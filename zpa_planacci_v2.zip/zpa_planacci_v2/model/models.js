sap.ui.define([
	"sap/ui/model/json/JSONModel",
	"sap/ui/Device",
	"sap/m/MessageBox",
	"ZPA_PLANESACCI/js/Utils",
], function (JSONModel, Device, MessageBox, Utils) {
	"use strict";

	return {

		createDeviceModel: function () {
			var oModel = new JSONModel(Device);
			oModel.setDefaultBindingMode("OneWay");
			return oModel;
		},
		/*
		 * Funcion que devuelve una estructura de parametros para los read
		 * @return estructura parametros
		 */
		getParamCall: function () {
			var parametros = {
				DataSource: "",
				EntityName: "",
				KeyValues: {},
				Filters: [],
				UrlParams: {
					Expand: [],
					Count: false,
					Skip: "",
					Top: ""
				}

			}
			return parametros;
		},
		/*
		 * Funcion que recupera las keys dado un objeto de campos
		 * @KeyValues: Objeto con los campos clave
		 * @sEntity: Nombre del modelo de salida ( en core )
		 */
		getKeys: function (KeyValues) {
			var keys = "";
			var arrkeys = Object.keys(KeyValues);
			var len = arrkeys.length;
			var i = 0;
			$.each(KeyValues, function (key, value) {
				if (i == len - 1) {
					keys = keys.concat(key + "=" + "'" + value + "'");
				} else {
					keys = keys.concat(key + "=" + "'" + value + "',");
				}
				i++;
			});
			return keys;
		},
		/*
		 * Funcion que realiza una lectura de entidad
		 * @oContext: Contexto desde el cual es llamada la funcion
		 * @paramCall: parametros de la llamada oData
		 * @sEntity: Nombre del modelo de salida ( en core )
		 */
		readModel: function (oContext, paramCall, sEntity, sType) {
			var that = this;
			//1) Formamos la url de llamada de la entidad con Posibles claves
			var keys = "";
			if (paramCall && paramCall.KeyValues) {
				keys = that.getKeys(paramCall.KeyValues);
			}

			//2) Colocamos las claves ( si hay )
			var entityName;
			if (keys) {
				entityName = paramCall.EntityName + "(" + keys + ")";
			} else {
				entityName = paramCall.EntityName;
			}

			//3) Parametros en URL
			//3.1) Posibles llamadas con Expand
			var oParams = {};
			if (paramCall && paramCall.UrlParams.Expand && paramCall.UrlParams.Expand.length > 0) {
				var expand = "";
				var len = paramCall.UrlParams.Expand.length;
				$.each(paramCall.UrlParams.Expand, function (index, value) {
					if (index == len - 1) {
						expand = expand.concat(value);
					} else {
						expand = expand.concat(value + ",");
					}
				});
				oParams["$expand"] = expand;
			}
			//3.2) Posibles llamadas con Count
			if (paramCall && paramCall.UrlParams.Count) {
				oParams["$count"] = "";
			}
			//3.3) Posibles llamadas con Skip
			if (paramCall && paramCall.UrlParams.Skip) {
				oParams["$skip"] = paramCall.UrlParams.Skip;
			}
			//3.4) Posibles llamadas con Top
			if (paramCall && paramCall.UrlParams.Top) {
				oParams["$top"] = paramCall.UrlParams.Top;
			}

			//4) Indicamos si lo que estamos ejecutando es un GET ( Read ) o un REP ( Query ).
			//   Esto se hace mirando si se han puesto filtros ( es lo que diferencia un REP de un GET )
			//var sType = ( paramCall.Filters && paramCall.Filters.length !== 0 ) ? "Query" : "Read";

			let sEntorno = oContext.getOwnerComponent().getModel("GlobalVars").getProperty("/Entorno");
			if (sEntorno === "FIORI") {
				//5) Ejecutamos la llamada al read
				// Ya que no coge el valor de texto de una variable NO SE PORQUE, lo ponemos a mano
				//var oModel = oContext.getOwnerComponent().getModel(paramCall.DataSource);
				var oModel = oContext.getOwnerComponent().getModel("zemateriales");
				oModel.read("/" + entityName, {
					urlParameters: oParams,
					filters: paramCall.Filters,
					success: function (oData, oResponse) {
						// Generamos modelo sin results inicial
						if (paramCall && paramCall.UrlParams.Expand && paramCall.UrlParams.Expand.length > 0) {
							if (oData.results[0]) {
								oData = oData.results[0];
							}
						}
						//Exito en la llamada oData
						var oJSONModel = new sap.ui.model.json.JSONModel(oData);
						// Guardar modelo en component
						oContext.getOwnerComponent().setModel(oJSONModel, sEntity);
						// Llamamos a la función callback
						oContext.entityCallBack(paramCall.EntityName, sType, oData, oResponse, paramCall);
					},
					error: function (oResponse) {
						//Error en la llamada oData
						that.ODataError(oContext, oResponse);
					}
				});
			}


		},//readModel
		/*
		 * Funcion para accion create del modelo
		 * @oContext: contexto desde el que se llama a la funcion
		 * @paramCall: parametros de la llamada oData
		 * @oPost objeto para realizar el create
		 */
		createModel: function (oContext, paramCall, oPost) {
			//1) Ejecutamos la llamada al create
			var that = this;
			var oModel = oContext.getOwnerComponent().getModel(paramCall.DataSource);
			oModel.create("/" + paramCall.EntityName, oPost, {
				success: function (oData, oResponse) {
					// Llamamos a la función callback
					oContext.entityCallBack(paramCall.EntityName, "Create", oData, oResponse);
				},
				error: function (oResponse) {
					//Error en la llamada oData
					that.ODataError(oContext, oResponse);
				}

			});

		}, //createModel
		/*
		 * Funcion para accion update del modelo
		 * @oContext: contexto desde el que se llama a la funcion
		 * @paramCall: parametros de la llamada oData
		 * @oPost: objeto para realizar el update
		 */
		updateModel: function (oContext, paramCall, oPost) {
			var that = this;
			//1) Formamos la url de llamada de la entidad con las claves
			var keys = "";
			if (paramCall.KeyValues) {
				keys = that.getKeys(paramCall.KeyValues);
			}

			//2) Ejecutamos la llamada al update
			var oModel = oContext.getOwnerComponent().getModel(paramCall.DataSource);
			oModel.update("/" + paramCall.EntityName + "(" + keys + ")", oPost, {
				success: function (oData, oResponse) {
					// Llamamos a la función callback
					oContext.entityCallBack(paramCall.EntityName, "Update", oData, oResponse);
				},
				error: function (oResponse) {
					//Error en la llamada oData
					that.ODataError(oContext, oResponse);
				}

			});

		}, //updateModel
		/*
		 * Funcion para accion delete del modelo
		 * @oContext: contexto desde el que se llama a la funcion
		 * @paramCall: parametros de la llamada oData
		 */
		removeModel: function (oContext, paramCall) {
			var that = this;
			//1) Formamos la url de llamada de la entidad con las claves
			var keys = "";
			if (paramCall.KeyValues) {
				keys = that.getKeys(paramCall.KeyValues);
			}

			//2) Ejecutamos la llamada al remove
			var oModel = oContext.getOwnerComponent().getModel(paramCall.DataSource);
			oModel.remove("/" + paramCall.EntityName + "(" + keys + ")", {
				success: function (oResponse) {
					// Llamamos a la función callback
					oContext.entityCallBack(paramCall.EntityName, "Remove", {}, oResponse);
				},
				error: function (oResponse) {
					//Error en la llamada oData
					that.ODataError(oContext, oResponse);
				}

			});
		}, //removeModel
		/** 
		 * Función genérica para capturar y mostrar los errores en las llamadas a oData.
		 * @oContext: contexto desde el que se llama a la funcion
		 * @oError: 	Objeto error que viene del servicio (obligatorio)
		 * @oFunction:	Funcion que se ejecutara tras cerrar el mensaje de error (opcional)
		 */
		ODataError: function (oContext, oError, oFunction) {
			var message, data;

			try {
				// lo formateamos a JSON
				data = $.parseJSON(oError.responseText);
				message = "";

				// obtengo el mensaje de error
				if (data.error.innererror.errordetails && data.error.innererror.errordetails.length > 0) {
					for (var i = 0; i < data.error.innererror.errordetails.length; i++) {
						if (data.error.innererror.errordetails[i].code !== "/IWBEP/CX_SD_GEN_DPC_BUSINS") {
							message += " - " + data.error.innererror.errordetails[i].message + "\n";
						}
					}
				} else {
					message += data.error.message.value;
				}
			} catch (err) {
				// si el formateo a JSON falla, lo intentamos formatear a XML
				data = $.parseXML(oError.responseText);
				var $xml = $(data);
				var $message = $xml.find("innererror").find("message");
				if (!$message.text()) {
					$message = $xml.find("message");
				}
				message = $message.text();
			}

			// quitamos el busy de espera
			if (oContext.getView()) {
				oContext.getView().setBusy(false);
			}

			// Mostramos el mensaje de error por pantalla
			MessageBox.error(message, {
				title: "Error"
			});
		}, //ODataError
		loadTemas: function (oContext) {
			var oModel = oContext.getOwnerComponent().getModel("ZGRCAUD_PORTAL");

			oModel.read(
				"/InfoThemesSet",
				{
					//   filters : aFilters,
					success: function (oData) {
						console.log(oData);
						var oModel = new sap.ui.model.json.JSONModel();
						oModel.setData(oData);
						oContext.getView().setModel(oModel, "temasModel").iSizeLimit = 200;

					}.bind(this),
					error: function (oError) {
						jQuery.sap.log.info("Odata Error occured");
					}.bind(this)
				});
		},

		//INI MMM 20/03/2023
		loadComentarios: function(oContext,key){
			var oModel = oContext.getOwnerComponent().getModel("ZGRCAUD_PORTAL");
			var url = Utils._formatUrl("/InfoActionDetailSet(binary{0})/NoteSet?$orderby=CreateTime desc", [key]);
			oModel.read(
				url , 
				{
					//Declaro el read model asincrono para poder luego realizar la creacion del fragment
					// y  que no ocurra antes de esto
					async: false,
					success: function (oData) {
						console.log(oData);
						var oModel = new sap.ui.model.json.JSONModel();
						oModel.setData(oData);
						//Guardo el array de comentarios en un Modelo para luego utilizar en la vista
						oContext.getView().setModel(oModel, "NoteSet");	
					}.bind(this),
					error: function (oError) {
						jQuery.sap.log.info("Odata Error occured");
					}.bind(this)
				});	
		},
		//FIN MMM 20/03/2023
		// Funció per guardar
		savePlanAccion: function (oContext, oEntity, notes) {
			var that = this
			var oModel = oContext.getOwnerComponent().getModel("ZGRCAUD_PORTAL");
			oModel.create(
				"/InfoActionDetailDeepSet", oEntity,
				{
					success: function () {

						that.onSavePlanAccionSuccess(oContext, notes);

					},
					error: function (oError) {
						that.onSavePlanAccionError(oError);
					}

				});
		},
		// La funcio succes del saveUser
		onSavePlanAccionSuccess: function (oContext, oNotes) {
			var oModel = oContext.getOwnerComponent().getModel("ZGRCAUD_PORTAL");
			
			
			//INI ASE 12/04/2023
			this.onSaveNotes(oContext,oModel, oNotes, 0);
			//END ASE 12/04/2023
			//for (var i = 0; i < oNotes.length; i++) {
				// if (oNotes[i] != null && oNotes[i] != undefined
				// 	&& oNotes[i].Text != undefined && oNotes[i].Text != "") {
				// 	var oEntity = {};
				// 	oEntity.TypeKey = "COMMENT";
				// 	oEntity.Text = oNotes[i].Text;
				// 	oEntity.Status = oNotes[i].Status;

					// Recupero la key recien creada y la busco para obtener el
					// ParentKey para crear la nota
					// var key = oContext.getView().getModel("PlanesCentroDetailSet").getProperty("/ActionKey");



					// var url = Utils._formatUrl("/InfoActionDetailSet(binary{0})/NoteSet", [Utils._convertKey(key)]);
					// oModel.create(url, oEntity, 
					// 	{	
					// 		success: function () {
								
					// 			Utils._showMsg(oContext.getI18nText("guardarOk", {}));
					// 		},
					// 		error: function (oError) {
					// 			Utils._showMsg(oContext.getI18nText("errCrearNota", {}));
					// 		}
					// 	}
					// );

					//INI MMM 05/04/2023
					// $.ajax({
					// 	type: 'POST',
					// 	url: oModel.sServiceUrl+url,
					// 	headers: { 'X-CSRF-Token': oModel.getSecurityToken() },
					// 	dataType: "json",
					// 	contentType: "application/json",
					// 	async: false,
					// 	success: function (oData) {
					// 		console.log("Okay");
					// 	},
					// 	error: function (oError) {
					// 		console.log("Non Okay");
					// 	}
					// });
					//FIN MMM 05/04/2023

				//}
			//}

			// Se guardan los attachements
			if (sap.ui.getCore().byId("anexosType2")){
				Utils.onSaveAttachments(oContext.getView().getModel("PlanesCentroDetailSet").getProperty("/ActionKey"),
				sap.ui.getCore().byId("anexosType2"), "Action");
			}

			oContext.onTabSelect();
			oContext.onBack();
			oContext.onCloseComent();

			oContext.getView().getModel("AccessListDetail").setData({});
			//INI MMM 17/04/2023
			oContext.getView().getModel("PlanesCentroDetailSet").getData().Commentary="";
			//FIN MMM 17/04/2023
		},

		onSaveNotes: function (oContext, oModel, oNotes, Index){
			var that = this
			if (oNotes[Index] != null && oNotes[Index] != undefined
				&& oNotes[Index].Text != undefined && oNotes[Index].Text != "") {
				var oEntity = {};
				oEntity.TypeKey = "COMMENT";
				oEntity.Text = oNotes[Index].Text;
				oEntity.Status = oNotes[Index].Status;

				var key = oContext.getView().getModel("PlanesCentroDetailSet").getProperty("/ActionKey");



				var url = Utils._formatUrl("/InfoActionDetailSet(binary{0})/NoteSet", [Utils._convertKey(key)]);

				oModel.create(url, oEntity, 
						{	
							success: function () {
								Index = Index + 1;
								that.onSaveNotes(oContext, oModel, oNotes, Index);
								
								
							},
							error: function (oError) {
								Utils._showMsg(oContext.getI18nText("errCrearNota", {}));
							}
						}
					);
			}else{
				Utils._showMsg(oContext.getI18nText("guardarOk", {}));
			}
		},


		// La funció error del saveUser
		onSavePlanAccionError: function (oError) {

			console.log(oError);
			var dialog = new sap.m.Dialog({
				title: 'Error',
				type: 'Message',
				state: 'Error',
				content: new sap.m.Text({
					text: $(oError.response.body).find('message').first().text()
				}),
				beginButton: new sap.m.Button({
					text: 'Aceptar',
					press: function () {
						dialog.close();
					}
				}),
				afterClose: function () {
					dialog.destroy();
				}
			});
			dialog.open();

		},

		loadRol: function (oContext) {

			var oModel = oContext.getOwnerComponent().getModel("ZGRCAUD_PORTAL");

			oModel.read(
				"/InfoUserRolSet",
				{
					//   filters : aFilters,
					success: function (oData) {
						var oModel = new sap.ui.model.json.JSONModel();
						oModel.setData(oData);
						sap.ui.getCore().setModel(oModel, "rol");
						var rolObj = sap.ui.getCore().getModel('rol').getData().results;
						var oDepartModel = new sap.ui.model.json.JSONModel();
						$.each(rolObj, function (i, n) {
							$.each(n.Rol.split("_"), function (j, k) {
								if ($.isNumeric(k))
									oDepartModel.getData().Department = k;
							});
						})
						sap.ui.getCore().setModel(oDepartModel, "depart");

						if(Utils.isAuditado()){
							var user = sap.ushell.Container.getService("UserInfo").getId();
							this.loadUserThemesAudited(oContext,user);
						}
						this.loadTemas(oContext);
						this.loadValidatorStatus(oContext);
						this.loadStatusPlAccion(oContext);

						oContext.onTabSelect();
					}.bind(this),
					error: function (oError) {
						jQuery.sap.log.info("Odata Error occured");
					}.bind(this)
				});
		},

		//INI MM ASE 21/03/2023
		loadValidatorStatus : function(oContext)  {
			var oModel = oContext.getOwnerComponent().getModel("ZGRCAUD_PORTAL");

			oModel.read(
				"/InfoValidatedSet",
				{
					//   filters : aFilters,
					success: function (oData) {
						console.log(oData);
						var oModel = new sap.ui.model.json.JSONModel();
						oModel.setData(oData);
						oContext.getView().setModel(oModel, "validatorStatus");

					}.bind(this),
					error: function (oError) {
						jQuery.sap.log.info("Odata Error occured");
					}.bind(this)
				});
		  },
		//FIN MM ASE 21/03/2023

		//INI MMM ASE 22/03/2023
		loadUserThemesAudited: function(oContext, user) {
			var oModel = oContext.getOwnerComponent().getModel("ZGRCAUD_PORTAL");
			var skip = 0;
			var top = 7;
			var aFilters = [];
			aFilters.push(new sap.ui.model.Filter("Id", sap.ui.model.FilterOperator.Contains, user));
			var oParams = {
				"$expand": "InfoThemes"
			};
			oModel.read(
				"/InfoUsersSet?&$skip=" + skip + "&$top=" + top,
				{
					//filters : aFilters,
					urlParameters: oParams,
					filters: aFilters,
			  		async : false,
					success: function (oData) {
						console.log(oData);
						var oModel = new sap.ui.model.json.JSONModel();
						oModel.setData(oData.results[0].InfoThemes);

						oContext.getView().setModel(oModel, "userThemes");

					}.bind(this),
					error: function (oError) {
						jQuery.sap.log.info("Odata Error occured");
					}.bind(this)
				});
		},

		loadDetail: function(oContext,key){
			var aFilters = [];
			aFilters.push(new sap.ui.model.Filter("ActionKey", sap.ui.model.FilterOperator.EQ, key));

			var oParams = {
				"$expand": "InfoAccessList,InfoThemes"
			};
			var oModel = oContext.getOwnerComponent().getModel("ZGRCAUD_PORTAL");
			var url = "/InfoActionDetailV2Set";
			oModel.read(
				url , 
				{
					//Declaro el read model asincrono para poder luego realizar la creacion del fragment
					// y  que no ocurra antes de esto
					urlParameters: oParams,
					filters: aFilters,
					async: false,
					success: function (oData) {
						console.log(url)
						console.log(oData.results);
						var oModel = new sap.ui.model.json.JSONModel();
						// for(var i=0;i < oData.results.length; i++){
						// 	if()
						// }
						var results = [];
						for (let i = 0; i < oData.results[0].InfoThemes.results.length; i++) {
							results.push(oData.results[0].InfoThemes.results[i].Key);
							
						}
						oModel.setData(results);
						//Guardo el array de comentarios en un Modelo para luego utilizar en la vista
						oContext.getView().setModel(oModel, "DetailSet");

						var oModel2 = new sap.ui.model.json.JSONModel();

						
						oModel2.setData(oData.results[0]);
						//Guardo el array de comentarios en un Modelo para luego utilizar en la vista
						oContext.getView().setModel(oModel2, "DetailGet");

						var key = oModel2.getData().ActionKey;
						Utils.onFetchStandardAttachments(oContext, key, "Actions");
						if(Utils.isAuditado() && oContext.getView().getModel("PlanesCentroDetailSet")){
							oContext.getView().getModel("PlanesCentroDetailSet").getData().ZzViewAudited = true;
						}
						oContext._createFragment();
					}.bind(this),
					error: function (oError) {
						jQuery.sap.log.info("Odata Error occured");
					}.bind(this)
				});		
		},

		loadStatusPlAccion: function (oContext) {
			// Dels status segons els seus codis
			var oModel = oContext.getOwnerComponent().getModel("ZGRCAUD_ALERTAS");
			var aFilters = [];
			aFilters.push(new sap.ui.model.Filter("Objtyp", sap.ui.model.FilterOperator.EQ, "ACTION"));
		  //  Codigo nuevo
			aFilters.push(new sap.ui.model.Filter("Langu", sap.ui.model.FilterOperator.EQ, sap.ui.getCore().getConfiguration().getLanguage().toUpperCase()));
		  //  Codigo viejo
		  //  aFilters.push(new sap.ui.model.Filter("Langu", sap.ui.model.FilterOperator.EQ, "ES"));
		  
		  oModel.read("/InfoStatusSet", {
			  filters : aFilters,
			  async : false,
			  success : function(oData) {
				var oModel = new sap.ui.model.json.JSONModel();
				oModel.setData(oData);
				oContext.getView().setModel(oModel, "statusPlModel");
			  }.bind(this),
			  error : function(oError) {
				jQuery.sap.log.info("Odata Error occured");
			  }.bind(this)
			});
		  },
		  //INI ASE MMM 29/03/2023
		  loadAccessList: function (oContext, name) {

			var aFilters = []
			aFilters.push(new sap.ui.model.Filter("FullName", sap.ui.model.FilterOperator.EQ, name));
			

			var oModel = oContext.getOwnerComponent().getModel();

			oModel.read(
				"/RoleSet(RoleId='AUD',RoleDepId='')/Users",
				{
					filters: aFilters,
					async: false,
					success: function (oData) {
						console.log(oData);
						var oModel = new sap.ui.model.json.JSONModel();
						oModel.setData(oData);
						oContext.getView().setModel(oModel, "AccessList");
						

					}.bind(this),
					error: function (oError) {
						jQuery.sap.log.info("Odata Error occured");
					}.bind(this)
				});
		},

		//FIN ASE MMM 29/03/2023
		//INI MMM ASE 19/04/2023
		createExportJob: function(oContext, aFilters, aSorters, ObjectType){
			var oModel = oContext.getOwnerComponent().getModel("ZGRCAUD_PORTAL");
			var oEntity = {};
			var selections = [];
			
			oEntity.ObjectType = ObjectType
			oEntity.Scenario = "LST_ACTPOR";
			oEntity.Template = "XLSX";
		  
			$.each(aFilters, function(i, n) {
			  var operator = "";
			  var value = ""
			  switch (n.sOperator) {
			  default:
				operator = n.sOperator;
				value = n.oValue1;
				break;
			  case "Contains":
				operator = "CP";
				value = "*" + n.oValue1 + "*";
				break;
			  }
			  selections.push({
				Field : n.sPath,
				Sign : "I",
				Opt : operator,
				Low : value
			  });
			});
		  
			var sorts = [];
			$.each(aSorters, function(i, n) {
			  sorts.push({
				AttributeName : n.sPath,
				Ascending : !n.bDescending
			  });
			});
		  
			if (selections.length != 0)
			  oEntity.Selections = selections;
			if (sorts.length != 0)
			  oEntity.Sorts = sorts;
			
		  
			var url = "/ExportJobSet";
			oModel.create(
				url,
				oEntity,
				{
				success: function (oData) {
				  window.open(location.protocol + "//" + location.hostname + ":" + location.port + oModel.sServiceUrl
					  + "/ExportJobSet(guid'" + oData.Key + "')/File/$value", '_blank');
				},
				error: function (oError) {
				  console.log(oError);
				}
			});
		},
		//FIN MMM ASE 19/04/2023

		//INI MMM ASE 20/04/2023
		loadOrigen: function (oContext){

			var oModel = oContext.getOwnerComponent().getModel("ZGRCAUD_PORTAL");

			oModel.read("/InfoOrigenSet", {
				success : function(oData) {
					var oModel = new sap.ui.model.json.JSONModel();
					oModel.setData(oData);
					oContext.getView().setModel(oModel, "OrigenActionPlan");
				}.bind(this),
				error : function(oError) {
					console.log(oError);
				}.bind(this)
			});
			
		}
		//FIN MMM ASE 20/04/2023
		
	};
});
sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"ZPA_PLANESACCI/model/models",
	"ZPA_PLANESACCI/js/Utils"
], function (UIComponent, Device, models, Utils) {
	"use strict";

	return UIComponent.extend("ZPA_PLANESACCI.Component", {

		metadata: {
			manifest: "json"
		},


		init: function () {
			let sEntorno;
			// call the base component's init function
			UIComponent.prototype.init.apply(this, arguments);

			// var showURL = !localStorage.getItem("showURL");
			// this.getModel("ZGRCAUD_PORTAL").setUseBatch(showURL);
			this.getModel("ZGRCAUD_PORTAL").setUseBatch(false);

			// set the device model
			this.setModel(models.createDeviceModel(), "device");

			// set global var
			this.setModel(new sap.ui.model.json.JSONModel({}), "GlobalVars");
			
			// enable routing
			this.getRouter().initialize();
		},
		exit: function(){
			localStorage.removeItem('filtrosTema');
			localStorage.removeItem('ordenacionesTema');
			localStorage.removeItem('filtrosCentro');
			localStorage.removeItem('ordenacionesCentro');
		}
	});
});
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/routing/History",
	"ZPA_PLANESACCI/js/Formatter",
	"sap/m/MessageBox",
	"sap/m/MessageToast",
	"sap/m/MessageStrip",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/core/Icon",
	"ZPA_PLANESACCI/model/models"
], function(Controller, History, Formatter, MessageBox, MessageToast, MessageStrip, Filter, FilterOperator, Icon, models) {
	"use strict";
	return Controller.extend("ZPA_PLANESACCI.controller.BaseController", {
		// INI MFDL - 15-12-2022
		Formatter: Formatter,
		// FIN MFDL - 15-12-2022
		
		// Recuperación modelo json "device"
		getDeviceModel: function() {
			debugger
			return this.getOwnerComponent().getModel("device");
		},

		/**
		 * 
		 * @param {String} sName 
		 * @returns 
		 */
		_byId: function (sName) {
			var cmp = this.byId(sName);
			if (!cmp) {
				cmp = sap.ui.getCore().byId(sName);
			}
			return cmp;
		},
		
		// Recuperar el valor del i18n
		// @params sText: Codigo para recuperar el texto del fichero i18n
		// @params oParams: Array con los valores a introducir en los datos {0}, {1}, etc que se tenga en el i18n
		getI18nText: function(sText,oParams) {
			var oParams = ( oParams ) ? oParams : [];
			return this.getOwnerComponent().getModel("i18n").getResourceBundle().getText(sText,oParams);
		},

		// Evento para simplificar las llamadas al routing del manifest.json.
		getRouter: function () {
			return sap.ui.core.UIComponent.getRouterFor(this);
		},
		onNavBack: function() {
        	this.getRouter().navTo("Home");
		},
		/**
		 * Funcion de recuperación de datos para los combos
		 * @param {Array} oArrayParams 
		 */
		getDataCombos: function(oArrayParams) {
			for (let index = 0; index < oArrayParams.length; index++) {
				const element = oArrayParams[index];
				let Campo = element.Campo;
				let Filtro = element.Filtro;
				let Name = element.ModelName;

				// generacion d efiltro segun parametros
				let aFilter =  [];
				aFilter.push(new sap.ui.model.Filter('ICampo', sap.ui.model.FilterOperator.EQ, Campo));
				aFilter.push(new sap.ui.model.Filter('IFiltro', sap.ui.model.FilterOperator.EQ, Filtro));

				// Llamada a la función para recuperar todos los datos
				var params = models.getParamCall();
				//params.DataSource = "zemateriales";
				params.EntityName = "ayudaBusquedaMaterialSet";
				params.Filters = aFilter;
				params.ModelName = Name;
				models.readModel(this, params, Name,"Query");
			}
		},
		/**
		 * Funcion de retorno despues de una llamada oData
		 * @param {} sEntity : Nombre del modelo
		 * @param {} sType :Tipo de ejecución ( Read | Query | Create | Update | Remove )
		 * @param {} oData : Datos de retorno del backend
		 * @param {} oResponse : Respuesta del odata
		 * @param {} oParams : Parametros pasados en la llamada readModel | createModel | updateModel | removeModel
		 */
		entityCallBack: function (sEntity, sType, oData, oResponse,oParams){
			var that = this;
			// Realizamos diferentes acciones segun el nombre del modelo
			switch (sEntity){
				case "actualizarDeepSet":
					//Paramos el "cargando" de los datos
					this.getView().setBusy(false);
					// Realizamos diferentes acciones segun el tipo ( Read / Query / Create / Update / Remove )
					switch (sType){
						case "Query":
							if(oData&&oData.actualizarZTPW_SIMULDATGENSet) {
								var data = oData.actualizarZTPW_SIMULDATGENSet.results;
								if(oParams.UrlParams&&oParams.UrlParams.Expand&&oParams.UrlParams.Expand.indexOf("actualizarZTPW_SIMULDATGENSet")!==-1) {
									var oDataResults = {"results":[]};
									var object = {};
									for (let index = 0; index < data.length; index++) {
										const element = data[index];
										var grupo = element.Agrupacion;
										if(!object[grupo]){
											object[grupo] = [];
										}
										object[grupo].push(element);
									}
									for (const key in object) {
										if (Object.hasOwnProperty.call(object, key)) {
											const element = object[key];
											oDataResults.results.push({"Grupo":key,"Datos":element});
											
										}
									}
									var oJSONModel = new sap.ui.model.json.JSONModel(oDataResults);
									that.getView().setModel(oJSONModel,"DatosGeneralesForm");
								}
							}
							break;		
						case "Create":	
							var message = this.getI18nText("txtSuccessSave", {});
							var messagetitle = this.getI18nText("txtSave", {});
							MessageBox.alert(message, {
								icon: MessageBox.Icon.SUCCESS,
								title: messagetitle
							});
							console.log(oData);
						break;					
					}
				break;
				case "ayudaBusquedaMaterialSet": 
					// Realizamos diferentes acciones segun el tipo ( Read / Query / Create / Update / Remove )
					switch (sType){
						case "Query":
							let sEntorno = that.getOwnerComponent().getModel("GlobalVars").getProperty("/Entorno");
							if (sEntorno === "LOCAL") {
								let oJsonData = that.getOwnerComponent().getModel(sEntity).getData();
								var oModel = new sap.ui.model.json.JSONModel(oJsonData[oParams.ModelName]);
								that.getView().setModel(oModel,oParams.ModelName);
							}
							break;						
					}
				break
			}
			
		},//entityCallBack
		/**
		 * Función de guardado de tablas
		 * @param {*} oEvent 
		 */
		onSaveData: function(oEvent) {
			//Le pasamos el id:1 porque el Deep Entity lo requiere
			var oObject = {"id":"1"};
			var oSource = oEvent.getSource();
			var sTabla = oSource.data("Tabla");
			var sModel = oSource.data("Model");
			//Que quede constancia de que esto parece facil pero ha sido durisimo
			var oModel = this.getView().getModel(sModel);
			if(oModel) {
				var aResults = oModel.getData().results;

				//En cualquier caso que tengamos una tabla que funcione similar a Datos Generales
				//habría que utilizar este if

				//Si nos piden enviar todas las tablas con poner un bucle en este if que recorra un array con todas las Nav
				// seria suficiente
				if(sTabla==="actualizarZTPW_SIMULDATGENSet"){	
					let aResultsAux = [];
					for (let index = 0; index < aResults.length; index++) {
						const element = aResults[index];
						for (let index2 = 0; index2 < element.Datos.length; index2++) {
							const element2 = element.Datos[index2];
							aResultsAux.push(element2);
						}						
					}
					aResults = aResultsAux;
					oObject[sTabla] = aResults;
				} else {
					oObject[sTabla] = oModel.getData()[sTabla].results
				}
				//Carga de pantalla para el contenido
				this.getView().setBusy(true);
				var params = models.getParamCall();
					params.EntityName = "actualizarDeepSet";
				models.createModel(this, params, oObject); 
			}
		},
		/**
		 * 
		 * @param {Object} oEvent 
		 */
		onValidateGlobal: function(oEvent){
			var oElement = oEvent.getSource();
			var id = oElement.data("Id");
			//var id = oElement.sId;
			var contenedor = this._byId(oElement.data("contenedor"));
			var validarBoton = true;
			this.dataId = id;
		    this.dataContenedor = oElement.data("contenedor");
			contenedor.FindElement(id).forEach(element => {
				if(!this._validate(element)){
					validarBoton = false;
				}
				//ESTE ES ESPECIAL PARA LA VISTA DE LOS PORCENTAJES
				if(element.data("contenedor")==="ZTPW_PORC_REG_TT"){
					if(!this._validarPorcentajes(element)){
						validarBoton = false;
					}
				}
				//console.log(element.getValue());
				// console.log(element.sId);
			});
			this._byId("btnUpdate").setEnabled(validarBoton);
		},
		// MFDL - 16-12-2022
		onUpdateTable: function(oEvent){

			var contenedor = this._byId(this.dataContenedor);
   
			var validarBoton = true;
			if(contenedor){
				contenedor.FindElement(this.dataId).forEach(element => {
					this._validate(element)
	   
				});
			}
		 },
		 //16-12-2022
		/**
		 * Evento de validacion
		 * @param {Object} oEvent 
		 */
		onValidate: function (oEvent) {
			// Llamamos a la función generica de validación
			this._validate(oEvent.getSource());
		},
		/**
		 * Función generica de validacion
		 * @param {Object} oElement 
		 */
		_validate: function(oElement) {

			var clase = oElement.getMetadata().getName();
			var tipo = (oElement.data("type")) ? oElement.data("type") : "normal";
			var valor;
			// Recuperamos el valor según el tipo de elemento que tengamos
			// y validamos que el formato sea correcto
			switch (clase) {
				case "sap.m.Input":
				default:
					switch (tipo) {
						case "number":
							valor = this._inputAmountValidation(oElement);
							break;
						case "normal":
						default:
							valor = this._inputValidation(oElement);
							break;
					}
					break;
				
			}
			return valor;
		},
		_inputValidation: function (oElement) {
			var input = oElement;
			var inputValue = input.getValue();

			//Validación longitud de campo
			var inputLength = inputValue.length;
			var inputMaxLength = input.getMaxLength();
			if (inputLength > inputMaxLength) {
				input.setValueState("Warning");
				input.setValueStateText("Maximum length reached");
				input.setValue(inputValue.substr(0, inputMaxLength));
				input.setShowValueStateMessage(true);
				return false;
			}
			// Validacion caracteres especiales
			var regExp = new RegExp(this.getOwnerComponent().getModel("Maestros").getProperty("/regExp"));
			if (!regExp.test(inputValue.toString())) {
				if (inputValue !== "") {
					input.setValueStateText("Character not allowed");
					input.setValueState("Error");
					input.setShowValueStateMessage(true);
					return false;
				}
			}

			input.setValueState("None");
			input.setShowValueStateMessage(false);
			return true;

		},
		_inputAmountValidation: function (oElement) {
			let sValue = oElement.getValue();
			//INI MFDL  14-12-2022 - validacion del campo numerico	
            let letras=new RegExp(/[A-Za-z.]+/g);
			let dato = sValue;
		
			if(letras.test(sValue)){
				dato=sValue.replace(letras, "");
				oElement.setValue(dato);
			}	
			 //FIN MFDL 14-12-2022
			//var oRegExp1 = new RegExp("^[0-9,.-]*$");
			// ^(\d{1,3})(([.]\d{3}))*([,]\d{1,2})?$
			let oRegExp = new RegExp(/^(\d{1,3})*([,]\d{1,3})?$/g);
			// var element = oElement.getParent();
			// if(!oRegExp.test(dato)){
			// 	var msg = "No valido";
			// 	var type = "Error";
			// 	this._generateMsgStrip(element,msg,type);
			// }else{
			// 	this._destroyElements(element)
			// }

			if (!oRegExp.test(dato)) {
				oElement.setValueStateText("Character not allowed");
				oElement.setValueState("Error");
				// oElement.setShowValueStateMessage(true);
				oElement.addStyleClass("fieldError");
				return false;
			}else{
				// quito el error del input
				oElement.setValueState("None");
				oElement.setShowValueStateMessage(false);
				return true;
			}
			
			// return true;
			
		},
		/**
		 * 
		 * @param {Object} element 
		 * @param {String} msg 
		 * @param {String} type 
		 */
		_generateMsgStrip: function (element,msg,type) {
			let IdMsgStrip = element.getId() + "_MSG";

			let Item = sap.ui.getCore().byId(IdMsgStrip);

		    if(Item !== undefined){Item.destroy(); }
		
			let MsgStrip = new MessageStrip({
				id:IdMsgStrip,
				text: msg,
				showIcon: true,
				type: type
			});
			
			if(element.addItem){element.addItem(MsgStrip);}
			
		},
		/**
		 * 
		 * @param {Object} Input 
		 */
		_destroyElements: function(Input){

			let IdMsgStrip = Input.getId() + "_MSG";

			var Item = sap.ui.getCore().byId(IdMsgStrip);

		    if(Item !== undefined){Item.destroy(); }
		},
		/**
		 * 
		 * @param {Object} oElement 
		 */
		_findElementGlobal: function(oElement){

			oElement.FindElement=function(Id){
				let Contenedor=this;
				let IdElementoBuscado=Id;

				let Elementos=Contenedor.findElements(true),x=0;
				if(!Elementos)return null;
				let arrayElements = [];
				while(x<Elementos.length){
					if(Elementos[x].data&&Elementos[x].data("Id")==IdElementoBuscado){
						arrayElements.push(Elementos[x]);
					}
					
					x++;
				}
				return arrayElements;
				
			};
		},
		/**
		 * 
		 * @param {Object} oElement 
		 * @returns 
		 */
		_validarPorcentajes : function(oElement){
			// INI MFDL - 15-12-2022 - funcion  para calcular y validar la suma de valores sea menos igual a 100%
			var aDataTabla = this.getView().getModel("SimulDeep").getData().actualizarZTPW_PORC_REG_TTSet.results;
			var fTotal     = 0;
			var dialog;
			var that = this;
			var pos = oElement.getBindingContext("SimulDeep").getPath().split("/")[oElement.getBindingContext("SimulDeep").getPath().split("/").length -1]
			aDataTabla[pos].Porce = oElement.getValue();
			aDataTabla.forEach(elem => {
				if(elem.Porce!==""){	  
					fTotal += parseFloat(elem.Porce);
				} 
			});
			var element = this._byId("MessageError");
			if(fTotal > 100){	
				this._byId("btnUpdate").setEnabled(false);
				var msg = this.getI18nText("txtErrorPorc", {});
				var type = "Error";
				this._generateMsgStrip(element,msg,type);
				return false;
			}else{	
				this.getView().byId("btnUpdate").setEnabled(true);	
				this._destroyElements(element);
				return true;
			}//FIN MFDL - 15-12-2022 
		
		},
		getDataSimulacion: function(oExpand) {
			//Carga de pantalla para el contenido
			this.getView().setBusyIndicatorDelay(0);
			this.getView().setBusy(true);
			// Llamada a la función para recuperar todos los datos
			var params = models.getParamCall();
			//params.DataSource = "zemateriales";
			params.EntityName = "actualizarDeepSet";
			params.UrlParams.Expand = oExpand;
			models.readModel(this, params, "SimulDeep","Query");
		}
		
	});
}); 
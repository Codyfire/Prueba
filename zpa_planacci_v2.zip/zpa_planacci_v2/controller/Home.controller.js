sap.ui.define(
	[
		"ZPA_PLANESACCI/controller/BaseController",
		"ZPA_PLANESACCI/js/Formatter",
		"ZPA_PLANESACCI/model/models",
		"sap/ui/model/Filter",
		"sap/ui/model/FilterOperator",
		"sap/ui/Device",
		"ZPA_PLANESACCI/js/Utils",
		"sap/ui/model/json/JSONModel",
	],
	function (
		BaseController,
		Formatter,
		models,
		Filter,
		FilterOperator,
		Device,
		Utils,
		JSONModel
	) {
		"use strict";

		return BaseController.extend("ZPA_PLANESACCI.controller.Home", {
			onInit: function () {
				
				models.loadRol(this);

				sap.ui
					.getCore()
					.getMessageManager()
					.registerObject(this.getView(), true);
				this.getRouter()
					.getRoute("Home")
					.attachPatternMatched(this._onObjectMatched, this);

				var oData = {};

				this.oModel = new sap.ui.model.json.JSONModel(oData);
				this.getView().setModel(this.oModel, "Filters");

				//INI MMN ASE 29/03/2023
				//Creacion de un modelo para la busqueda del fragment AccessList
				oData = {
					AccessListSearch: ""
				}
				this.oModel = new sap.ui.model.json.JSONModel(oData);
				this.getView().setModel(this.oModel, "SearchValue");
				//SSJ
				// this.getDataSimulacion(["InfoActionsSet"]);
				var oData = {};

				this.oModel = new sap.ui.model.json.JSONModel(oData);
				this.getView().setModel(this.oModel, "FileItems");

				//INI MMM ASE 30/03/2023
				this.oModel = new sap.ui.model.json.JSONModel(oData);
				this.getView().setModel(this.oModel, "AccessListDetail");
				//FIN MMM ASE 30/03/2023

				//INI MMM ASE 20/04/2023
				models.loadOrigen(this);
				//INI MMM ASE 20/04/2023

				


			},

			/**
			 * @override
			 */
			onAfterRendering: function () {
				this.getView().getModel("InfoActionsSet");
			},

			//Se ejecutan los filtros pre llamada Auto ASEASE PPM100032267
			//INI ASE MMM 19/03/2023
			onBeforeRebindTable: function (oSource) {
				if (oSource.getParameters().id == "smartTableCentro") {
					var binding = oSource.getParameter("bindingParams");
					// Obtener los filtros y ordenaciones guardados del almacenamiento local 
					var storedFilters = JSON.parse(localStorage.getItem("filtrosCentro"));
					var storedSorters = JSON.parse(localStorage.getItem("ordenacionesCentro"));
				
					
					if (storedFilters != null) {
						for (let i = 0; i < storedFilters.length; i++) {
							binding.filters.push(storedFilters[i]);
						}
						//binding.filters.push(storedFilters);
					}else{
						binding.filters.push(new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "01"));
						binding.filters.push(new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "04"));
					}
					if (storedSorters != null) {
						for (let i = 0; i < storedSorters.length; i++) {
							binding.sorter.push(new sap.ui.model.Sorter(storedSorters[i].sPath, storedSorters[i].bDescending));	
						}
					}
					
					
					
				}
				else{
					var binding = oSource.getParameter("bindingParams");
					var selectItems = this._byId("multiComboBox").getSelectedKeys().length;
					// Obtener los filtros y ordenaciones guardados del almacenamiento local
					var storedFilters = JSON.parse(localStorage.getItem("filtrosTema"));
					var storedSorters = JSON.parse(localStorage.getItem("ordenacionesTema"));

					if (storedFilters != null && storedFilters.length > 0) {
						for (let i = 0; i < storedFilters.length; i++) {
							binding.filters.push(storedFilters[i]);
						}
						//binding.filters.push(storedFilters);
					}
					if (storedSorters != null) {
						for (let i = 0; i < storedSorters.length; i++) {
							binding.sorter.push(new sap.ui.model.Sorter(storedSorters[i].sPath, storedSorters[i].bDescending));	
						}			 
					}

					if (selectItems > 0) {
						for (let i = 0; i < selectItems; i++) {
							var auxTheme = this._byId("multiComboBox").getSelectedItems()[i].mProperties.text;
							binding.filters.push(new sap.ui.model.Filter("Theme", sap.ui.model.FilterOperator.EQ, auxTheme));
							
						}
						
					}
				 }
				//FIN ASE MMM 19/03/2023
				//Se ejecutan los filtros pre llamada Auto ASEASE PPM100032267 FIN
				

			},


			onTabSelect: function (oEvent) {
				var model = this.getView().getModel("InfoActionsSet");
				this._tab = this.byId("tabBarPlanes").getSelectedKey();
				if (this._tab == "tabCentros") {
					if (Utils.isAuditado()) {
						this.Action = "PlanesCentroAuditado";
					} else {
						this.Action = "PlanesCentroAuditor";
					}

				} else if (this._tab == "tabTemas") {
					//INI MMM ASE 16/03/2023
					if (Utils.isAuditado()) {
						this.Action = "PlanesTemaAuditado";
					} else {
						this.Action = "PlanesTemaAuditor";
					}
					//FIN MMM ASE 16/03/2023
				}
				this._createFragment();

			},

			onTableDetail: function (oEvent) {

				this.saveFilters();

				let oObject = oEvent.getSource().getBindingContext().getObject();

				if (this.Action == "PlanesCentroAuditado" || this.Action == "PlanesCentroAuditor") {
					this.Action = "PlanesDetail";

					var oModelCentro = new sap.ui.model.json.JSONModel(oObject);
					this.getView().setModel(oModelCentro, "PlanesCentroDetail");
					var oModelCentroEdit = new sap.ui.model.json.JSONModel(oObject);
					this.getView().setModel(oModelCentroEdit, "PlanesCentroDetailSet");

					//ASE ASE Tengo que poner un if IsValidate para que no pase por el Status
					this.getStatus();
					//INI MMM ASE 16/03/2023
				} else if (this.Action == "PlanesTemaAuditado" || this.Action == "PlanesTemaAuditor") {
					//FIN MMM ASE 16/03/2023
					this.Action = "PlanesTemaDetail";

					var oModelCentro = new sap.ui.model.json.JSONModel(oObject);
					this.getView().setModel(oModelCentro, "PlanesCentroThemeSet");
				}
				//INI MMM 20/03/2023
				//Decodifico la key para poder hacer la llamada correctamente
				let key_decoded = Utils._convertKey(oModelCentro.getProperty("/ActionKey"));
				models.loadDetail(this,key_decoded);
				models.loadComentarios(this,key_decoded);
				// models.onFetchStandardAttachments(this,key_decoded);
				//FIN MMM 20/03/2023
				
			},

			_createFragment: function () {
				// Destruimos el fragment si existiera y lo creamos de nuevas
				if (this._fragmentStatus) {
					this._fragmentStatus.destroy();
				}
				this.byId("PlanesPageAcci").destroyFooter();

				this._fragmentStatus = sap.ui.xmlfragment(
					"ZPA_PLANESACCI.view.fragment." + this.Action,
					this
				);
				this.getView().addDependent(this._fragmentStatus);
				this.byId(this._tab).addContent(this._fragmentStatus);
				// ME SALE UN ERROR DE DUPLICACION DE ID
				if (this.Action == "PlanesDetail") {
					var status = this.getView().getModel("PlanesCentroDetailSet").getData().Status;
					this._createFooter(status);
				}
			},
			doAction: function (oEvent) {
				var status = oEvent.getSource().getProperty("text");
				var oController = this;
				switch (status) {
					//INI MMM ASE 31/03/2023
					case this.getI18nText("planificar", {}):
						this.doChangeStatus(
							this.getI18nText("planifAccion", {}),
							this.getI18nText("planificar", {}),
							"fragment.Comentario",
							"01"
						);
						break;
					case this.getI18nText("obsoleto", {}):
						this.doChangeStatus(
							this.getI18nText("accionEstObs", {}),
							this.getI18nText("aceptar", {}),
							"fragment.Comentario",
							"03"
						);
						break;
					case this.getI18nText("completar", {}):
						this.doChangeStatus(
							this.getI18nText("complAccion", {}),
							this.getI18nText("aceptar", {}),
							"fragment.Comentario",
							"02"
						);
						break;
					// case "Aceptar Riesgo":
					// 	this.doChangeStatus(
					// 		this.getI18nText("asumirRiesgo", {}),
					// 		this.getI18nText("aceptar", {}),
					// 		"fragment.Comentario",
					// 		"05"
					// 	);
					// 	break;
					case "Verificar":
						this.doChangeStatus(
							this.getI18nText("verifAccion", {}),
							this.getI18nText("aceptar", {}),
							"fragment.OkKoAprobar",
							"02"
						);
						break;
					case this.getI18nText("validar", {}):
						oController.doSave("01", "");
						break;
					case this.getI18nText("rechazar", {}):
						oController.doSave("02");
						break;
					// case "Actualizar":
					// 	this.doChangeStatus(
					// 		this.getI18nText("actuAccion", {}),
					// 		this.getI18nText("aceptar", {}),
					// 		"fragment.Comentario",
					// 		"07"
					// 	);
					// 	break;
					case this.getI18nText("guardar", {}):
						oController.doSave("");
						break;
					case this.getI18nText("modifFecha", {}):
						this.doModifyDate();
						break;
					case this.getI18nText("comAudita", {}):
						oController.doSave("05");
						break;
					default:
						break;

					//INI MMM ASE 31/03/2023
				}
			},

			doSave: function (validated) {
				var newData = this.getView().getModel("PlanesCentroDetail").getData();
				var isComAudita = false;
				var model = this.getView().getModel("InfoActionsSet");

				if (validated != undefined && validated != null && validated == "05") {
					isComAudita = true;
				}


				if ((newData.Status == undefined || newData.Status == "") && Utils.isAuditado()) {
					this.showError(this.getI18nText("adv", {}), this.getI18nText("selectEstado", {}));
					return;
				}


				var status;
				if (Utils.isAuditor()) {
					status = newData.ActualStatus;
				} else {
					status = newData.Status;
				}


				//Comprobaciones de fechas
				if (!isComAudita) var text;
				if (validated === "01") {
					text = this.getI18nText("validAccion", {});
				} else if (validated === "02") {
					text = this.getI18nText("rechaAccion", {});
				} else {
					if (validated === undefined || validated == null)
						validated = newData.Validated;
					text = this.getI18nText("guardarCambios", {});
				}

				this._oDialogStatus = sap.ui.xmlfragment(
					"ZPA_PLANESACCI.view.fragment.Save",
					this
				);
				this.getView().addDependent(this._oDialogStatus);

				var oData = {
					Text: text,
					Validated: validated,
				};

				var oModel = new sap.ui.model.json.JSONModel(oData);
				this._oDialogStatus.setModel(oModel, "SaveDialogModel");
				this._oDialogStatus.open();
			},
			onSave: function () {
				var newData = this.getView().getModel("PlanesCentroDetail").getData();
				//INI MMM ASE 31/03/2023
				var newData2 = this.getView().getModel("DetailGet").getData();
				//FIN MMM ASE 31/03/2023

				var validated = this._oDialogStatus
					.getModel("SaveDialogModel")
					.getData().Validated;

				var entity = {};
				var notesArray = [];

				entity.Validated = validated;
				entity.Verified = newData.Verified;
				entity.ActionKey = newData.ActionKey;
				//INI MMM ASE 31/03/2023
				//INI MMM 04/04/2023
				//EN EL CASO DE AUDITOR SE GUARDA EL ESTADO DE LA IZQUIERDA
				//EN EL CASO DE AUDITADO SE GUARDA EL ESTADO DE LA DERECHA
				if(Utils.isAuditado()){
					//entity.Status = newData2.Status;
					//INI MMM 05/04/2023
					entity.Status = this._byId('estadoSelect').getSelectedKey();
					//FIN MMM 05/04/2023
					
				}else{
					entity.Status = newData.Status;	
				}
				
				entity.Deadline = newData2.Deadline;
				//INI MMM 04/04/2023
				//FIN MMM ASE 31/03/2023
				
				// entity.ZzViewAudited = newData.ZzViewAudited;
				// entity.ZzViewAuditor = newData.ZzViewAuditor;
				entity.Autho = newData.Autho;
				//INI MMM ASE 30/03/2023
				entity.InfoAccessListDeep = this.getInfoAccessListDeep(this.getView().getModel('AccessListDetail').getData());
				//FIN MMM ASE 30/03/2023
				entity.InfoThemesDeep = this.getDeepThemesData(this._byId("comboFilter").getSelectedKeys());

					notesArray.push({
						ActionKey: newData.ActionKey,
						Text: newData.Commentary,
						Status: newData.Status,
					});

				//Guardamos
				models.savePlanAccion(this, entity, notesArray);
			},
			doChangeStatus: function (title, textEstado, typeFragment, estado) {
				//ASEASE
				this._oDialogStatus = sap.ui.xmlfragment(
					"ZPA_PLANESACCI.view." + typeFragment,
					this
				);
				this.getView().addDependent(this._oDialogStatus);
				this._byId("titleDialog").setText(title);
				this._byId("BegindButton").setText(textEstado);
				var oData = {
					CodeEstado: estado,
					Comentario: "",
					typFrag: typeFragment,
				};

				var oModel = new sap.ui.model.json.JSONModel(oData);
				this._oDialogStatus.setModel(oModel, "StatusDialogModel");
				this._oDialogStatus.open();
			},

			onPressComent: function (oEvent) {
				//INI MMM ASE 31/03/2023
				var coment = this._oDialogStatus.getModel("StatusDialogModel").getData().Comentario;
				var newData = this.getView().getModel("PlanesCentroDetail").getData();
				var typeFragment = this._oDialogStatus.getModel("StatusDialogModel").getData().typFrag;
				var status = this._oDialogStatus.getModel("StatusDialogModel").getData().CodeEstado;
				//INI MMM 04/04/2023
				var newData2 = this.getView().getModel("DetailGet").getData();
				//FIN MMM 04/04/2023
				//FIN MMM ASE 31/03/2023
				if (coment != undefined && coment != "") {
					/** Guardamos **/
					var entity = {};
					var notesArray = [];

					//Cargamos los datos del plan de acción
					entity.Validated = "00";
					entity.Verified = "00";
					entity.ActionKey = newData.ActionKey;
					entity.Status = status;
					//INI MMM 04/04/2023
					entity.Deadline = newData2.Deadline;
					//FIN MMM 04/04/2023
					entity.Autho = false;
					//INI MMM ASE 30/03/2023
					entity.InfoAccessListDeep = this.getInfoAccessListDeep(this.getView().getModel('AccessListDetail').getData());
					entity.InfoThemesDeep = this.getDeepThemesData(this._byId("comboFilter").getSelectedKeys());
					//FIN MMM ASE 30/03/2023

					if (typeFragment == "fragment.OkKoAprobar") {
						var strOk = this._oDialogStatus
							.getModel("StatusDialogModel")
							.getProperty("/SelectedProduct");

						if (strOk == "") {
							this.showError(
								this.getI18nText("adv", {}),
								this.getI18nText("verifOblig", {})
							);
							return;
						}
						entity.Verified = strOk == "ok" ? "01" : "02";
					}

					

					notesArray.push({
						ActionKey: newData.ActionKey,
						Text: coment,
						Status: status,
					});

					//INI MMM 05/04/2023
					//El orden es importante para la llamada recursiva del models
					notesArray.push({
						ActionKey: newData.ActionKey,
						Text: newData.Commentary,
						Status: newData.Status,
					});
					//FIN MMM 05/04/2023

					//Guardamos
					models.savePlanAccion(this, entity, notesArray);
				} else {
					this.showError(
						//INI MMM ASE 31/03/2023
						this.getI18nText("adv", {}),
						this.getI18nText("comentOblig", {})
						//FIN MMM ASE 31/03/2023
					);
				}
			},

			getInfoAccessListDeep: function (data) {
				var oData = [];
				var selectedItems = data.length;
				for(let i=0;i<selectedItems;i++){
					oData.push({Id: data[i].UserId });
				}
				return oData;
			},

			getInfoThemesListDeep: function () {
				var listaThemes = sap.ui
					.getCore()
					.byId("planesDetailEditable")
					.oTagCloud.oPanel.getContent();
				var InfoThemesList = [];

				$.each(listaThemes, function (i, n) {
					var themeText = n.getProperty("text");
					//oEvent.getSource().getAggregation("customData")[0].getProperty("text")
					$.each(
						sap.ui.getCore().getModel("temasModel").getData().results,
						function (i, n) {
							if (n.Theme == themeText) {
								InfoThemesList.push({ Key: n.Key });
								return false;
							}
						}
					);
				});

				return InfoThemesList.length > 0 ? InfoThemesList : [{}];
			},

			doModifyDate: function () {
				this._oDialogStatus = sap.ui.xmlfragment(
					"ZPA_PLANESACCI.view.fragment.ModifyDate",
					this
				);
				this.getView().addDependent(this._oDialogStatus);
				var oData = {
					Comentario: "",
					Fecha: "",
				};

				var oModel = new sap.ui.model.json.JSONModel(oData);
				this._oDialogStatus.setModel(oModel, "ModifyDateDialogModel");
				this._oDialogStatus.open();
			},
			onModifyDate: function () {

				var coment = this._oDialogStatus
					.getModel("ModifyDateDialogModel")
					.getProperty("/Comentario");

				var fecha = this._oDialogStatus
					.getModel("ModifyDateDialogModel")
					.getProperty("/Fecha");

				if (coment == undefined || coment == "") {
					this.showError(
						this.getI18nText("Advertencia", {}),
						this.getI18nText("ComentarioObligatorio", {})
					);
				} else if (fecha === "") {
					this.showError(
						this.getI18nText("Advertencia", {}),
						this.getI18nText("FechaDeVencimientoObligatoria", {})
					);
				} else {
					/** Guardamos **/
					var entity = {};
					var notesArray = [];
					var newData = this.getView().getModel("PlanesCentroDetail").getData();

					//Cargamos los datos del plan de acción
					entity.Validated = "00";
					entity.Overdue = "false";
					entity.Verified = newData.Verified;
					entity.ActionKey = newData.ActionKey;
					entity.Status = newData.ActualStatus;
					entity.Deadline =
						fecha.substring(6, 10) +
						fecha.substring(3, 5) +
						fecha.substring(0, 2);
					entity.Autho = newData.Autho;
					//INI MMM ASE 30/03/2023
					entity.InfoAccessListDeep = this.getInfoAccessListDeep(this.getView().getModel('AccessListDetail').getData());
					entity.InfoThemesDeep = this.getDeepThemesData(this._byId("comboFilter").getSelectedKeys());
					//FIN MMM ASE 30/03/2023

					notesArray.push({
						ActionKey: newData.ActionKey,
						Text: coment,
						Status: newData.ActualStatus,
					});

					notesArray.push({
						ActionKey: newData.ActionKey,
						Text: newData.Commentary,
						Status: newData.ActualStatus,
					});

					//Guardamos
					models.savePlanAccion(this, entity, notesArray );

				}
			},
			onBack: function () {

				

				var model = this.getView().getModel("InfoActionsSet");
				if (this.Action == "PlanesDetail") {
					if (Utils.isAuditado()) {
						this.Action = "PlanesCentroAuditado";
					} else {
						this.Action = "PlanesCentroAuditor";
					}
				} else if (this.Action == "PlanesTemaDetail") {
					//INI MMM ASE 16/03/2023
					if (Utils.isAuditado()) {
						this.Action = "PlanesTemaAuditado";
					} else {
						this.Action = "PlanesTemaAuditor";
					}
					//FIN MMM ASE 16/03/2023
				}
				this._createFragment();
				//this.restoreFilters();
			},
			onCloseComent: function () {
				this._oDialogStatus.close();
				this._oDialogStatus.destroy();
				this._oDialogStatus = "";
			},
			formatDate: function (oDate) {
				var oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
					pattern: "dd/MM/yyyy",
				});
				return oDateFormat.format(oDate);
			},
			formatFinalDate: function (oDate) {
				var dateString = oDate;
				var day = dateString.substring(0, 2);
				var month = dateString.substring(2, 4);
				var year = dateString.substring(4, 8);
				var date = (day +'/'+month+'/'+year);
				
				
				return date; // Output: 00/00/0000
				

			},

			formatDateComment: function (oDate) {
				var oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
					pattern: "dd/MM/yyyy hh:mm:ss",
				});
				return oDateFormat.format(oDate);
			},

			_onObjectMatched: function (oEvent) { },

			_createFooter: function (estado) {
				var btnPlanificar, btnObsoletoDesestimado, btnComunicarAuditado, btnModifDate, btnValidar, btnRechazar, btnFinalizar, btnGuardar;
				var btns = [new sap.m.ToolbarSpacer()];
				var model = this.getView().getModel("PlanesCentroDetail");

				//Creamos los botones
				btnPlanificar = new sap.m.Button({
					text: this.getI18nText("planificar", {}),
					press: this.doAction.bind(this)
				});
				btnObsoletoDesestimado = new sap.m.Button({
					text: this.getI18nText("obsoleto", {}),
					press: this.doAction.bind(this)
				});
				btnComunicarAuditado = new sap.m.Button({
					text: this.getI18nText("comAudita", {}),
					press: this.doAction.bind(this)
				});
				btnModifDate = new sap.m.Button({
					text: this.getI18nText("modifFecha", {}),
					press: this.doAction.bind(this)
				});
				btnValidar = new sap.m.Button({
					text: this.getI18nText("validar", {}),
					press: this.doAction.bind(this)
				});
				btnRechazar = new sap.m.Button({
					text: this.getI18nText("rechazar", {}),
					press: this.doAction.bind(this)
				});
				btnFinalizar = new sap.m.Button({
					text: this.getI18nText("completar", {}),
					press: this.doAction.bind(this)
				});
				btnGuardar = new sap.m.Button({
					text: this.getI18nText("guardar", {}),
					press: this.doAction.bind(this)
				});

				if (Utils.isAuditor() && (this.getView().getModel("PlanesCentroDetail").getProperty("/Validated") == "01" || this.getView().getModel("PlanesCentroDetail").getProperty("/Validated") == "00" || this.getView().getModel("PlanesCentroDetail").getProperty("/Validated") == ""
					|| this.getView().getModel("PlanesCentroDetail").getProperty("/Validated") == "04" || this.getView().getModel("PlanesCentroDetail").getProperty("/Validated") == "05")) {
					switch (estado) {
						case "04": //"En Estudio":
							if (this.getView().getModel("PlanesCentroDetail").getProperty("/Overdue") == "true") {
								btns.push(btnPlanificar, btnObsoletoDesestimado, btnComunicarAuditado, btnModifDate);
							} else {
								btns.push(btnPlanificar, btnObsoletoDesestimado, btnComunicarAuditado);
							}

							break;
						case "01": //"Planificado":
							if (this.getView().getModel("PlanesCentroDetail").getProperty("/Overdue") == "true") {
								btns.push(btnFinalizar, btnObsoletoDesestimado, btnComunicarAuditado, btnModifDate);
							} else {
								btns.push(btnFinalizar, btnObsoletoDesestimado, btnComunicarAuditado);
							}
							break;
						case "03": //"Obsoleto":
							break;
						case "02": //"Completo/Finalizado":
							if (this.getView().getModel("PlanesCentroDetail").getProperty("/Validated")) {
								btns.push(btnPlanificar);
							}
							break;
						case "06": //"Verificado":
							break;
						case "05": //"Riesgo Aceptado":
							break;
						case "07": //"Actualizado":
							break;
						default:
							break;
					}

					if (this.getView().getModel("PlanesCentroDetailSet").getProperty("/Validated") !== "01") {
						btns.push(btnGuardar);
					}

				} else if (Utils.isValidator(model) && this.getView().getModel("PlanesCentroDetailSet") && this.getView().getModel("PlanesCentroDetailSet").getProperty("/Validated") == "03") {
					btns.push(btnValidar);
					btns.push(btnRechazar);
				} else if (Utils.isAuditado() && this.getView().getModel("PlanesCentroDetailSet") && this.getView().getModel("PlanesCentroDetailSet").getProperty("/Validated") != "03") {
					btns.push(btnGuardar);
				} else if (Utils.isAuditor()) {
					btns.push(btnGuardar);
				}
				//Creamos y bindeamos la toolbar 
				var toolbar = new sap.m.Toolbar({
					id: "footerTabs",
					with: "100%",
					heigth: "80px",
					content: btns
				});
				this.byId("PlanesPageAcci").setFooter(toolbar);
			},
			getStatus: function() {
				var currStatus =  this.getView().getModel("PlanesCentroDetailSet").getData().Status;
				var possibleStatus = [];
				var controller = this;
						
				switch(currStatus){
					case "":
						break;
					case "01": // Planificado
						if(Utils.isAuditor())
							possibleStatus = this.getStatusValues(["01","02","03","04","05","07"]);
						else
							possibleStatus = this.getStatusValues(["01","02","03","05"]);
						break;
					case "02": // Finalizado
						if(Utils.isAuditor())
							possibleStatus = this.getStatusValues(["01","02","03","04","05","07"]);
						break;
					case "03": // Obsoleto
						//possibleStatus = getStatusValues(["01","03","05"]);
						break;
					case "04": // En estudio
						if(Utils.isAuditor())
							possibleStatus = this.getStatusValues(["01","02","03","04","05","07"]);
						else
							possibleStatus = this.getStatusValues(["04","01","03","05"]);
						break;
					case "05": // Se asume el riesgo
						//possibleStatus = getStatusValues(["01","03","05"]);
						break;
					case "06": // Verificado
						//possibleStatus = getStatusValues(["01","03","05"]);
						break;
					case "07": // Actualizado
						//possibleStatus = getStatusValues(["01","03","05"]);
						break;
					default:
						break;
				}
				
				var model = new sap.ui.model.json.JSONModel();
				model.setData(possibleStatus);
				this.getView().setModel(model, "StatusObj");
				//return model;
			},

			getStatusValues: function(statusArray) {
				var items = [];
				var that = this;
				
				$.each(statusArray, function(i,n){
					$.grep(that.getView().getModel('statusPlModel').getData().results, function(e){ 
						if(e.Status == n) {
							items.push(e);
							return;
						} else {
						}
					});
				});
				
				return items;
			},

			showError: function (title, message) {

				var dialog = new sap.m.Dialog({
					title: title,
					type: 'Message',
					content: new sap.m.Text({
						text: message
					}),
					state: sap.ui.core.ValueState.Warning,
					beginButton:
						new sap.m.Button({
							text: this.getI18nText("aceptar", {}),
							press: function () {
								dialog.close();
							}
						}),
					afterClose: function () {
						dialog.destroy();
					}
				});

				dialog.open();

			},
			getDeepThemesData :function(aKeys){
				var InfoThemesList = [];

				for (let i = 0; i < aKeys.length; i++) {
					const element = aKeys[i];
					InfoThemesList.push({Key: element });
				}
				return InfoThemesList;
			},

			//INI MMM 17/03/2023
			onSort: function() {
				this._showPersonalizationSections("Sort");
			},
			onFilter: function() {
				this._showPersonalizationSections("Filter");
			},
			onGroup: function() {
				this._showPersonalizationSections("Group");
			},
			onColumns: function() {
				this._showPersonalizationSections("Columns");
			},

			_showPersonalizationSections: function(sSectionName){
				if (this.Action == "PlanesCentroAuditado" || this.Action == "PlanesCentroAuditor") {
					var oSmartTable = this._byId("smartTableCentro");
				}else{
					var oSmartTable = this._byId("smartTableTema");
				}
				
				oSmartTable.openPersonalisationDialog(sSectionName);
			},
			//FIN MMM 17/03/2023
			onSelectFile : function(oEvent) {
				Utils.onFileSelected(oEvent);
			},
			
			onBeforeUploadStarts: function(oEvent) {
			},
			
			onUploadComplete: function(oEvent) {
				console.log("\t\tUpload Complete:");
			},
			
			onUploadTerminated: function(oEvent) {
				console.log("\t\tUpload terminado:");
			},
			
			onFileDeleted: function(oEvent) {
				console.log("\t\tFile deleted:");
			},

			//INI MMM  29/03/2023
			addListAcces: function (){
				// //var ctrl = this;
				// if(sap.ui.getCore().getComponent('searchComponentListaAcceso')) {
				// 	sap.ui.getCore().getComponent('searchComponentListaAcceso').destroy();
				// }
				
				// var oSearchCenterComp  = sap.ui.getCore().createComponent({
				// 	id: "searchComponentListaAcceso",
				// 	name: "searchComponentPlanes"
				// });
				
				// // Función de añadir resultados a las tablas
				// var addFunct = function() {
				// 	var selItems = this.getParent().getContent()[1].getSelectedItems();
					
				// 	if(selItems.length == 0) { 
				// 		this.showError("Usuario no valido", "Seleccione al menos una opción");
				// 	}
				// 	else {
				// 		var bindingContext = selItems[0].getBindingContext().sPath;
				// 		var newEntry =  sap.ui.getCore().getModel("personas").getProperty(bindingContext).UserId;
				// 		var array = sap.ui.getCore().byId("planesDetailEditable").table.getItems();
				// 		var detectRepeatedEntry = function(newEntry, array) {
				// 			var i = 0;
				// 			while(i < array.length){
				// 				if(newEntry === array[i].getAggregation("cells")[0].getProperty("text")){
				// 					return true;
				// 				}
				// 				i++;
				// 			}
				// 			return false;
				// 		}
						
				// 		if(!detectRepeatedEntry(newEntry, array)){
							
				// 			sap.ui.getCore().byId("planesDetailEditable").table.addItem(
				// 				new sap.m.ColumnListItem({
				// 					cells:[
				// 							new sap.m.Label({ text: sap.ui.getCore().getModel("personas").getProperty(bindingContext).UserId,
				// 							editable:true,}),
				// 							new sap.m.Label({ text: sap.ui.getCore().getModel("personas").getProperty(bindingContext).FullName,
				// 								editable:true,})
				// 							],
				// 					customData: new sap.ui.core.CustomData({
				// 						key : "key",
				// 						value : sap.ui.getCore().getModel("personas").getProperty(bindingContext).UserId})
				// 					})	
				// 			);
				// 			this.getParent().close();
				// 		}else{
				// 			this.showError(planesAccionUtils.oBundle.getText("usuExist"), planesAccionUtils.oBundle.getText("usuRepetido"));
				// 		}
				// 	}};
					
		
				// 	var addSearchFunct = function(){
				// 		//Agafo el valor del serchfield
				// 		var text = "*" +  this.getParent().getContent()[0].getProperty("value") + "*";
						
				// 		if(text != ""){
				// 			  //Preparo els filtres amb els valors
				// 			  var aFilters = [];
				// 			  aFilters.push(new sap.ui.model.Filter("FullName",sap.ui.model.FilterOperator.EQ,text.toUpperCase()));
				// 			  getUsersLdap(aFilters);
				// 			  sap.ui.getCore().getComponent('searchComponentListaAcceso').table.setModel(sap.ui.getCore().getModel("personas"));
				// 		}
				// 	 }
		
					
				// // Cabecera, Binding Posiciones, Modo de Lista, Binding Aggregation, Path, Model, AddFunction
				// oSearchCenterComp.setupInicial(planAcc.tableCols.buscarPersonas, planAcc.tableCels.buscarPersonas, "SingleSelect", "", "/results", "", addFunct,addSearchFunct);
				
				// // Se crea un contenedor para el componente
				// var oCompCont = new sap.ui.core.ComponentContainer({
				// 	 component: oSearchCenterComp,
				// });
				// llamamos al fragment CreditInvoice
				this._oDialogStatus = sap.ui.xmlfragment(
					"ZPA_PLANESACCI.view.fragment.AccessList",
					this
				);
				this.getView().addDependent(this._oDialogStatus);

				var oData = {
					// Text: text,
					// Validated: validated,
				};

				var oModel = new sap.ui.model.json.JSONModel(oData);
				this._oDialogStatus.setModel(oModel, "AccessListModel");
				this._oDialogStatus.open();


				// this._oDialogStatus.close();
				// this._oDialogStatus.destroy();
				// this._oDialogStatus = "";
			
			},

			onSearchAccessList: function (){
				if(this.getView().getModel("SearchValue").getData().AccessListSearch){
					var searchName = "*"+this.getView().getModel("SearchValue").getData().AccessListSearch+"*";
					models.loadAccessList(this, searchName);
				}
			},
			//FIN MMM ASE 29/03/2023
			//INI MMM ASE 30/03/2023
			onAddComent: function(oEvent){
				var selectedItems = this._byId("tableAccessList").getSelectedItems().length;
				var oData = []
				for(let i=0;i<selectedItems;i++){
					oData.push(this._byId("tableAccessList").getSelectedContexts()[i].getObject());
				}
				var oModel = new sap.ui.model.json.JSONModel(oData);
				this.getView().setModel(oModel, "AccessListDetail");

				this._oDialogStatus.close();
				this._oDialogStatus.destroy();
				this._oDialogStatus = "";

			},
			//FIN MMM ASE 30/03/2023
			//INI MMM ASE 19/04/2023
			onDescargaAmpliada: function(oEvent){
				var ObjectType;
				var filters = [];
				var sorters;
				if (this.Action == "PlanesCentroAuditado" || this.Action == "PlanesCentroAuditor") {
					ObjectType = "ZACTP";
					filters = this._byId("smartTableCentro").getTable().getBinding("items").aApplicationFilters;
					sorters = this._byId("smartTableCentro").getTable().getBinding("items").aSorters;
				} else if (this.Action == "PlanesTemaAuditado" || this.Action == "PlanesTemaAuditor") {
					ObjectType = "ZACTT";
					filters = this._byId("smartTableTema").getTable().getBinding("items").aApplicationFilters;
					sorters = this._byId("smartTableTema").getTable().getBinding("items").aSorters;
					//INI MMM ASE 24/04/2023
					if(this._byId("smartFilterBar").getFilters().length > 0){
						let i=0;
						for(i;i<this._byId("smartFilterBar").getFilters()[0].aFilters.length;i++){
							filters.push(this._byId("smartFilterBar").getFilters()[0].aFilters[i]);
						}
						
					}
					//FIN MMM ASE 24/04/2023
				}
				//INI MMM ASE 20/04/2023
				//FIN MMM ASE 20/04/2023
				models.createExportJob( this, filters, sorters, ObjectType);
			},
			//FIN MMM ASE 19/04/2023
			// IRC 16/06/2023
			_getDataFromEntity: function(sEntity,sId) {
				let aData = this.getView().getModel(sEntity).getData();
				var oModel = new sap.ui.model.json.JSONModel();
				for (let index = 0; index < aData.results.length; index++) {
					const element = aData.results[index];
					if(element.Id === sId) oModel.setData(element);
					
				}
				return oModel;
			},
				//INI ASEASE 18/07/2023
				//Se ejecutan los filtros pre llamada Auto ASEASE PPM100032267 INI
			saveFilters: function(){
				var filters = [];
				var sorters;

				if (this.Action == "PlanesCentroAuditado" || this.Action == "PlanesCentroAuditor") {
					filters = this._byId("smartTableCentro").getTable().getBinding("items").aApplicationFilters;
					sorters = this._byId("smartTableCentro").getTable().getBinding("items").aSorters;

					localStorage.setItem("filtrosCentro", JSON.stringify(filters));
					localStorage.setItem("ordenacionesCentro", JSON.stringify(sorters));

				} else if (this.Action == "PlanesTemaAuditado" || this.Action == "PlanesTemaAuditor") {
					filters = this._byId("smartTableTema").getTable().getBinding("items").aApplicationFilters;
					sorters = this._byId("smartTableTema").getTable().getBinding("items").aSorters;

					localStorage.setItem("filtrosTema", JSON.stringify(filters));
					localStorage.setItem("ordenacionesTema", JSON.stringify(sorters));
			}
		},
		//Se ejecutan los filtros pre llamada Auto ASEASE PPM100032267 FIN


		
		});
	}
);

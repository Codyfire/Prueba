sap.ui.define(["sap/m/MessageBox"], function (MessageBox) {
	"use strict";

	return {

		_showMsg: function (text) {
			sap.m.MessageToast.show(text, { duration: 800 });
		},
		/**
		 * Realiza la conversión y descarga de un documento pasado en string base64.
		 * @param base64 :		Documento convertido a un string en formato base64 (obligatorio)
		 * @param name :		Nombre del documento con o sin extension (obligatorio)
		 * @param extension :	Extension del documento (solo obligatorio si 'name' viene sin extension)
		 */
		downloadBase64: function (base64, name, extension) {
			if (!extension) {
				extension = name.substr(name.lastIndexOf(".") + 1);
				name = name.substr(0, name.lastIndexOf("."));
			}
			var byteArray = this.base64ToArrayBuffer(base64);
			var blob = new Blob([byteArray], {
				type: "application/" + extension
			});
			// IE hack; see http://msdn.microsoft.com/en-us/library/ie/hh779016.aspx
			if (window.navigator.msSaveBlob) {
				window.navigator.msSaveOrOpenBlob(blob, name + "." + extension);
			} else {
				var blobUrl = URL.createObjectURL(blob);
				var pom = document.createElement("a");
				pom.setAttribute("href", blobUrl);
				pom.setAttribute("download", name + "." + extension);
				pom.click();
			}
		},

		/**
		 * Convierte un string en base64 a un array de bytes.
		 */
		base64ToArrayBuffer: function (base64) {
			var binaryString = window.atob(base64);
			var len = binaryString.length;
			var bytes = new Uint8Array(len);
			for (var i = 0; i < len; i++) {
				bytes[i] = binaryString.charCodeAt(i);
			}
			return bytes.buffer;
		},
		// this fucntion remove a js or css from the DOM
		removejscssfile: function (filename, filetype, appname) {
			var targetelement = (filetype === "js") ? "script" : (filetype === "css") ? "link" : "none"; //determine element type to create nodelist from
			var targetattr = (filetype === "js") ? "src" : (filetype === "css") ? "href" : "none"; //determine corresponding attribute to test for
			var allsuspects = document.getElementsByTagName(targetelement);
			for (var i = allsuspects.length; i >= 0; i--) { //search backwards within nodelist for matching elements to remove
				if (allsuspects[i] && allsuspects[i].getAttribute(targetattr) !== null &&
					allsuspects[i].getAttribute(targetattr).indexOf(filename) !== -1 &&
					allsuspects[i].getAttribute(targetattr).indexOf(appname) !== -1) {
					allsuspects[i].parentNode.removeChild(allsuspects[i]); //remove element by calling parentNode.removeChild()
				}
			}
		},
		// This functiion calls for logout when the user is iddle for 30 minutes in the app.
		manageInactivityTime: function () {
			// Reset count initially
			this.resetCount();
			var that = this;
			// Resets count on click event
			document.onclick = function () {
				that.resetCount();
			};
			// Resets count on key press event
			document.onkeypress = function () {
				that.resetCount();
			};
		},
		// This function resets the idle count
		resetCount: function () {
			//Clear count
			jQuery.sap.clearDelayedCall(this.delayedCallId);
			// Start Count
			//2.700.000ms = 45 m
			this.delayedCallId = jQuery.sap.delayedCall(2700000, window, function () {
				MessageBox.alert("Connection expired due to inactivity. Redirecting to Fiori Login Page.", {
					icon: MessageBox.Icon.WARNING,
					title: "Warning",
					onClose: function (sResult) {
						if (sResult === MessageBox.Action.OK) {
							// After OK of user, call logout of Fiori.
							sap.ushell.Container.logout();
						}
					}
				});
			});
		},
		// Función validación de fecha
		// @params		oElement: Elemento a validar
		//              that: contexto, para poder obtener Maestros JSON
		parseExact: function (oElement, that) {

			var sDay, sMonth, sYear, aDate, oDate, maxDays, bBisiesto;
			var oRegExp = /^(\d{2})([\/]\d{2})([\/]\d{4})?$/m;
			var oDaysOfMonth = that.getMaestrosModel().getData().DaysOfMonth;
			var sType = oElement.getMetadata().getName();
			var datevalue = oElement.getValue();

			// Format validation
			switch (sType) {
				case "sap.m.DatePicker":

					sYear = datevalue.substring(0, 4);
					sMonth = datevalue.substring(4, 6);
					sDay = datevalue.substring(6, 8);
					maxDays = oDaysOfMonth[sMonth];
					bBisiesto = ((sYear % 4) === 0) ? true : false;

					if (bBisiesto && (sMonth === "02")) {
						maxDays = parseInt(maxDays, 10) + 1;
					}

					if ((maxDays === undefined) || (sDay > maxDays) || (sDay <= 0) || (sYear === undefined)) {

						// wrong date.
						oElement.setValueState("Error");
						oElement.setValueStateText("Wrong date.");
						oElement.setShowValueStateMessage(true);
						return false;

					}
					return true;
					break;

				case "sap.m.DateRangeSelection":
					var sDateFrom, sDateTo;

					var aRange = datevalue.split("-");
					sDateFrom = aRange[0].trim();

					//Se comprueba que se ha introducido un rango completo
					if (aRange[1]) {
						sDateTo = aRange[1].trim();

						// Se comprueba que se ha introducido el formato dd/mm/yyyy correcto
						if (!(oRegExp.test(sDateFrom)) && !(oRegExp.test(sDateTo))) {
							// wrong date.
							oElement.setValueState("Error");
							oElement.setValueStateText("Wrong range.");
							oElement.setShowValueStateMessage(true);
							return false;
						}
					} else {
						// wrong date format.
						oElement.setValueState("Error");
						oElement.setValueStateText("Wrong date format.");
						oElement.setShowValueStateMessage(true);
						return false;
					}

					// Llegando a esta línea el rango es correcto asi como los formatos de fecha.
					aDate = sDateFrom.split("/");

					for (var fecha in aRange) {

						aDate = aRange[fecha].trim().split("/");
						sDay = aDate[0];
						sMonth = aDate[1];
						sYear = aDate[2];
						maxDays = oDaysOfMonth[sMonth];
						bBisiesto = ((sYear % 4) === 0) ? true : false;

						if (maxDays) {
							// Calculamos la validez de la fecha
							if (bBisiesto && (sMonth === "02")) {
								maxDays = parseInt(maxDays, 10) + 1;
								if ((sDay > maxDays) || (sDay <= 0)) {
									// wrong day.
									oElement.setValueState("Error");
									oElement.setValueStateText("Wrong day.");
									oElement.setShowValueStateMessage(true);
									return false;
								}
							} else {
								if ((sDay > maxDays) || (sDay <= 0)) {
									// wrong day.
									oElement.setValueState("Error");
									oElement.setValueStateText("Wrong day.");
									oElement.setShowValueStateMessage(true);
									return false;
								}
							}
						} else {
							// wrong month.
							oElement.setValueState("Error");
							oElement.setValueStateText("Wrong month.");
							oElement.setShowValueStateMessage(true);
							return false;
						}
					}
					return true;
					break;
				default:
					return true;
					break;
			}
		},
		// Funcion generica para poner el modelo filtrado a un combo o a una tabla en las ayudas de búsqueda
		_bindElement: function (oParams) {
			// Guardamos los valores en variables separadas
			var sOdata = oParams.Odata;
			var sServicio = oParams.Servicio;
			var sIdElement = oParams.Id;
			var sTipo = oParams.Tipo;
			var aFilters = oParams.Filters;

			// Recuperamos el objeto
			var oElement = this._byId(sIdElement);

			// Ponemos el primer filtro
			var aFilter = [];
			// Ponemos los demas filtros si llegaran
			if (aFilters.length !== 0) {
				for (var i = 0; i < aFilters.length; i++) {
					aFilter.push(aFilters[i]);
				}
			}

			switch (sTipo) {
				case "Combo":
					// Eliminamos los datos seleccionados del combo
					oElement.setValue("");
					oElement.setSelectedKey("");
					// Cargamos el combo
					oElement.bindItems({
						path: sOdata + ">/" + sServicio,
						filters: aFilter,
						template: new sap.ui.core.ListItem({
							key: "{" + sOdata + ">" + oParams.Key + "}",
							text: "{" + sOdata + ">" + oParams.Text + "}"
						})
					});

					// Ponemos valor por defecto
					if (oParams.Default) {
						oElement.setSelectedKey(oParams.Default);
						oElement.setEnabled(false);
					}
					break;
				case "List":
					// Cargamos la lista
					oElement.bindItems({
						path: sOdata + ">/" + sServicio,
						filters: aFilter,
						template: new sap.m.StandardListItem({
							info: "{" + sOdata + ">" + oParams.Key + "}",
							title: "{" + sOdata + ">" + oParams.Text + "}"
						})
					});
					break;
			}
		},
		/**
		 * Limpia el combo que se le pasa o lo inhabilita segun el punto en que se llame a la función
		 * @param		oElement - combo a limpiar/inhabilitar
		 *				sAction - clear / disable / enable / all
		 */
		clearCombo: function (oElement, sAction) {

			switch (sAction) {
				case "clear":
					oElement.setSelectedKey("");
					break;
				case "disable":
					oElement.setEnabled(false);
					break;
				case "enable":
					oElement.setEnabled(true);
					break;
				case "all":
					oElement.setSelectedKey("");
					oElement.setEnabled(false);
					break;
				default:
					break;
			}

		},
		/**
		* Convierte un objeto en un array de objetos. Mismo funcionalidad que Object.values() pero éste sí funciona en IE.
		* @param data : objeto
		*/
		_objectValues: function (data) {
			var aData = [];
			for (var key in data) {
				aData.push(data[key]);
			}
			return aData;
		},
		/**
		* Función que genera un array de objetos dado un array y una clave
		*/
		_generateObjectArray: function (aArray, oKey) {
			var oObject = {};
			for (var i in aArray) {
				var newKey = aArray[i][oKey];
				if (!oObject[newKey]) {
					oObject[newKey] = aArray[i];
				}
			}
			return oObject;
		},

		/**
		 * Función que elimina los duplicados de un array, dada su clave
		 */
		_deleteDuplicate: function (aArray, oKey) {
			var oObject = {};
			var aNewArray = [];
			for (var i in aArray) {
				var newKey = aArray[i][oKey];
				if (!oObject[newKey]) {
					oObject[newKey] = aArray[i];
					aNewArray.push(oObject[newKey]);
				}
			}
			return aNewArray;
		},

		_convertKey: function (base64_text) {
			var output = this.base64_decode(base64_text);
			var separator = "";
			var hexText = "";
			for (var i = 0; i < output.length; i++) {
				hexText = hexText + separator + (output[i] < 16 ? "0" : "") + output[i].toString(16);
			}

			//console.log(hexText);
			hexText = hexText.toUpperCase();
			return hexText;
		},
		base64_decode: function (input) {
			var keyStr = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
			var output = [];
			var chr1, chr2, chr3;
			var enc1, enc2, enc3, enc4;
			var i = 0;

			var orig_input = input;
			input = input.replace(/[^A-Za-z0-9\+\/\=]/g, "");
			if (orig_input != input)
				console.error("Warning! Characters outside Base64 range in input string ignored.");
			if (input.length % 4) {
				console.error("Error: Input length is not a multiple of 4 bytes.");
				return "";
			}

			var j = 0;
			while (i < input.length) {

				enc1 = keyStr.indexOf(input.charAt(i++));
				enc2 = keyStr.indexOf(input.charAt(i++));
				enc3 = keyStr.indexOf(input.charAt(i++));
				enc4 = keyStr.indexOf(input.charAt(i++));

				chr1 = (enc1 << 2) | (enc2 >> 4);
				chr2 = ((enc2 & 15) << 4) | (enc3 >> 2);
				chr3 = ((enc3 & 3) << 6) | enc4;

				output[j++] = chr1;
				if (enc3 != 64)
					output[j++] = chr2;
				if (enc4 != 64)
					output[j++] = chr3;

			}
			// En el caso de que no vengan 16 parejas de datos, se completa con 0's
			if (output.length < 16) {
				output[output.length++] = 0o0;
			}

			return output;
		},


		dec2hex: function (d) {
			var hD = '0123456789ABCDEF';
			var h = hD.substring(d & 15, 1);
			while (d > 15) {
				d >>= 4;
				h = hD.substring(d & 15, 1) + h;
			}
			return h;
		},

		_formatUrl: function (source, params) {

			// source -> String con parametros {0},{1}...
			// params -> Array con los valores ["Hello","World!"]

			// Replace all params in function
			if (params) {
				$.each(params, function (i, n) {
					if (n != undefined && n != null) {
						source = source.replace(new RegExp("\\{" + i + "\\}", "g"), function () {
							return '\'' + n + '\'';
						});
					}
				})
			}

			// Other params will be replace by ''
			source = source.replace(new RegExp("\\{[0-9]+\\}", "g"), function () {
				return '\'\'';
			});

			return source;
		},

		/**
		 * Función qeu devuelve un array ordenado por un valor en concreto ( usa el metodo "sort" del array)
		 */
		_sortArray: function (aArray, oKey) {
			aArray.sort(function (a, b) {
				if (a[oKey] > b[oKey]) { return 1; }
				if (a[oKey] < b[oKey]) { return -1; }
				return 0;
			});
			return aArray
		},
		isValidator: function (oModel) {
			var validator = false
			if (oModel) {
				//INI MODIF DMA 17/07/2023
				//OLD
				//var company = oModel.getData().results[0].ZzAnOrg.substring(0, 5);
				//var department = oModel.getData().results[0].ZzAnOrg.substring(5);
				//NEW
				var company = oModel.getData().ZzAnOrg.substring(0, 5);
				var department = oModel.getData().ZzAnOrg.substring(5);
				//FIN MODIF DMA 17/07/2023
				$.each(sap.ui.getCore().getModel("rol").getData().results, function (i, n) {
					if (n.Department == department && n.Company == company) {
						// IRC 08/11/2023 - Revisar botones en validated 03
						//if (n.Validator == "true") validator = true;
						if (n.Validator === true) validator = true;
					}
				});
			}
			return validator;
		},
		//ASEASE
		isAuditor: function () {
			/*const AUDITOR = "ZSAP_GRCAUD_AUDITOR";
			var array = $.grep(sap.ui.getCore().getModel("rol").getData().results,function(n,i){return n.Rol.indexOf(AUDITOR) === 0});
			return array.length > 0 ? true : false;*/
			/**
			 * INI MOD PPM100084365 - (BPI) - Rol auditor/auditado compatibles en BPI2 23/01/2023				
			 * Código nuevo
			 */
			/*
			var model = oModel;
			if (model && model.getData().results[0].ZzViewAuditor) {
				var auditor = model.getData().results[0].ZzViewAuditor;
				if (auditor) {
					if (auditor === 'true' || auditor === true) {
						return true;
					} else if (auditor === 'false' || auditor === false) {
						return false;
					}
				} else {
					return false;
				}
				//		return data.ZzViewAuditor;
			} else {*/
				const AUDITOR = "ZSAP_GRCAUD_AUDITOR";
				var array = $.grep(sap.ui.getCore().getModel("rol").getData().results, function (n, i) { return n.Rol.indexOf(AUDITOR) === 0 });
				return array.length > 0 ? true : false;
	//		}
			/**
			 * FIN MOD PPM100084365 - (BPI) - Rol auditor/auditado compatibles en BPI2 23/01/2023
			 */

		},
		isAuditado: function () {
			/*const AUDITADO = "ZSAP_GRCAUD_AUDITADO";
			var array = $.grep(sap.ui.getCore().getModel("rol").getData().results,function(n,i){return n.Rol == AUDITADO});
			return array.length > 0 ? true : false;*/
			/**
			 * INI MOD PPM100084365 - (BPI) - Rol auditor/auditado compatibles en BPI2 23/01/2023				
			 * Código nuevo
			 */
			/*
			var model = oModel;
			if (model && model.getData().results[0].ZzViewAudited) {
				var auditado = model.getData().results[0].ZzViewAudited;
				if (auditado) {
					if (auditado === 'true' || auditado === true) {
						return true;
					} else if (auditado === 'false' || auditado === false) {
						return false;
					}
				} else {
					return false;
				}
				//		return data.ZzViewAudited;
			} else {*/
				//INI MMM ASE 30/03/2023
				// while(sap.ui.getCore().getModel("rol")==undefined){

				// }
				//FIN MMM ASE 30/03/2023
				const AUDITADO = "ZSAP_GRCAUD_AUDITADO";
				var array = $.grep(sap.ui.getCore().getModel("rol").getData().results, function (n, i) { return n.Rol == AUDITADO });
				return array.length > 0 ? true : false;	
			//}
			/**
			 * FIN MOD PPM100084365 - (BPI) - Rol auditor/auditado compatibles en BPI2 23/01/2023
			 */
		},
		//INI MMM ASE 21/03/2023
		convertDateTime: function (date) {
			if (date != "") {
				var dat = new Date(date);
				var day = dat.getDate() < 10 ? '0' + dat.getDate() : '' + dat.getDate();
				var month = dat.getMonth() + 1;
				month = month < 10 ? '0' + month : '' + month;
				// Se muestra la hora correcta sin el descuadre (se incrementa una hora a la hora de la creación del registro)
				var hour = dat.getHours() - dat.getTimezoneOffset() / 60 < 10 ? '0' + (dat.getHours() - dat.getTimezoneOffset() / 60) : '' + (dat.getHours() - dat.getTimezoneOffset() / 60);
				var min = dat.getMinutes() < 10 ? '0' + dat.getMinutes() : '' + dat.getMinutes();
				var sec = dat.getSeconds() < 10 ? '0' + dat.getSeconds() : '' + dat.getSeconds();
				return day + "/" + month + "/" + dat.getFullYear() + " " + hour + ":" + min + ":" + sec;
			} else { return ""; }
		},
		//FIN MMM ASE 21/03/2023

		//INI MMM ASE 22/03/2023
		getCurrentUser: function () {
			return sap.ushell.Container.getService("UserInfo").getId();
		},


		onFetchStandardAttachments: function (oContext, objKey, entityType) {
			var that = this;
			return new Promise(function (resolve, reject) {
				var oModel = oContext.getOwnerComponent().getModel("GRCAUD");
				var key = that._convertKey(objKey);
				key = key.substring(0, 8) + "-" + key.substring(8, 12) + "-" + key.substring(12, 16) + "-" + key.substring(16, 20) + "-" + key.substring(20);
				var url = "/" + entityType + "(guid'" + key + "')/WorkPapers";
				oModel.read(url,
					{
						async: false,
						success: function (oData, oDataRes) {
							var data = []; var detailModel = new sap.ui.model.json.JSONModel();
							var dataLength = oData.results.length;
							//INI MMM ASE 14/04/2023
							if (oData.results.length === 0) {
								detailModel.setData(data);
								oContext.getView().setModel(detailModel, "DetailFile")
								resolve();
							}
							//FIN MMM ASE 14/04/2023
							$.each(oData.results, function (i, n) {
								var item = {}; item.CreateBy = n.CreateBy;
								item.CreateByName = n.CreateByName;
								item.CreateTime = n.CreateTime;
								item.Name = n.Name;
								item.DeleteUrl = n.__metadata.uri;
								let url = "/" + n.ServiceURL + "/File";
								oModel.read(url,
									{
										async: false,
										success: function (oData, oDataRes) {
											item.MimeType = oData.MimeTypeKey;
											item.DocId = oData.Key;
											item.Url = window.location.protocol + "//" + window.location.hostname + ":" + window.location.port + oModel.sServiceUrl;
											item.Url += "/FileSet(guid'" + oData.Key + "')/$value"; data.push(item);
											if (i === dataLength - 1) {
												detailModel.setData(data);
												oContext.getView().setModel(detailModel, "DetailFile")
												resolve();
											}
										},
										error: function (oError) {
											alert(that.findErrorMsg(oError.response.body));
										}
									});
							});
						},
						error: function (oError) {
							alert(that.findErrorMsg(oError.response.body));
						}
					});
			});
		},

		findErrorMsg: function (xml) {
			var parseXml = $.parseXML(xml);
			var firstMessage = $(parseXml).find("message")[0];

			return "Error: " + firstMessage.textContent;
		},


		onSaveAttachments: function (key, uploader, entityType) {

			var that = this;

			var conModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZGRCAUD_PORTAL_SRV/", false);
			var conAttachModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/GRCAUD_SRV/", false);

			uploader.setBusy(true);

			var attach2 = uploader._aDeletedItemForPendingUpload;

			if (attach2.length > 0) {
			$.each(attach2, function(i, n) {
				var deleteUrl = "";
				if (n.getAggregation("customData") != null) {
				deleteUrl = n.getAggregation("customData")[0].getProperty("key");
				}
				if (deleteUrl != "") {
				$.ajax({
					method: "DELETE",
					url: deleteUrl,
					async: false,
					beforeSend: function(XMLHttpRequest) {
					XMLHttpRequest.setRequestHeader("x-csrf-token", conModel.getSecurityToken());
					},
					success: function(oData, oDataRes) {
					uploader.setBusy(false);
					},
					error: function(oError) {
					uploader.setBusy(false);
					}
				});
				}
			});
			}

			uploader.setBusy(true);

			var attach = uploader.getAggregation("items");

			if (attach.length > 0) {
			var binKey = this._convertKey(key);
			binKey = binKey.substring(0, 8) + "-" + binKey.substring(8, 12) + "-" + binKey.substring(12, 16) + "-" + binKey.substring(16, 20) + "-" + binKey.substring(20);

			$.each(attach, function(i, n) {
				if (n._status == "pendingUploadStatus") {
				var url = "/CreateDocWorkPaper";
				url += "?Phase=''";
				url += "&Name='" + encodeURIComponent(n.getFileName()) + "'";
				url += "&Entity='" + entityType + "'";
				url += "&ObjectKey=guid'" + binKey + "'";
				url += "&Type='Attachment'";

				conAttachModel.refreshSecurityToken();
				conAttachModel.create(url, null, {
					async: false,
					success: successCreateDocWorkPaper.bind({ item: n }),
					error: errorCreateDocWorkPaper
				});

				function successCreateDocWorkPaper(oEvent) {
					that.onUploadCompleted(oEvent, uploader, this.item);
				};

				function errorCreateDocWorkPaper(error) {
					alert(that.findErrorMsg(error.response.body));
					uploader.setBusy(false);
				};
				}
			});

			that._showMsg("Acci\u00f3n guardada correctamente!");
			uploader.setBusy(false);
			} else {
			that._showMsg("Acci\u00f3n guardada correctamente!");
			uploader.setBusy(false);
			}
		},

		onUploadCompleted: function (oEvent, uploader, item) {

			var that = this;

			var conAttachModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/GRCAUD_SRV/", false);
			var refKey = oEvent.ReferenceKey;
			var url = "/DocWorkPaperSet(guid'" + refKey + "')/File";
			conAttachModel.read(url, {
				async: false,
				success: successDocWorkPaperSet.bind({ item: item }),
				error: errorDocWorkPaperSet
			});
		
			function successDocWorkPaperSet(oEvent) {
				var key = oEvent.Key;
				var url2 = window.location.protocol + "//" + window.location.hostname + ":" + window.location.port + conAttachModel.sServiceUrl + "/FileSet(guid'" + key + "')/$value";
				conAttachModel.refreshSecurityToken();
				var contData = {};
				contData.mime_type = this.item.getAggregation('customData')[0].getValue();
				if (contData.mime_type == "") {
					contData.mime_type = "application/x-www-form-urlencoded";
				}
				contData.value = this.item.getAggregation('customData')[0].getKey();
				contData.value = contData.value.substring(contData.value.indexOf('base64,') + 'base64,'.length);
				$.ajax({
					type: "PUT",
					url: url2,
					data: contData.value,
					contentType: contData.mime_type,
					success: successFileSet,
					error: errorFileSet,
					async: false,
					beforeSend: function (XMLHttpRequest) {
						XMLHttpRequest.setRequestHeader("x-csrf-token", conAttachModel.getSecurityToken());
					},
				});
		
				function successFileSet(oEvent) {
					console.log("TODO OK");
					uploader.setBusy(false);
				};
		
				function errorFileSet(oEvent) {
					alert(that.findErrorMsg(oEvent.response.body));
					uploader.setBusy(false);
				};
			};
		
			function errorDocWorkPaperSet(oEvent) {
				alert(that.findErrorMsg(oEvent.response.body));
				uploader.setBusy(false);
			};
		},

		onFileSelected : function (oEvent) {

			var that = this;

			var uploader = sap.ui.getCore().byId("anexosType2");
			
			var conAttachModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/GRCAUD_SRV/", false);
			var errorMsg = "";
			var found = false;
			var checkItems = uploader.getItems();
			var toCheck = false;
			var files = oEvent.getParameters("files").files;
			$.each(files, function(i,n){
				toCheck = $.grep(checkItems, function(value){
					return value.getFileName() == n.name;
				});
				if(toCheck.length > 0){
					found = true;
					errorMsg = "Nombre de fichero ya existente";
				} else if(n.name.length > 100){
					that.findErrorMsg( that._showMsg("El tama\u00f1o m\u00e1ximo para el nombre de un adjunto es de 100 caracteres ") );
					return;
				}
			});
			if(uploader) {
				$.each(files, function(i,n){
					checkItems = undefined;
					toCheck = false;
					checkItems = uploader.getItems();
					toCheck = $.grep(checkItems, function(value){
						return value.getFileName() == n.name;
					});
					if(toCheck.length > 0){
						found = true;
						errorMsg = "No se puede adjuntar, ya se a\u00f1adi\u00f3 previamente un fichero con el mismo nombre en la alerta";
					}
				});
			}
			if(found) {
				var dialog = new sap.m.Dialog({
					title: "Advertencia",
					type: 'Message',
					content: new sap.m.Text({
						text: errorMsg
					}),
					state: sap.ui.core.ValueState.Warning,
					endButton: new sap.m.Button({
						text: "Aceptar",
						press: function(){
							var aFiles = uploader.getAggregation("items");
							uploader.removeAggregation("items",aFiles[0], true);
							uploader.rerender();
							dialog.close();
							uploader.setBusy(false);
						}
					}),
				});
				dialog.open();
			} else {
				uploader.setBusy(true);
				var oUploadCollection = oEvent.getSource();
				var oCustomerHeaderToken = new sap.m.UploadCollectionParameter({
					multiple: false,
					name : "x-csrf-token",
					value : conAttachModel.getSecurityToken()
				});
				oUploadCollection.addHeaderParameter(oCustomerHeaderToken);
				var file = oEvent.getParameter("files") && oEvent.getParameter("files")[0];
				if(file && window.FileReader){
					var reader = new FileReader();
					var that = this;
					reader.onload = function(evn) {
						var strCSV = evn.target.result;
						var fileType = this.type;
						uploader.getItems()[0].addCustomData(new sap.ui.core.CustomData({
							key : strCSV,
							value: fileType
						}));
						uploader.setBusy(false);
					}.bind({type : file.type});
					reader.readAsDataURL(file);
				}
			}
		}







	};
});
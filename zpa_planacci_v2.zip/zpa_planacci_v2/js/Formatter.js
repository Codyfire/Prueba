sap.ui.define([
	"sap/ui/core/format/DateFormat",
	"sap/ui/core/CalendarType",
	"sap/ui/core/format/NumberFormat"
	], function(DateFormat,CalendarType,NumberFormat){
	"use strict";
	
	return {
		
		// Conversor de numeros float
		// @params sNumber: Numero a formatear
		// @params sFromLocale: Region del formato original (US o ES )
		formatNumber : function(sNumber,sFromLocale) {
			var value = "";
			if(sNumber) {
				switch(sFromLocale) {
			        // Cambiar de formato 0000000.00 (US) a formato 0.000.000,00 (ES)
			        case "US":
			        	var decimalPLaces = sNumber.split(".")[1];
			        	var integerPLaces = sNumber.split(".")[0].replace(/(\d)(?=(\d{3})+(?!\d))/g,"$1.");
				        value = (decimalPLaces ) ? integerPLaces + "," + decimalPLaces : integerPLaces + ",00";
				        break;
				    // Cambiar de formato 0.000.000,00 (ES) a formato 0000000.00 (US)
			        case "ES":
			        	value = sNumber.replace(/\./g,"").replace(",",".");
			        	break;
			    }
			}
		    return value;
		},
		
		// Conversor de numeros integer
		// @params sNumber: Numero a formatear
		// @params sFromLocale: Region del formato original (US o ES )
		formatIntegerNumber : function(sNumber,sFromLocale) {
			var value = "";
			if(sNumber) {
				switch(sFromLocale) {
			        // Cambiar de formato 0000000 (US) a formato 0.000.000 (ES)
			        case "US":
			        	value = sNumber.replace(/(\d)(?=(\d{3})+(?!\d))/g,"$1.");
				        break;
				    // Cambiar de formato 0.000.000 (ES) a formato 0000000 (US)
			        case "ES":
			        	value = sNumber.replace(/\./g,"");
			        	break;
			    }
			}
		    return value;
		},
		// convierte un string numerico a Integer
		stringToInteger : function(sValue) {
			if(sValue === "") {
				return "0";
			} else {
				return sValue;
			}
		},
		
		// convierte un string en formato 0.000.000,00 a float
		stringToFloat : function(sValue) {
			return parseFloat(sValue.split(".").join("").replace(",", "."));
		},
		
		// convierte un float en un string con formato 0.000.000,00
		floatToString : function(fValue) {
			var oNumberFormat = NumberFormat.getFloatInstance({
                minIntegerDigits: 1, 
                maxFractionDigits: 2,
                minFractionDigits: 2,
                groupingEnabled: true, 
                groupingSeparator: ".", 
                decimalSeparator: "," 
             });
             var stringNumber = oNumberFormat.format(fValue);
             return stringNumber;
		},
		
		// convierte un float en un string con formato 0.000.000,00
		fourDecimalFloatToString : function(fValue) {
			var oNumberFormat = NumberFormat.getFloatInstance({
                minIntegerDigits: 1, 
                maxFractionDigits: 4,
                minFractionDigits: 4,
                groupingEnabled: true, 
                groupingSeparator: ".", 
                decimalSeparator: "," 
             });
             var stringNumber = oNumberFormat.format(fValue);
             return stringNumber;
		},
		
		/** Convierte una fecha en formato string del tipo yyyyMMddHHmmss a un objeto Date.
		 *  @params sDate:		Fecha en texto a formatear
		 *  @params sFormat:	Formato de la fecha introducida
		 */
		stringToDate : function(sDate, sFormat) {
			var oDate;
			// si sFormat no viene informado se establece el formato por defecto
			var formato = sFormat ? sFormat : "yyyyMMddHHmmss";
	    	if(sDate) {
				oDate = DateFormat.getInstance({pattern: formato, calendarType: CalendarType.Gregorian}).parse(sDate);
	    	}
			return oDate;
		},
		
		// Función para formatear fechas de tipo Date a String
	    // @params oDate: Fecha a formatear
	    // @params sPattern: Mascara de formateo
	    dateToString : function(oDate, sPattern) {
	    	var sDate;
	    	if(oDate) {
	    		sDate = DateFormat.getInstance({pattern: sPattern, calendarType: CalendarType.Gregorian}).format(oDate);
	    	} else {
	    		sDate = "-";
	    	}
	    	return sDate;
	    },
		// Función para formatear fechas de tipo String al formato que se elija
		//( esta funcion para formater en xml combina las funciones stringToDate y dateToString)
	    // @params sDate: Fecha en texto a formatear
	    // @params sPattern: Mascara de formateo
	    stringToFormattedDate: function(sDate,sPattern) {
	    	var oDate,formattedDate;
	    	if(sDate) {
	    		if(sDate === "00000000") {
	    			formattedDate = sDate;
	    		} else {
		    		// Recuperamos el objeto Date()
		    		oDate         = this.formatter.stringToDate(sDate);
		    		// Formateamos el objeto date recuperado con la mascara pedida
			    	formattedDate = this.formatter.dateToString(oDate,sPattern);
	    		}
	    	} else {
	    		formattedDate = "-";
	    	}
	    	return formattedDate;
	    },
	    // Función para formatear fechas de tipo String ( fecha + hora ) al formato que se elija
		//( esta funcion para formater en xml combina las funciones stringToDate y dateToString)
	    // @params sDate: Fecha en texto a formatear
	    // @params sHour: Hora en texto a formatear
	    // @params sPattern: Mascara de formateo
	    stringToTimestamp: function(sDate,sHour,sPattern) {
	    	var oDate,formattedDate;
	    	if(sDate) {
	    		// Recuperamos el objeto Date()
	    		oDate         = this.formatter.stringToDate(sDate + sHour);
	    		// Formateamos el objeto date recuperado con la mascara pedida
		    	formattedDate = this.formatter.dateToString(oDate,sPattern);
	    	} else {
	    		formattedDate = "-";
	    	}
	    	return formattedDate;
	    },
	    formatDateRange: function(sStartDate,sEndDate,sPattern) {
			var oStartDate,oEndDate,formattedStartDate,formattedEndDate,formattedDateRange;
			// Formateamos la fecha de inicio
			// Recuperamos el objeto Date() a partir de sStartDate
    		oStartDate    = this.formatter.stringToDate(sStartDate);
    		// Formateamos el objeto date recuperado con la mascara dd/MM/yyyy
	    	formattedStartDate = this.formatter.dateToString(oStartDate,sPattern);
	    	// Comprobamos que exista una fecha de fin
			if(sEndDate) {
				// Recuperamos el objeto Date() a partir de sEndDate
	    		oEndDate    = this.formatter.stringToDate(sEndDate);
	    		// Formateamos el objeto date recuperado con la mascara dd/MM/yyyy
		    	formattedEndDate = this.formatter.dateToString(oEndDate,sPattern);
				// Generamos el rango de fechas
				formattedDateRange = formattedStartDate + " - " + formattedEndDate;
				return formattedDateRange;
			} else {
				return formattedStartDate;
			}
	    },
	    formatDateKPI: function(sDate) {
	    	var formattedDate;
	    	if(sDate) {
		    	var aMonths = this.getOwnerComponent().getModel("Maestros").getProperty("/Months"),
		    		day     = sDate.substring(6, 8),
		    		month   = aMonths[parseInt(sDate.substring(4, 6),10)];
		    		formattedDate = month + ", " + day;
	    	}
	    	return formattedDate;
	    },
	    formatMonthYear: function(sDate) {
	    	var formattedDate;
	    	if(sDate) {
		    	var aMonths = this.getOwnerComponent().getModel("Maestros").getProperty("/Months"),
		    		year     = sDate.substring(0, 4),
		    		iMonth   = parseInt(sDate.substring(4, 6),10),
		    		month    = aMonths[iMonth];
		    		formattedDate = month + " " + year;
	    	}
	    	return formattedDate;
	    },
	    // Devuelve el tipo de una variable (number, string, Function, etc)
		typeOf : function(value) {
		    var type = typeof value;
		
		    switch(type) {
		        case 'object':
			        return value === null ? 'null' : Object.prototype.toString.call(value).match(/^\[object (.*)\]$/)[1];
		        case 'function':
		        	return 'Function';
		        default:
		        	return type;
		    }
		},
		
		acortarNombre : function(sName) {
			if(sName.length < 24) {
				return sName;
			}
			
			var strSplit = sName.split(",");
			var nombres = strSplit[1].trim();
			var apellidos = strSplit[0].trim();
			
			strSplit = nombres.split(" ");
			var nombre;
			if(strSplit.length > 1) {
				nombre = strSplit[0] + " " + strSplit[1].substr(0, 1) + ".";
			} else {
				nombre = strSplit[0];
			}
			
			strSplit = apellidos.split(" ");
			var apellido;
			if(apellidos.length > 1) {
				apellido = strSplit[0] + " " + strSplit[1].substr(0, 1) + ". ";
			} else {
				apellido = strSplit[0] + " ";
			}
			
			return apellido + ", " + nombre;
		},
		
		// Devuelve el valor de un checkbox como "X" - true, "" - false
		// @params bState: Valor boolean proviniente del modelo oData
		formatCheckToModel: function(bState) {
			if(bState) {
				return "X";
			} else {
				return "";
			}
		},
		
		// Devuelve el valor de un checkbox como true - "x", false - ""
		// @params sState: Valor string proviniente del modelo oData
		formatModelToCheck: function(sState) {
			if(sState === "X") {
				return true;
			} else {
				return false;
			}
		},
		
		// Devuelve el valor de un checkbox como "EXITING" - true, "NEW" - false
		// Esta función es solo para el check "New or Existing Client"
		// @params bState: Valor boolean proviniente del modelo oData
		formatCheckToNewClientModel: function(bState) {
			if(bState) {
				return "EXISTING";
			} else {
				return "NEW";
			}
		},
		
		// Devuelve el valor de un checkbox como true - "EXSITING", false - "NEW"
		// Esta función es solo para el check "New or Existing Client"
		// @params sState: Valor string proviniente del modelo oData
		formatModelToNewClientCheck: function(sState) {
			if(sState === "EXISTING") {
				return true;
			} else {
				return false;
			}
		},
		
		// Recupera la descripción del estado de un string del tipo "QUAL Qualified"
		// @params sStatus: Código descripción del status
		toLifecycleStatus: function(sStatus) {
			var formattedStatus;
			if(sStatus) {
				formattedStatus = sStatus.substring(5, 30);
			}
			return formattedStatus;
		},
		// Muestra '-' en las cajas de texto cuyo dato este vacío
		// @params sValue: Valor a tratar
		voidData: function(sValue) {
			if( sValue === "" ) {
				return "-";
			} else {
				return sValue;
			}
		},
		formatDecimals: function(sValue, sCurrency) {
			//ejecución cuando sValue esté informado, al ser un formatter contemplamos la 
			//posibilidad de que se ejecute antes de realizarse el binding pudiendo venir vacías las variables
			if (sValue !== null || sValue !== undefined) {
				// Consultamos sCurrency. Si NO TIENE decimales hacemos lo siguiente
				var _sMoneda = sValue;
				var _bDecimal = true;
				var format = 0;
				var aCurrencies;

				try {
					//cargamos el modelo en la vista donde se aplica este formatter
					var _oModel = this.getOwnerComponent().getModel("Currencies");
						aCurrencies = _oModel.getData();
				} catch (error) {
						aCurrencies ={ "results" : [ {
									"NonDecimalCurr": "CLP"
								}, {
									"NonDecimalCurr": "COP"
								}, {
									"NonDecimalCurr": "HUF"
								}, {
									"NonDecimalCurr": "IDR"
								}, {
									"NonDecimalCurr": "JPY"
								}, {
									"NonDecimalCurr": "KRW"
								}, {
									"NonDecimalCurr": "ROL"
								}, {
									"NonDecimalCurr": "TRL"
								}, {
									"NonDecimalCurr": "TWD"
								}]
								};
				}

		//se consultan las monedas sin decimales cargadas del modelo
			for (var i = 0; aCurrencies.results.length > i; i++) {
			if (sCurrency === aCurrencies.results[i].NonDecimalCurr) {
				_bDecimal = false;
			}
		}

		//Formato float con decimales, la moneda no se encuentra en el modelo
			if (_bDecimal) {

			var oOptionsDecimals = {
				"minIntegerDigits": "1",
				"minFractionDigits": "2",
				"maxFractionDigits": "2",
				"groupingEnabled": "true",
				"groupingSeparator": ".",
				"decimalSeparator": ",",
				"minusSign": "-"
			};

			var oFloatDec = NumberFormat.getFloatInstance(oOptionsDecimals);
			format = oFloatDec.format(_sMoneda);
		} else { //Formato float sin decimales, la moneda se encuentra en el modelo

			var oOptionsNoDec = {
				"minIntegerDigits": "1",
				"minFractionDigits": "0",
				"maxFractionDigits": "0",
				"groupingEnabled": "true",
				"groupingSeparator": ".",
				"decimalSeparator": ",",
				"minusSign": "-"
			};

			var oFloatND = NumberFormat.getFloatInstance(oOptionsNoDec);
			format = oFloatND.format(_sMoneda);
		}
	}
	return format;
},
//INI MFDL - 15-12-2022 Formato calcular porcentaje 
formatoCalcular: function(valor,valor2){

	var  dato=parseInt(valor.replace(",","."));
	var  dato2=parseFloat(valor2.replace(",","."));
	var calculo=((dato*dato2)/100).toFixed(3).toString().replace(".",",");
	return calculo;
},
formatStringDate:function(sDate) {
	var dateString = sDate;
	var day = dateString.substring(6, 8);
	var month = dateString.substring(4, 6);
	var year = dateString.substring(0,4);
	var date = (day +'/'+month+'/'+year);

	return date; // Output: 00/00/0000
}
//FIN MFDL -15-12-2022
		
/*		floatToString2 : function (num) {
			var separador = "."; // separador para los miles
			var sepDecimal = ","; // separador para los decimales
			num += "";
			var splitStr = num.split(".");
			var splitLeft = splitStr[0];
			var splitRight = splitStr.length > 1 ? sepDecimal + splitStr[1] : "";
			var regx = /(\d+)(\d{3})/;
			while (regx.test(splitLeft)) {
				splitLeft = splitLeft.replace(regx, "$1" + separador + "$2");
			}
			return splitLeft + splitRight;
		}*/
	};
});
/*
 * Copyright (C) 2009-2020 SAP SE or an SAP affiliate company. All rights reserved.
 */

jQuery.sap.declare("sap.grc.acs.aud.audit.initiate.extended.Component");
					
sap.ui.component.load({
 	name:"sap.grc.acs.aud.audit.initiate",
 	url: "/sap/bc/ui5_ui5/sap/grcaud_audinit"
 		 
 });

sap.ui.define([ "sap/ui/core/UIComponent", "sap/ui/Device",
		"sap/grc/acs/aud/audit/initiate/Component",
		"sap/grc/acs/aud/audit/app/Component" ], function(U, D, A, F) {
	"use strict";
	return F.extend("sap.grc.acs.aud.audit.initiate.extended.Component", {
		metadata : {
			manifest : "json", 
		     "customizing" : {
//		    	 "sap.ui.viewExtensions":{
//		    		 "sap.grc.acs.aud.audit.block.view.General": {    
//	                        "viewName": "sap.grc.acs.aud.audit.initiate.extended.view.GeneralCustom",            
//	                        "type": "XML"
//	                    }    ,
//	
//		    	 },
		    	 "sap.ui.viewReplacements" : {
						"sap.grc.acs.aud.audit.view.Object" : {
							"viewName" : "sap.grc.acs.aud.audit.initiate.extended.view.Object",
							"type" : "XML"
						},												
						 
						
						"sap.grc.acs.aud.audit.view.Worklist" : {
							"viewName" : "sap.grc.acs.aud.audit.initiate.extended.view.Worklist",
							"type" : "XML"
						},
				    	 "sap.grc.acs.aud.audit.view.Create": {    		                     
		                     "viewName": "sap.grc.acs.aud.audit.initiate.extended.view.Create",            
		                     "type": "XML"
		                 }    	,
		                 "sap.grc.acs.aud.audit.block.view.General": {    
		                     "viewName": "sap.grc.acs.aud.audit.initiate.extended.view.GeneralCustom",            
		                     "type": "XML"
		                 }    ,
					},
		         "sap.ui.controllerExtensions" : {
		              
		     "sap.grc.acs.aud.audit.controller.Object" : {
					"controllerName" : "sap.grc.acs.aud.audit.initiate.extended.controller.ObjectExtended"
		
				},
				
				"sap.grc.acs.aud.audit.controller.Worklist" : {
					"controllerName" : "sap.grc.acs.aud.audit.initiate.extended.controller.Worklist"
		
				},
				

				 "sap.grc.acs.aud.audit.block.controller.General" : {
					 "controllerName":"sap.grc.acs.aud.audit.initiate.extended.block.GeneralCustom"
				 
				 }
				 
			},
			"sap.ui.controllerReplacements": {
				 "sap.grc.acs.aud.audit.controller.Create" : {
					 "controllerName":"sap.grc.acs.aud.audit.initiate.extended.controller.Create"
				 
				 },
				 

			}
		          }
		}
	});

	
});

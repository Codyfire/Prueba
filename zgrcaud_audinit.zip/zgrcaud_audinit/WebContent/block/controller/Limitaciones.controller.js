// PPM100104703 Crear controlador
sap.ui.define([ 
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";
	return Controller.extend("sap.grc.acs.aud.audit.initiate.extended.block.controller.Limitaciones",{
		/**
		 * @override
		 */
		onInit: function () {
			//Inicialización de datos y botones desde ObjectExtended.Controller por publish / subscribe
			sap.ui.getCore().getEventBus().subscribe("sap.grc.acs.aud.audit.EventBus","getDataLimitacionesInit", this._initView, this);
			//Inicialización de datos desde carga inicial
			this._initView(this);
		},
		/***
		 * **********************************************************************************
		 * Eventos de pantalla
		 * **********************************************************************************
		 */
		/**
		 * Evento del boton "Search" del SearchField
		 * @param {Object} oEvent
		 */
		onSearch: function(oEvent) {
			let sValue = oEvent.getSource().getValue();
			let aFilters = [];
			if(sValue) {
				aFilters.push(new sap.ui.model.Filter("description", sap.ui.model.FilterOperator.Contains, sValue));
			}
			this.byId("tableLimitaciones").getBinding("items").filter(aFilters);
		},
		/**
		 * Evento del boton "Añadir" del header de la tabla
		 * @param {Object} oEvent
		 */
		onAddLimitacion: function(oEvent) {					
		
			// Destruimos el fragment si existiera y lo creamos de nuevas
			if (this._fragment) {
				this._fragment.destroy();
			}

			this._fragment = sap.ui.xmlfragment("sap.grc.acs.aud.audit.initiate.extended.block.fragment.DialogCreateLimitacion",this);
			this.getView().addDependent(this._fragment);
			
			// Añadimos función para recuperar los elementos del formulario dinamicamente
			this._addFindElements({Control:this,Object:this._byId("formLimitacion")});
			
			// Creamos el modelo de la pantalla
			let oData =  
			{
				"parent_key":sap.ui.getCore().getModel("auditKeyModel").getData().id,
				"db_key":"00000000-0000-0000-0000-000000000000",
				"limit_id":"",
				"limitation":"",
				"description":"",
				"status":"",
				"vinc_obligations":"",
				"init_date":"",
				"fin_date":""
			}	

			this.getView().setModel(new sap.ui.model.json.JSONModel(oData),"modelAddLimitacion");
			
			this._fragment.open();
		},
		/**
		 * Evento del boton "Tratar" del header de la tabla
		 * @param {Object} oEvent
		 */
		onEditLimitacion: function(oEvent) {
			// Añadimos función para recuperar los elementos de la tabla dinamicamente
			this._addFindElements({Control:this,Object:this._byId("tableLimitaciones")});
			let aFormulario = this._byId("tableLimitaciones").FindElement();
			// Validamos para quitar los posibles inputs erroneos
			this._massiveValidate(aFormulario);
			// No hacemos nada si no tenemos datos
			if(aFormulario.length === 0) return;
			// Mostramos/ocultamos los botones
			this._modeEdit(true);
		},
		/**
		 * Evento del boton "+" del header de la tabla
		 * @param {Object} oEvent
		 */
		onCreateLimitacion: function(oEvent) {
			// Llamamos a modify
			this._modifyLimitacion("Create","modelAddLimitacion");
		},
		/**
		 * Evento del boton "Save" del header de la tabla
		 * @param {Object} oEvent
		 */
		onSaveLimitacion: function(oEvent) {
			// Llamamos a modify
			this._modifyLimitacion("Update","modelLimitaciones");
		},
		/**
		 * Evento del boton "Borrar" del header de la tabla
		 * @param {Object} oEvent
		 */
		onDeleteLimitacion: function(oEvent) {
			// Llamamos a modify
			this._modifyLimitacion("Delete","modelLimitaciones");
		},
		/**
		 * Evento del boton "Cancelar" del header de la tabla
		 * @param {Object} oEvent
		 */
		onCancelar: function(oEvent) {
			// Mostramos/ocultamos los botones
			this._modeEdit(false);
			// Recargar la tabla con los datos iniciales
			this._loadData();
		},
		/**
		 * Evento de cierre del dialog de añadir limitacion
		 * @param {Object} oEvent
		 */
		onCloseDialog: function(oEvent) {
			this._fragment.close();
			this._fragment.destroy();
			this._fragment = "";
		},
		/**
		 * Función de validación en los eventos change de los elementos
		 * @param {Object} oEvent
		 */
		onChangeValidate: function(oEvent) {
			// Recuperamos el flag
			let oFlag = oEvent.getSource().data("ValidateVoid");
			// Llamamos a la función generica de validación
			this._validate(oEvent.getSource(), oFlag);
		},
		/**
		 * Función de validación en los eventos change de las fechas
		 * @param {Object} oEvent
		 */
		onChangeFecha: function(oEvent) {
			// Recuperamos las dos fechas para validar por parejas
			let sIdFecIni  = oEvent.getSource().data("FecIni");
			let sIdFecFin  = oEvent.getSource().data("FecFin");
			let sContainer = oEvent.getSource().data("Container")
			let oFecIni = this._byId(sContainer).FindElement(sIdFecIni);
			let oFecFin = this._byId(sContainer).FindElement(sIdFecFin);
			let oFlagFecIni = oFecIni.data("ValidateVoid");
			let oFlagFecFin = oFecFin.data("ValidateVoid");
			// Llamamos a la función generica de validación
			let validateFecIni = this._validate(oFecIni, oFlagFecIni);
			let validateFecFin = this._validate(oFecFin, oFlagFecFin);
			//Si pasa bien la validación, validamos rango
			if(validateFecIni && validateFecFin) {
				this._validateInicioFin(oFecIni,oFecFin);
			}
		},
		/***
		 * **********************************************************************************
		 * Funciones internas - Controlador
		 * **********************************************************************************
		 */
		/**
		 * Función interna de inicialización de componentes y datos de la vista
		 * @param {Object} oControl
		 */
		_initView: function(oControl) {
			// Mostramos/ocultamos los botones
			this._modeEdit(false);
			// Cargamos los datos de la tabla
			this._loadData();
			// Cargamos los datos de estados
			this._loadEstados();			
			// Cargamos los datos de obligatorios
			this._loadObligatorios();
		},
		/**
		 * Función interna de carga de datos de la tabla
		 */
		_loadData: function() {	
			var oTabla = this._byId("tableLimitaciones");
			// Ponemos el busy en la tabla
			oTabla.setBusyIndicatorDelay(0);
			oTabla.setBusy(true);									
			
			//Realizamos llamada al back para obtener el listado de limitaciones
			let sKey = sap.ui.getCore().getModel("auditKeyModel").getData().id;
			//sKey = "0050568f-0fcf-1edd-b0b2-29da2638fd4b";
			let oData = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/ZGRCAUD_ENH_SRV/",false);
			oData.read("/GRCAUD_CV_Audit(guid'"+sKey+"')/to_Limitation", {
				success: function (oData, response) {
					// Quitamos el busy de la tabla
					oTabla.setBusy(false);
					// Cargamos el modelo
					//let oData = {"results" :[{"ID":"1","Limitacion":"aaa","Descripcion":"aaa","Estado":"1","Obligaciones":"aaa","Fecha_Inicio":"20230501","Fecha_Fin":"20230515"},{"ID":"2","Limitacion":"bbb","Descripcion":"bbb","Estado":"2","Obligaciones":"bbb","Fecha_Inicio":"20230501","Fecha_Fin":"20230515"}]};
					let oModel = new sap.ui.model.json.JSONModel(oData);
					this.getView().setModel(oModel,"modelLimitaciones");	
				}.bind(this),
				error: function(oError) {
					this._oDataError(oError,oTabla) 
				}.bind(this) 
			});
		},
		/**
		 * Función interna de carga de datos del combo de estados
		 */
		_loadEstados: function() {
			//Realizamos llamada al back para obtener el listado de estados
			let oData = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/ZGRCAUD_ENH_SRV/",false);
			oData.read("/ZGRCAUD_IV_AUDITLIMIT_STATUS", {
				success: function (oData, response) {
					// Cargamos el modelo
					//let oData = {"results" :[{"Code":"01","Name":"Vigente con obligaciones abiertas"},{"Code":"02","Name":"Vigente con obligaciones cerradas"},{"Code":"03","Name":"No Vigente"}]};
					let oModel = new sap.ui.model.json.JSONModel(oData);
					this.getView().setModel(oModel,"modelEstados");	
				}.bind(this),
				error: function(oError) {
					this._oDataError(oError,{}) 
				}.bind(this) 
			});
			
			
		},
		/**
		 * Función interna de carga de modelo de obligatorios
		 */
		_loadObligatorios: function() {
			let oData = {"requireLimitacion":true,"requireDescripcion":true,"requireEstado":true,"requireObligaciones":true,"requireFechaInicio":true,"requireFechaFin":false};
			let oModel = new sap.ui.model.json.JSONModel(oData);
			this.getView().setModel(oModel,"modelObligatorios");
		},
		/**
		 * Función interna de cambio entre modo edicion y modo detalle
		 * @param {Boolean} bEdit
		 */
		_modeEdit: function(bEdit) {
			this.byId("btn_editLimitacion").setVisible(!bEdit);
			this.byId("btn_addLimitacion").setVisible(!bEdit);
			this.byId("btn_saveLimitacion").setVisible(bEdit);
			this.byId("btn_deleteLimitacion").setVisible(bEdit);
			this.byId("btn_cancelarEditLimitacion").setVisible(bEdit);
			if(bEdit) {
				this.byId("tableLimitaciones").setMode("MultiSelect");
			} else {
				this.byId("tableLimitaciones").setMode("None");
			}
			// Hacemos editables los campos
			let oModel = new sap.ui.model.json.JSONModel({"editable":bEdit});
			this.getView().setModel(oModel,"modelEditable");			
		},
		/**
		 * Función interna para controlar la accion de creacción, actualización y borrado de limitaciones
		 * @param {String} sType
		 * @param {String} sModel
		 */
		_modifyLimitacion: function(sType,sModel){
			let oData, bValidate,
			oModel = this.getView().getModel(sModel),
			oTabla = this.byId("tableLimitaciones"),
			oItems = oTabla.getSelectedItems();
			
			oData = {
				"AuditKey":sap.ui.getCore().getModel("auditKeyModel").getData().id,
				"to_Limitation" : []
			};
			
			// Case para diferenciar entre acciones CRUD
			switch (sType) {	
				case "Create":
					// Comprobamos obligatorios
					let aFormulario = this._byId("formLimitacion").FindElement();
					bValidate = this._massiveValidate(aFormulario);
					
					// Revalidamos el rango de fechas para asegurar qeu sea correcto
					for (var i = 0; i < aFormulario.length; i++) {
						if(aFormulario[i].data("FecIni")){
							let oFecIni = this._byId("formLimitacion").FindElement(aFormulario[i].data("FecIni"));
							let oFecFin = this._byId("formLimitacion").FindElement(aFormulario[i].data("FecFin"));
							let vali = this._validateInicioFin(oFecIni,oFecFin);
							if(!vali) bValidate=false;
						}
					}
					
					if(!bValidate) {
						// Mostramos el mensaje de error por pantalla
						sap.m.MessageBox.alert(this._getI18nText("MSG_REQUIRED_FIELD",[]), {
							icon: sap.m.MessageBox.Icon.ERROR,
							title: "Error"
						});
						return;
					}
					// Sacamos todos los datos de la tabla ( se hayan modificado o no )
					oData.to_Limitation = this.getView().getModel("modelLimitaciones").getData().results;
					// Añadimos los datos a la deep.
					oData.to_Limitation.push(oModel.getData());
					// Machacamos variable para gestion de busy
					this._fragment.setBusyIndicatorDelay(0);
					oTabla = this._fragment;
				break;
				case "Update":
					// Comprobamos obligatorios
					let aTabla = this._byId("tableLimitaciones").FindElement();
					bValidate = this._massiveValidate(aTabla);
					
					// Revalidamos el rango de fechas para asegurar qeu sea correcto
					for (var i = 0; i < aTabla.length; i++) {
						if(aTabla[i].data("FecIni")){
							let oFecIni = this._byId("tableLimitaciones").FindElement(aTabla[i].data("FecIni"));
							let oFecFin = this._byId("tableLimitaciones").FindElement(aTabla[i].data("FecFin"));
							let vali = this._validateInicioFin(oFecIni,oFecFin);
							if(!vali) bValidate=false;
						}
					}
					
					if(!bValidate) {
						// Mostramos el mensaje de error por pantalla
						sap.m.MessageBox.alert(this._getI18nText("MSG_REQUIRED_FIELD",[]), {
							icon: sap.m.MessageBox.Icon.ERROR,
							title: "Error"
						});
						return;
					}
					// Sacamos todos los datos de la tabla ( se hayan modificado o no )
					oData.to_Limitation = oModel.getData().results;
				break;
				case "Delete":
					// Comprobamos que se haya seleccionado algo de la tabla
					if(oItems.length === 0) {
						sap.m.MessageToast.show(this._getI18nText("msgSeleccionLimitacion",[]));
						return;
					}
					
					// Iteramos sobre los elementos de la tabla
					let aAux = [];
					for (var index = 0; index < oItems.length; index++) {
						let element =  oItems[index].getBindingContext(sModel).getObject();
						// Iteramos sobre las lineas seleccionadas
						for (var index2 = 0; index2 < oModel.getData().results.length; index2++) {
							let element2 = oModel.getData().results[index2];
							let indexAux = oModel.getData().results.findIndex(elem => elem.db_key === element2.db_key);
							if(element&&element2&&element.db_key === element2.db_key) oModel.getData().results.splice(indexAux,1);
						}
					}
					// Refrescamos los elementos
					oModel.refresh();
					oTabla.getBinding("items").refresh();
					// Sacamos los datos restantes de la tabla
					oData.to_Limitation = oModel.getData().results;
				break;	
				default:
				break;
			}
			// Modificamos las fechas para que sean de tipo date
			for (let index = 0; index < oData.to_Limitation.length; index++) {
				let element = oData.to_Limitation[index];
				let oDateIni = new Date(element.init_date);
				let oDateFin = new Date(element.fin_date);
				if(element.init_date) element.init_date = oDateIni;
				if(element.fin_date) {
					element.fin_date = oDateFin;
				} else {
					delete element.fin_date;
				}
			}
			// Ponemos el busy en la tabla
			oTabla.setBusy(true);
			// Llamamos a función de deep para crear/editar/borrar
			this._deepOperation(oData,oTabla,sType);
			// Volvemos a dejar las fechas bien formateadas ( por si acaso)
			for (let index = 0; index < oData.to_Limitation.length; index++) {
				let element = oData.to_Limitation[index];
				element.init_date = sap.ui.core.format.DateFormat.getInstance({pattern: "yyyy-MM-ddTHH:MM:SS", calendarType: sap.ui.core.CalendarType.Gregorian}).format(element.init_date);
				if(element.fin_date) element.fin_date = sap.ui.core.format.DateFormat.getInstance({pattern: "yyyy-MM-ddTHH:MM:SS", calendarType: sap.ui.core.CalendarType.Gregorian}).format(element.fin_date);
			}
		},
		/**
		 * Operacion CRUD crear/editar/borrar
		 * @param {Object} data
		 * @param {Object} objBusy
		 * @param {Object} sType
		 */
		_deepOperation: function(data,objBusy,sType) {
			// Aqui habría que hacer una llamada a una deep Entity en back
			let oData = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/ZGRCAUD_ENH_SRV/",false);
			oData.create("/GRCAUD_CV_Audit", data, {
				success:function(oData) {
					// Quitamos el busy en la tabla
					objBusy.setBusy(false);
					// Si tenemos el popup de creacción lo cerramos
					if(this._fragment) this._fragment.close();
					// recargamnos la tabla
					this._initView();
				}.bind(this),
				error: function(oError) {
					this._oDataError(oError,objBusy) 
					// recargamnos la tabla en caso de error en el delete ( para recuepar valro eprdido ) o el create ( para que no se añada varias veces el mismo valor )
					if(sType !== "Update") this._initView();
				}.bind(this)
			});
		},
		/***
		 * **********************************************************************************
		 * Funciones internas - Genericas
		 * **********************************************************************************
		 */
		/**
		 * Recuperar el valor del i18n
		 * @param {String} sText
		 * @param {Array} oParams
		 * @returns {Object} 
		 */
		_getI18nText: function(sText,oParams) {
			var oParams = ( oParams ) ? oParams : [];
			return this.getOwnerComponent().getModel("i18n").getResourceBundle().getText(sText,oParams);
		},
		/**
		 * ById genérico que aplica primero el byId de controlador y despues el de core.
		 * @params {String} sName
		 * @return {Object}
		 */
		_byId: function(sName) {
			var oObject = this.byId(sName);
			if (!oObject) {
				oObject = sap.ui.getCore().byId(sName);
			}
			return oObject;
		},
		// 
		/**
		 * Introduce la funcion FindElement en el objeto que se le pase, esta funcion buscara por cualquier elemento que tenga un id del data
		 * @params {Object} Params
		 * @return {Array/Object}
		 */
		_addFindElements: function(Params) {
			let Control, Object;
			if (Params) { Control = Params.Control, Object = Params.Object}
			Object.FindElement=function(Id){
				let Contenedor=this;
	
				let Elementos=Contenedor.findElements(true),x=0;
				if(!Elementos)return null;
				let aElements = [];
				while(x<Elementos.length){
					if(Elementos[x].data&&Elementos[x].data("Id")){
						if(Id&&Elementos[x].data("Id")===Id)return Elementos[x];
						aElements.push(Elementos[x]);
					}
					x++;
				}
				if(Id)return null;
				return aElements;
			};		
		},
		/** 
		 * Función genérica para capturar y mostrar los errores en las llamadas a oData.
		 * @param {Object} oError
		 * @param {Object} objBusy
		 */
		_oDataError: function (oError,objBusy) {
			var message, data;

			try {
				// lo formateamos a JSON
				data = $.parseJSON(oError.responseText);
				message = "";

				// obtengo el mensaje de error
				if (data.error.innererror.errordetails && data.error.innererror.errordetails.length > 0) {
					for (var i = 0; i < data.error.innererror.errordetails.length; i++) {
						if (data.error.innererror.errordetails[i].code !== "/IWBEP/CX_SD_GEN_DPC_BUSINS") {
							// message += data.error.innererror.errordetails[i].code + " - " + data.error.innererror.errordetails[i].message + "\n";  /*JPM*/
							message += data.error.innererror.errordetails[i].message + "\n";
						}
					}
				} else {
					message += data.error.message.value;
				}
			} catch (err) {
				// si el formateo a JSON falla, lo intentamos formatear a XML
				data = $.parseXML(oError.responseText);
				var $xml = $(data);
				var $message = $xml.find("innererror").find("message");
				if (!$message.text()) {
					$message = $xml.find("message");
				}
				//var $service = $xml.find( "service_id" ); /*JPM*/
				message = $message.text();
				//service = $service.text(); /*JPM*/
			}

			// quitamos el busy de espera
			if (objBusy) {
				objBusy.setBusy(false);
			}

			// Mostramos el mensaje de error por pantalla
			sap.m.MessageBox.alert(message, {
				icon: sap.m.MessageBox.Icon.ERROR,
				title: "Error",
			});
		},
		/***
		 * **********************************************************************************
		 * Funciones internas - Validaciones
		 * **********************************************************************************
		 */
		
		/**
		 * Función de validación masiva al pulsar a botones de guardado
		 * @param {Array} aElements
		 * @returns {Boolean}
		 */
		_massiveValidate: function(aElements) {
			var oElement;
			var validate = true;
			//Recorremos el array de ids
			for (var i = 0; i < aElements.length; i++) {
				// Recuperamos el elemento
				oElement = aElements[i];
				
				if(oElement&&oElement.data) {
					let vali = this._validate(oElement,oElement.data("ValidateVoid"));
					if(!vali) validate=false;
				}

			}
			return validate;
		},
		/**
		 * Función genérica de validación de formato de campos
		 * @param {Object} oElement
		 * @param {Boolean} swValidateVoid
		 * @returns {Boolean}
		 */
		_validate: function(oElement, swValidateVoid) {
			var valor = "";
			if(oElement) {
				// Recuperamos el tipo de elemento que se tiene
				var clase = oElement.getMetadata().getName();
				
				// Recuperamos el valor según el tipo de elemento que tengamos
				// y validamos que el formato sea correcto
				switch (clase) {
					case "sap.m.Input":
					case "sap.m.TextArea":
					default:     
						valor = this._inputValidation(oElement, swValidateVoid);
						break;
					case "sap.m.DatePicker":
						valor = this._datepickerValidation(oElement, swValidateVoid);
						break;
					case "sap.m.Select":
						valor = this._selectValidation(oElement, swValidateVoid);
						break;
				}
			}
			return valor;
		},
		/**
		 * Función validación de formato de inputs
		 * @param {Object} oElement
		 * @param {Boolean} swValidateVoid
		 * @returns {Boolean}
		 */
		_inputValidation: function(oElement, swValidateVoid) {
			var input = oElement;
			var inputValue = input.getValue();
			// Validamos campos vacios solo para el create (swValidateVoid = true)
			if (swValidateVoid && (inputValue === "" || inputValue === "0,00" || inputValue === "0")) {
				input.setValueState("Error");
				return false;
			}

			input.setValueState("None");
			return true;

		},
		/**
		 * Función validación de formato de selects
		 * @param {Object} oElement
		 * @param {Boolean} swValidateVoid
		 * @returns {Boolean}
		 */
		_selectValidation: function(oElement, swValidateVoid) {
			var select = oElement;
			var selectItems = select.getItems();
			var selectValue = select.getSelectedKey();
			// Validamos campos vacios solo para el create (swValidateVoid = true)
			if (swValidateVoid && selectValue === "") {
				select.setValueState("Error");
				return false;
			}
			
			// Si pasamos todas las validaciones quitamos el error en el elemento
			select.setValueState("None");
			return true;
		},
		/**
		 * Función validación de formato de datepicker
		 * @param {Object} oElement
		 * @param {Boolean} swValidateVoid
		 * @returns {Boolean}
		 */
		_datepickerValidation: function(oElement, swValidateVoid) {
			var datepicker = oElement;
			var datepickerValue = datepicker.getValue();
			var datepickerLength = datepickerValue.length;
			var datepickerMaxLength = 10;
			
			// Ponemos bien el elemento para asegurar validacion correcta
			datepicker.setValueState("None");
			datepicker.setValueStateText("");

			// Validamos campos vacios solo para el create (swValidateVoid = true)
			if (swValidateVoid && datepickerValue === "") {
				datepicker.setValueState("Error");
				return false;
			}
			
			//Validación de formato de fecha
			if(!datepicker.isValidValue()) {
				datepicker.setValueState("Error");
				return false;
			}

			// Si pasamos todas las validaciones quitamos el error en el elemento
			datepicker.setValueState("None");			
			return true;
		},
		/**
		 * Función validación de fecha inicio y fin en orden correcto
		 * @param {Object} oFecIni
		 * @param {Object} oFecFin
		 */
		_validateInicioFin:function(oFecIni,oFecFin){
			if(oFecIni && oFecFin && oFecIni.getValueState() === "None" && oFecFin.getValueState() === "None"){
				let sFecIniValue = oFecIni.getValue();
				let sFecFinValue = oFecFin.getValue();
				if(sFecIniValue !== "" && sFecFinValue !== ""){
					let sFecIniTime = oFecIni.getDateValue().getTime();
					let sFecFinTime = oFecFin.getDateValue().getTime()
					if(parseInt(sFecIniTime,10) > parseInt(sFecFinTime,10)){
						oFecIni.setValueState("Error");
						oFecIni.setValueStateText(this._getI18nText("msgFechaInicioFin",[]));
						oFecFin.setValueState("Error");
						oFecFin.setValueStateText(this._getI18nText("msgFechaInicioFin",[]));
						return false;
					} else {
						oFecIni.setValueState("None");
						oFecIni.setValueStateText("");
						oFecFin.setValueState("None");
						oFecFin.setValueStateText("");
					}
				}
			}
			return true;
		}
	});
});
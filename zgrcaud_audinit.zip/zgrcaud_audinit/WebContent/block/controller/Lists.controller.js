sap.ui.define([ "sap/ui/core/mvc/Controller",
"sap/grc/acs/aud/audit/initiate/extended/block/util/listsUtils",
	"sap/grc/acs/aud/audit/initiate/extended/block/util/encodingUtils",
	"sap/grc/acs/aud/audit/initiate/extended/block/model/oDataGeneratorList"


], function(Controller,UtilList,Util,Model) {
	"use strict";
	return Controller.extend("sap.grc.acs.aud.audit.initiate.extended.block.controller.Lists",{
		
		onInit: function () {
			if(!sap.ui.getCore().getModel("con")) {
				var con = {};
			    con.Model = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZGRCAUD_PORTAL_SRV/", false);
			    sap.ui.getCore().setModel(con.Model,"con");
			}
			//Inicio PRL 16.09.2021: Pasamos la carga del object binding al initialize, hacemos subscribe a ese metodo
			sap.ui.getCore().getEventBus().subscribe("sap.grc.acs.aud.audit.EventBus","initializeListsinit", this.initialize, this);
//			var that = this;
//			this.getOwnerComponent().mAggregations.rootControl.mAggregations.content[0].mAggregations.pages.forEach(function(e,i,a){
//				if(e.sId.indexOf('object') !== -1){
//			
//					
//				if(e.getBindingContext()){
//					that.objectBinding = e.getBindingContext().getObject();
//				}	
//					
//                }
//			});
			//Fin PRL 16.09.2021
			this.grcaudController = this;
			this.initialize(this);
			
		},
		
		initialize: function(oController) {
			//Inicio PRL 16.09.2021: Solo informamos el objectBinding si se ha cargado el contexto
			var that = this;
			if(this.getOwnerComponent()){
			this.getOwnerComponent().mAggregations.rootControl.mAggregations.content[0].mAggregations.pages.forEach(function(e,i,a){
				if(e.sId.indexOf('object') !== -1){
								
				if(e.getBindingContext()){
					that.objectBinding = e.getBindingContext().getObject();
				}	
			//Fin PRL 16.09.2021		
                }
			})};
			this.grcaudController = oController;  
			
			// Fetching Distribution List
			this._getDistList(oController);
			//sap.ui.getCore().getEventBus().subscribe("sap.grc.acs.aud.audit.EventBus","getInTeamLists", this._checkEnabledTeamAdd, this);
			
		},
		
		_getCurrentUser: function() {
			return sap.ushell.Container.getService("UserInfo").getId();
		}, 
		
		_getInTeam: function(auditKey) {
			if(!auditKey){
				 auditKey = this.objectBinding.DBKey;
			} 
				
			if(auditKey){
				// Find current user in Team
				var inTeam = false;
				var currUser = this._getCurrentUser();
				
				var oModel = new sap.ui.model.odata.ODataModel(
						"/sap/opu/odata/sap/GRCAUD_SRV",false
				);
				oModel.read("/AuditSet(guid'"+ auditKey + "')/UserRoles", { async: false, success: success, error: error }); //TODO Da error la llamada parece que el oModel no esta bien
				
				function success(oData,oDataRes)
				{
					var users = $.grep(oData.results,function(n){ return (n.UserID == currUser); });
					inTeam = users.length > 0 ? true : false;
				}
				
				function error(error) {
					console.log("Error retrieving Team members");
					inTeam = false;
				}
				
				return inTeam;
			} else return false;
		},
		
		_getFinalStatus: function() {
			// Closed : "08",Canceled : "09", DistributeAuditReport : "18"
			return ["08","09","18"];
		},
		
		_getInFinalStatus: function(currStatus) {		
			// Looking for curStatus in finalStatus array
			var finalStatus = this._getFinalStatus();
			var array = $.grep(finalStatus, function(n){ return (n == currStatus)});
			return array.length > 0 ? true : false;
		},
		
		_hideAddSubsBtn: function(distView) {
		
			
			//First Responsible
			var centros = distView.mAggregations.content[0].mAggregations.items[0];
			centros.byId('treeTableCentros').mAggregations.columns[1].mAggregations.template.mAggregations.items[0].setVisible(false);
			centros.byId('treeTableCentros').mAggregations.columns[1].mAggregations.template.mAggregations.items[0].setVisible(false);
			// Second Responsible
			
			centros.byId('treeTableCentros').mAggregations.columns[2].mAggregations.template.mAggregations.items[0].setVisible(false);
			centros.byId('treeTableCentros').mAggregations.columns[2].mAggregations.template.mAggregations.items[2].setVisible(false);
			
			
			
			//Inicio SPAU 02.10.2018
			
			var hbox = distView.mAggregations.content[0].mAggregations.items[0].byId('treeTableCentros').mAggregations.columns[0];
			
			$.each(hbox._aTemplateClones, function(a,b){
				b.getItems()[0].setVisible(false);
				b.getItems()[2].setVisible(false);
			});
			//Fin SPAU 02.10.2018
		},
		
		_getDistList: function(oController) {					
			var component = this;
			//Inicio PRL 16.09.2021: Solo hacemos la llamada si se ha cargado el contexto
			if(this.objectBinding ){
			if(this.oView.byId('distListView') && this.oView.mAggregations.content ){
				if(this.oView.mAggregations.content[0].mAggregations.items ){
			var currStatus = this.objectBinding.Status; 			
			var auditKey = this.objectBinding.DBKey; }
			}
			}else if(this.oView.byId('distListView')){
				if(this.oView.byId('distListView').getContent()[0].getItems()[2].byId('buttonDelete')!= undefined){
					this.oView.byId('distListView').getContent()[0].getItems()[2].byId('buttonDelete').setVisible(false);
					this.oView.byId('distListView').getContent()[0].getItems()[2].byId('buttonAdd').setVisible(false);
				}
				
			}
			//Fin PRL 16.09.2021
			var that = this;
			if(auditKey){
				// Fetching Distribution List
				var urlDist = "/InfoAuditListSet?$filter=Key eq binary'" + auditKey.replaceAll('-','') + "'&$expand=InfoUsersHierList,InfoUsersList,InfoUserDelegatedList";
				sap.ui.getCore().getModel("con").read(urlDist,{async: false, success: success, error: error });
				
			    function success(oData, oDataRes) {

			    	//var view = sap.ui.getCore().byId('listView');
			    	var view = that.oView;
			    	var distView = that.oView.byId('distListView');
			    	var accView = that.oView.byId('accListView');
			    	
			    	/**
			    	 * Emtpy table/list
			    	 */ 
			    	
			      	var table = distView.getContent()[0].getItems()[0].byId('treeTableCentros');
			    	if(table) {
			    		table.unbindRows();
			    		table.setVisibleRowCount(1);
			    	}

			    	var list = distView.getContent()[0].getItems()[1].byId('tablePersonas');
			    
			    	var template = that.template !== undefined ? that.template : list.mBindingInfos.items && list.mBindingInfos.items.template ? list.mBindingInfos.items.template : undefined;
                    if(template === undefined){
                    	template = new sap.m.ColumnListItem({
              cells : [  
                       new sap.m.Label({  
                           text : "{UserId}",
                       }), 
                 		new sap.m.Label({  
                           text : "{FullName}",
                        })
              ],
             customData: [new sap.ui.core.CustomData({
					key : "Id",
					value : "{id}"
			  })],
			  
			  
		});  
                    	
                    }			    	
                    
			    	that.template = template;
			   		if(list) {
			   			list.unbindAggregation("items");
			   		}
			   		distView.getContent()[0].getItems()[1].templateTable = template; 

			   		if(list) {
			   			list.unbindAggregation("items");
			   		}
			   		
			    	
			    	var list2 = distView.getContent()[0].getItems()[2].byId('tableDelegados');		    	
/* Inicio - Evitar Error HTTP request failed - ANB 31.08.2021 */
/* Código antiguo: */
//			    	
/* Código nuevo: */
					var template2 = that.template2 !== undefined ? that.template2 : list2.mBindingInfos.items !== undefined && list2.mBindingInfos.items.template !== undefined ? list2.mBindingInfos.items : undefined;
								    	
								    	if(template2 === undefined){
//PRL
								    		var hBox = new sap.m.HBox({
								    			items: [
								    			    new sap.ui.core.Icon({  
								    	                src : "sap-icon://sys-minus",  
								    	                size : "15px",  
								    	                color : "#ff0000",
								    	                width : "15px",
								    	                press: function (oEvent){
								    	      			var bindingContext = oEvent.getSource().getBindingContext().sPath;
								    	                  var viewName = oEvent.getSource().getParent().getParent().getParent().getParent().getParent();
								    	                  var table = viewName.byId('tableDelegados');
								    	                  var oModel = table.getModel();                        
								    	                  var dele = oModel.getProperty(bindingContext);           
								    	                 var oData = oModel.getData();

								    	                 $.each(oData.results, function(i,n){ 
								    	             		if(n.UserId == dele.UserId) {
								    	             			n.DelegadoDel = 'true';       			       		
								    	             		}        		       		
								    	             	});
								    	                 
								    	                 oModel.setData(oData);
								    	          		table.setModel(oModel);
								    	          		table.updateBindings(true);
								    	              		
								    	      		},
								    	            }),
								    			    new sap.m.Text({     
								    			    	customData:  new sap.ui.core.CustomData({key:"{Id}"}),
								    					layoutData: new sap.m.FlexItemData({
								    						alignSelf: sap.m.FlexAlignSelf.Center,styleClass: "marginRight"})
								    					}).bindProperty("text",{
								    					    parts:[{path:"FullName"},
								    					           {path:"DelegadoDel"}],
								    					    formatter: 
								    						    function(FullNameResp1,DelUserResp1){
								    						    	if(FullNameResp1 != null && FullNameResp1 != undefined && FullNameResp1 != "") {
								    						    		if(DelUserResp1 == "false") {
								    						    			this.getParent().getAggregation("items")[1].removeStyleClass("lineThrough");
								    						    		}else if (DelUserResp1 == "true") {
								    						    			this.getParent().getAggregation("items")[1].addStyleClass("lineThrough");
								    						    		}
								    						    		this.getParent().setVisible(true);
								    						    		return FullNameResp1;
								    						    	}else {
								    						    		this.getParent().setVisible(false);
								    						    		return "";
								    						    	}
								    						     }
								    					     }),
								    					     
								    			       new sap.ui.core.Icon({  
								    		                src : "sap-icon://sys-add",  
								    		                size : "15px",  
								    		                color : "#007833",   
								    		                width : "15px",
								    		                press: function(oEvent){
								    		        			var bindingContext = oEvent.getSource().getBindingContext().sPath;
								    		                    var viewName = oEvent.getSource().getParent().getParent().getParent().getParent().getParent();
								    		                    var table = viewName.byId('tableDelegados');
								    		                    var oModel = table.getModel();                        
								    		                    var dele = oModel.getProperty(bindingContext);           
								    		                   var oData = oModel.getData();

								    		                   $.each(oData.results, function(i,n){ 
								    		               		if(n.UserId == dele.UserId) {
								    		               			n.DelegadoDel = 'false';       			       		
								    		               		}        		       		
								    		               	});
								    		                   
								    		                   oModel.setData(oData);
								    		            		table.setModel(oModel);
								    		            		table.updateBindings(true);
								    		                    
								    		                    
								    		                },
								    		            })
								    				]
								    		});

//PRL								    		
								    		template2 = new sap.m.ColumnListItem({
					              cells : [  
					                       new sap.m.Label({ text : "{UserId}"}),
					                       hBox
					                 	  ],
					              customData: [new sap.ui.core.CustomData({
										key : "Id",
										value : "{id}"
								  })],
								  
								  
							}); 
								    	}
								    	
/* Fin - Evitar Error HTTP request failed - ANB 31.08.2021 */		
			    	that.template2 = template2;
			   		if(list2) {
			   			list2.unbindAggregation("items");
			   		}
			   		distView.getContent()[0].getItems()[2].templateTable = template2;
			   		/**
			   		 * Getting buttons
			   		 */
			   	// Getting Distribution List Panel
			   		var distPanel = view.mAggregations.content[0].mAggregations.items[0]
					
					// Getting Access List Panel
					var accPanel =  view.mAggregations.content[0].mAggregations.items[1];
					
					// Getting Distribution List > Centers section
					var centros =  distView.getContent()[0].getItems()[0];
					var addCenterBtn = centros.byId('treeTableCentros').getToolbar().getContent()[4];
					
					// Getting Distribution List > People section
					var personas = distView.getContent()[0].getItems()[1];
					var addPeopleBtn = personas.byId('tablePersonas').getHeaderToolbar().getContent()[2];
					
					// Getting Distribution List > Delegate section
					var delegados = distView.getContent()[0].getItems()[2];
					var addDelegatesBtn = delegados.byId('tableDelegados').getHeaderToolbar().getContent()[2];
					
					// If any data fetched
			    	if(oData.results.length != 0) {
			    		// Center data
			    		var centerModel = new sap.ui.model.json.JSONModel();
			    		centerModel.setData(oData.results[0].InfoUsersHierList);
						table.setModel(transformJerarquia(centerModel));
						
						table.bindRows("/centros");  
//						table.bindRows({path:"/centros",parameters:{arrayNames:['0']}});
						
						if(oData.results[0].InfoUsersHierList.results.length > 0) {
							table.setVisibleRowCount(10);
						} else {
							table.setVisibleRowCount(1);
						}
			    		
				   		// People data
				   		var peopleData = new sap.ui.model.json.JSONModel();
/* Inicio - ANB - Botón de borrado segun si haya personas o no - 31.08.2021 */
/* Código nuevo: */
				   	 	var results = [];
				   	 	//si no se obtienen personas desde base de datos, se pone sin modo la tabla de personas
				   		if(oData.results[0].InfoUsersList === undefined){
				   			oData.results[0].InfoUsersList = [];
				   			oData.results[0].InfoUsersList.results = results;
				   			personas.byId('tablePersonas').setMode("None");	
				   		}else{
				   			//si se obtienen personas desde base de datos, se pone la tabla con modo borrado para mostrar botón de borrado
				   			personas.byId('tablePersonas').setMode("Delete");	
				   		}
/* Fin - ANB - Botón de borrado segun si haya personas o no - 31.08.2021 */
				   		peopleData.setData(oData.results[0].InfoUsersList);
				   		list.setModel(peopleData);
				   		list.bindAggregation("items", "/results", template);
				   		
				   		// Delegates data
				   		var delegateData = new sap.ui.model.json.JSONModel();
				   		if(oData.results[0].InfoUserDelegatedList === undefined){
	                        var results = [];
	                        oData.results[0].InfoUsersDeletatedList = [];
	                        oData.results[0].InfoUsersDeletatedList.results = results;
	                    
					   		}
				   		if(delegados.byId('buttonDelete')!==undefined){
				   		if(oData.results[0].InfoUserDelegatedList.results[0]=== undefined){
					   		delegados.byId('buttonDelete').setVisible(false);
					   		delegados.byId('buttonAdd').setVisible(false);	
				   		}else{
				   			delegados.byId('buttonDelete').setVisible(true);
					   		delegados.byId('buttonAdd').setVisible(true);	
				   		}}
				   		delegateData.setData(oData.results[0].InfoUserDelegatedList); 
				   		list2.setModel(delegateData);
				   		list2.bindAggregation("items", "/results", template2);
			    	} else{
			    		if(delegados.byId('buttonDelete')!==undefined){
				   		delegados.byId('buttonDelete').setVisible(false);
				   		delegados.byId('buttonAdd').setVisible(false);
			    		}
			    	}
			    	
			    	
			    	/**
			    	 * Preparing buttons by Status
			    	 */
			    	
			    	// Inicio MOD RTC539288 - error part de centres, es desplega malament		
					table.getToolbar().getContent()[3].setIcon("sap-icon://expand")
					// Fin MOD RTC539288 - error part de centres, es desplega malament	
			    	
					// If status is inside finalStatus array, then no editable buttons shall appear
					if(component._getInFinalStatus(currStatus)) {
						// Collapse Distribution List section and disable toolbar
						distPanel.setExpanded(false);
						disableToolbar(distPanel.getHeaderToolbar().getContent());
						addCenterBtn.setEnabled(false);
						addPeopleBtn.setEnabled(false);
						addDelegatesBtn.setEnabled(false);
						distPanel.mAggregations.content[0].mAggregations.content[1].mAggregations.content[1].setEnabled(false);
						accPanel.mAggregations.content[0].mAggregations.content[1].mAggregations.content[1].setEnabled(false);
						// Hide delete row
						table.getColumns()[table.getColumns().length-1].setVisible(false);
						
						component._hideAddSubsBtn(distView);
						// Hide Save footer
						distView.getContent()[1].setVisible(false);
						
						// Hide delete row
						list.setMode("None");
						// Loading Access List
							component._getAccList(auditKey);
//						}
					} else {
						// Expand Distribution List section and disable toolbar
						distPanel.setExpanded(true);
						enableToolbar(distPanel.getHeaderToolbar().getContent());
						if(oData.results.length == 0) {
				    		addCenterBtn.setEnabled(false);
				    		addPeopleBtn.setEnabled(false);
				    		addDelegatesBtn.setEnabled(false);

				    	} else {
				    		addCenterBtn.setEnabled(true);
				    		addPeopleBtn.setEnabled(true);
				    		addDelegatesBtn.setEnabled(true);

				    	}
						
						// Show delete row
						table.getColumns()[table.getColumns().length-1].setVisible(true);
						// If current audit is not in final state, there's no need to show Access List
						accPanel.setVisible(false);
					}
			    	
								
					//Se comprueba si está en el equipo y configura los botones
					component._checkEnabledTeamAdd();
			    
			    }// fin function oController
			    
			    function error(error) {
			    	alert("Error recuperando lista de distribución");
			    }
			}  
		},
		
        // Método que habilita/desabilita toolbar dependiendo del equipo
        _checkEnabledTeamAdd:function(){
        		var auditKey = this.objectBinding.DBKey;
        		var view = this.oView;		    	
        		var distPanel = view.mAggregations.content[0].mAggregations.items[0]									
				var accPanel =  view.mAggregations.content[0].mAggregations.items[1];

					if(!this._getInTeam(auditKey)){
						disableToolbar(distPanel.getHeaderToolbar().getContent());
						disableToolbar(accPanel.getHeaderToolbar().getContent());
						distPanel.mAggregations.content[0].mAggregations.content[1].mAggregations.content[1].setEnabled(false);
						accPanel.mAggregations.content[0].mAggregations.content[1].mAggregations.content[1].setEnabled(false);
					}else{
						enableToolbar(distPanel.getHeaderToolbar().getContent());
						enableToolbar(accPanel.getHeaderToolbar().getContent());
						distPanel.mAggregations.content[0].mAggregations.content[1].mAggregations.content[1].setEnabled(true);
						accPanel.mAggregations.content[0].mAggregations.content[1].mAggregations.content[1].setEnabled(true);

					}
        },
		_getAccList: function(auditKey) {
			
			if(auditKey){
				// Fetching Access List							
				var that = this;
				var urlAcc = "/InfoAuditAccListSet?$filter=Key eq binary'" + auditKey.replaceAll('-','') + "'&$expand=InfoUsersHierList,InfoUsersList,InfoUserDelegatedList";
				sap.ui.getCore().getModel("con").read(urlAcc,{async: false, success: successAcc, error: errorAcc });
			    
				function successAcc(oData, oDataRes) { 
			    	var view = that.oView;
			    	var accView = that.oView.byId('accListView');
			    	var table = accView.getContent()[0].getItems()[0].byId('treeTableCentros');
			    	// Inicio MOD RTC539288 - error part de centres, es desplega malament		
					table.getToolbar().getContent()[3].setIcon("sap-icon://expand")
					// Fin MOD RTC539288 - error part de centres, es desplega malament	
			    	var list = accView.getContent()[0].getItems()[1].byId('tablePersonas');
			    	var template = list.mBindingInfos.items.template;
			    	var list2 = accView.getContent()[0].getItems()[2].byId('tableDelegados');
			    	var template2 = list2.mBindingInfos.items.template;
			    	
			    	if(oData.results.length != 0) {
				    	
				    	// Expand Distribution List section and disable toolbar
				    	accView.getParent().setExpanded(true);
				    	
			    		// Center data
			    		var oModel = new sap.ui.model.json.JSONModel();
						oModel.setData(oData.results[0].InfoUsersHierList);
						table.setModel(Model.transformJerarquia(oModel));
						table.bindRows("/centros");
//						table.bindRows({path:"/centros",parameters:{arrayNames:['0']}});
						if(oData.results[0].InfoUsersHierList.results.length > 0) {
							table.setVisibleRowCount(10);
						} else {
							table.setVisibleRowCount(1);
						}
			    		
				   		// People data
				   		var peopleData = new sap.ui.model.json.JSONModel();
				   		peopleData.setData(oData.results[0].InfoUsersList);
				   		list.setModel(peopleData);
				   		list.bindAggregation("items", "/results", template);
				   		
				   		// Delegate data
				   		var delegatesData = new sap.ui.model.json.JSONModel();
				   		delegatesData.setData(oData.results[0].InfoUserDelegatedList);
				   		list2.setModel(delegatesData);
				   		list2.bindAggregation("items", "/results", template2);
				   		
				   		disableToolbar(accView.getParent().getHeaderToolbar().getContent());
			    	} else {
			    		if(this.done) { // If we have already save a Acc list, but we still have no data -> DO NOTHING

			    			// Add empty model to center table
							table.setModel(new sap.ui.model.json.JSONModel());
							
							// Add empty model to people list
					   		list.setModel(new sap.ui.model.json.JSONModel());
					   		
							// Add empty model to delegates list
					   		list2.setModel(new sap.ui.model.json.JSONModel());
					   		
			    		} else {
			    			var distView = that.oView.byId('distListView');
			    			var table = distView.getContent()[0].getItems()[0].byId('treeTableCentros');
					    	var list = distView.getContent()[0].getItems()[1].byId('tablePersonas');
					    	var template = list.mBindingInfos.items.template;
					    	var list2 = distView.getContent()[0].getItems()[2].byId('tableDelegados');
					    	var template2 = list2.mBindingInfos.items.template;
					   			   		
					    	var listaCentros = [];
					    	if(table.getModel()) {
					    		if(table.getModel().getData().centros) {
				    				var oModelCentros = Model.aplanarJerarquia(table.getModel().getData().centros);
				    				if(oModelCentros.getData().centros != undefined){
				    					if(oModelCentros.getData().centros.length > 0){
				    						$.each(oModelCentros.getData().centros,function(i,n){
				    							listaCentros.push({Company: n.Company, Department: n.Department, FirstNode: transformStringToBool(n.FirstNode),DelUserResp1: UtilList.transformStringToBool(n.DelUserResp1), DelUserResp2: UtilList.transformStringToBool(n.DelUserResp2)})
				    						});
				    					}
				    				}
				    			} else {
				    				listaCentros = [{}];
				    			}
					    	} else {
			    				listaCentros = [{}];
			    			}
			    				
				    		
			    			var oModelPersonas = list.getModel();
			    			var listaPersonas = [];
			    			if(oModelPersonas) {
			    				if(oModelPersonas.getData().results != undefined){
				    				if(oModelPersonas.getData().results.length > 0){
				    					$.each(oModelPersonas.getData().results,function(i,n){
				    						listaPersonas.push({UserId: n.UserId});
				    					});
				    				}
				    			}else{
				    				listaPersonas = [{}];
				    			}
			    			}else{
			    				listaPersonas = [{}];
			    			}
			    			
			    			var oModelDelegados = list.getModel();
			    			var listaDelegados = [];
			    			if(oModelDelegados) {
			    				if(oModelDelegados.getData().results != undefined){
				    				if(oModelDelegados.getData().results.length > 0){
				    					$.each(oModelDelegados.getData().results,function(i,n){
				    						listaDelegados.push({UserId: n.UserId});
				    					});
				    				}
				    			}else{
				    				listaDelegados = [{}];
				    			}
			    			}else{
			    				listaDelegados = [{}];
			    			}
			    			
			    			//debugger
			    			//Creamos la entidad lista que pasaremos por parametro
			    			var oLista = {};
			    			oLista.Key = Util.recoverKey(auditKey);
			    			oLista.InfoUsersDeep = listaPersonas.length > 0 ? listaPersonas : [{}];
			    			oLista.InfoUserDelegatesDeep = listaDelegados.length > 0 ? listaDelegados : [{}];
			    			oLista.InfoDepatmentsDeep = listaCentros.length > 0 ? listaCentros : [{}];

			    			var url = "/InfoAuditAccListDeepSet";
						    sap.ui.getCore().getModel("con").refreshSecurityToken();
							sap.ui.getCore().getModel("con").create(url,oLista,{async: false, success: success, error: error });
							
							function success(oData, oDataRes) {
								var urlAcc = "/InfoAuditAccListSet?$filter=Key eq binary'" + auditKey.replaceAll('-','') + "'&$expand=InfoUsersHierList,InfoUsersList,InfoUserDelegatedList";
							    sap.ui.getCore().getModel("con").read(urlAcc,{async: false, success: successAcc.bind({done:"y"}), error: errorAcc });
							}
							
							function error(error) {
								alert("Error creando lista de acceso");
							}
			    		}
			    		
			    	}
			    }
			    
			    function errorAcc(error){
			    	alert("Error recuperando lista de acceso");
			    }
			}
		},
		
		onAddDist: function(oEvent) { 
			var o18nmModel = this.getOwnerComponent().getModel('i18nm');
			var oController = this;
			
			if(sap.ui.getCore().getComponent('searchComponent')) {
				sap.ui.getCore().getComponent('searchComponent').destroy();
			}
			var oComp  = sap.ui.getCore().createComponent({
				id: "searchComponent",
		        name: "sap.grc.acs.aud.audit.initiate.extended.block.searchComponent"
		    });
			
			// Función de añadir resultados a las tablas
			var addFunct =function() {
				var selItems = this.getParent().getContent()[1].getSelectedItems();
				
				if(selItems.length == 0) { alert(o18nmModel.getResourceBundle().getText("select_option")); }
				else {
					var bindingContext = selItems[0].getBindingContext().sPath;
					var data= sap.ui.component('searchComponent').table.getModel().getProperty(bindingContext);
					
					// Recuperamos las URL para el detalle de los centros
					var uriCentros = data.InfoUsersHierListSet.__deferred.uri;
					uriCentros = uriCentros.substring(uriCentros.indexOf("/InfoListsSet"));
					loadCData(uriCentros, sap.ui.component('searchComponent').oControllerView.byId('distListView').getContent()[0].getItems()[0]);
					// Recuperamos las URL para el detalle de las personas
					var uriPersonas = data.InfoUsersListSet.__deferred.uri;
					uriPersonas = uriPersonas.substring(uriPersonas.indexOf("/InfoListsSet"));
					loadPData(uriPersonas, sap.ui.component('searchComponent').oControllerView.byId('distListView').getContent()[0].getItems()[1]);
					// Recuperamos las URL para el detalle de los delegados
					if (data.InfoUserDelegatedListSet){ 
					//Cuando nos confirmen que han creado el campo InfoUserDelegatedListSet, borraremos el if
					var uriDelegados = data.InfoUserDelegatedListSet.__deferred.uri;
					uriDelegados = uriDelegados.substring(uriDelegados.indexOf("/InfoListsSet"));
					loadDData(uriCentros, sap.ui.component('searchComponent').oControllerView.byId('distListView').getContent()[0].getItems()[2]);
					}

					
					// Getting Distribution List > Centers section
					var centros = sap.ui.component('searchComponent').oControllerView.byId('distListView').getContent()[0].getItems()[0];
					var addCenterBtn = centros.byId('treeTableCentros').getToolbar().getContent()[4];
					addCenterBtn.setEnabled(true);
					
					// Getting Distribution List > People section
					var personas = sap.ui.component('searchComponent').oControllerView.byId('distListView').getContent()[0].getItems()[1];
					var addPeopleBtn = personas.byId('tablePersonas').getHeaderToolbar().getContent()[2];
					
					addPeopleBtn.setEnabled(true);
					
					// Getting Distribution List > Delegates section
					var delegados = sap.ui.component('searchComponent').oControllerView.byId('distListView').getContent()[0].getItems()[2];
					var addDelegatesBtn = delegados.byId('tableDelegados').getHeaderToolbar().getContent()[2];
					addDelegatesBtn.setEnabled(true);
					centros.getContent()[0].getItems()[0].getToolbar().setEnabled(true);
					personas.byId('tablePersonas').getHeaderToolbar().setEnabled(true);
					delegados.byId('tableDelegados').getHeaderToolbar().setEnabled(true);
					this.getParent().close();
				}};
				
			 //Creo ola funcio a anira al search del search field
		    var addSearchFunct = function(){ 
		    	//Agafo el valor del serchfield
		    	var text = this.getParent().getContent()[0].getProperty("value");
		    	if (text != ""){
		    	//Preparo els filtres amb els valors
		    	var aFilters = [];
		    		/*if(tieneNumeros(text))//Si conté numeros es que cerquen per matricula
		    			aFilters.push(new sap.ui.model.Filter("Id",sap.ui.model.FilterOperator.Contains, text));
		    		else*/
		    			aFilters.push(new sap.ui.model.Filter("ListName",sap.ui.model.FilterOperator.Contains, text));
		    		loadAddData("/InfoListsSet", aFilters);
		    	}
		    	
		    }
				
			// Cabecera, Binding Posiciones, Modo de Lista, Binding Aggregation, Path, Model, AddFunction
			oComp.setupInicial([o18nmModel.getResourceBundle().getText("department"), o18nmModel.getResourceBundle().getText("group"), o18nmModel.getResourceBundle().getText("list_name")], ["{Department} - {DepartmentName}", "{AudGroup} - {GroupName}", "{ListName}"], "SingleSelect", "", "/results", "distList", addFunct, addSearchFunct,this.oView);
		    

			// Se crea un contenedor para el componente
			var oCompCont = new sap.ui.core.ComponentContainer({
				 component: oComp,
			});
		},
		
		onAddAcc: function() { 
			var oController = this;
			var o18nmModel = this.getOwnerComponent().getModel('i18nm');
			if(sap.ui.getCore().getComponent('searchComponent')) {
				sap.ui.getCore().getComponent('searchComponent').destroy();
			}
			var oComp  = sap.ui.getCore().createComponent({
				id: "searchComponent",
			    name: "sap.grc.acs.aud.audit.initiate.extended.block.searchComponent"
			});
			
			// Función de añadir resultados a las tablas
			var addFunct =function() {
				var selItems = this.getParent().getContent()[1].getSelectedItems();
				
				if(selItems.length == 0) { alert(o18nmModel.getText("select_option")); }
				else {
					var bindingContext = selItems[0].getBindingContext().sPath;
					//var id = selItems[0].getAggregation("customData")[0].getValue("Key");
					//var data = sap.ui.getCore().getModel('distList').getProperty(bindingContext);
					var data= sap.ui.component('searchComponent').table.getModel().getProperty(bindingContext);
					
					// Recuperamos las URL para el detalle de los centros
					var uriCentros = data.InfoUsersHierListSet.__deferred.uri;
					uriCentros = uriCentros.substring(uriCentros.indexOf("/InfoListsSet"));
					loadCData(uriCentros, sap.ui.component('searchComponent').oControllerView.byId('accListView').getContent()[0].getItems()[0]);
					// Recuperamos las URL para el detalle de las personas
					var uriPersonas = data.InfoUsersListSet.__deferred.uri;
					uriPersonas = uriPersonas.substring(uriPersonas.indexOf("/InfoListsSet"));
					loadPData(uriPersonas, sap.ui.component('searchComponent').oControllerView.byId('accListView').getContent()[0].getItems()[1]);
					// Recuperamos las URL para el detalle de los delegados
					var uriDelegados = data.InfoUserDelegatedListSet.__deferred.uri;
					uriDelegados = uriDelegados.substring(uriDelegados.indexOf("/InfoListsSet"));
					loadDData(uriDelegados, sap.ui.component('searchComponent').oControllerView.byId('accListView').getContent()[0].getItems()[2]);
					
					// Getting Distribution List > Centers section
					var centros = sap.ui.component('searchComponent').oControllerView.byId('accListView').getContent()[0].getItems()[0];
					var addCenterBtn = centros.table.getToolbar().getContent()[4];
					addCenterBtn.setEnabled(true);
					
					// Getting Distribution List > People section
					var personas = sap.ui.component('searchComponent').oControllerView.byId('accListView').getContent()[0].getItems()[1];
					var addPeopleBtn = personas.listContainer.getHeaderToolbar().getContent()[2];
					addPeopleBtn.setEnabled(true);
					
					// Getting Distribution List > Delegates section
					var delegados = sap.ui.component('searchComponent').oControllerView.byId('accListView').getContent()[0].getItems()[2];
					var addDelegatesBtn = delegados.listContainer.getHeaderToolbar().getContent()[2];
					addDelegatesBtn.setEnabled(true);
					
					centros.table.getToolbar().setEnabled(true);
					personas.listContainer.getHeaderToolbar().setEnabled(true);
					delegados.listContainer.getHeaderToolbar().setEnabled(true);
			 
					this.getParent().close();
				}};
				
			 //Creo la funcio a anira al search del search field
			var addSearchFunct = function(){
				//Agafo el valor del serchfield
				var text = this.getParent().getContent()[0].getProperty("value");
				if (text != ""){
				//Preparo els filtres amb els valors
				var aFilters = [];
					/*if(tieneNumeros(text))//Si conté numeros es que cerquen per matricula
						aFilters.push(new sap.ui.model.Filter("Id",sap.ui.model.FilterOperator.Contains, text));
					else*/
						aFilters.push(new sap.ui.model.Filter("ListName",sap.ui.model.FilterOperator.Contains, text));
					loadAddData("/InfoListsSet", aFilters);
				}
				
			} 
				
			// Cabecera, Binding Posiciones, Modo de Lista, Binding Aggregation, Path, Model, AddFunction
			oComp.setupInicial([o18nmModel.getResourceBundle().getText("department"), o18nmModel.getResourceBundle().getText("group"), o18nmModel.getResourceBundle().getText("list_name")], ["{Department} - {DepartmentName}", "{AudGroup} - {GroupName}", "{ListName}"], "SingleSelect", "", "/results", "accList", addFunct, addSearchFunct,this.oView);

			
			// Se crea un contenedor para el componente
			var oCompCont = new sap.ui.core.ComponentContainer({
				 component: oComp,
			});
		},
		
		onDeleteDist: function() {
			var centros = this.oView.byId('distListView').getContent()[0].getItems()[0];
			centros.byId('treeTableCentros').unbindRows();
			centros.byId('treeTableCentros').setVisibleRowCount(1);
			//Inicio PRL 08092021: Se dado casos en los que getdata viene undefined, controlamos para evitar error en consola
			if(centros.byId('treeTableCentros').getModel().getData()!==undefined){
			//Fin PRL 08092021: Se dado casos en los que getdata viene undefined, controlamos para evitar error en consola	
			centros.byId('treeTableCentros').getModel().getData().centros = [];
			}
			
			centros.byId('treeTableCentros').getToolbar().setEnabled(false);
			
			//var personas = sap.ui.getCore().byId('distListView').personas;
			var personas = this.oView.byId('distListView').getContent()[0].getItems()[1];			
			personas.byId('tablePersonas').unbindAggregation("items");
			//Inicio PRL 08092021: Se dado casos en los que getdata viene undefined, controlamos para evitar error en consola
			if(personas.byId('tablePersonas').getModel().getData()!==undefined){
			//Fin PRL 08092021: Se dado casos en los que getdata viene undefined, controlamos para evitar error en consola	
			personas.byId('tablePersonas').getModel().getData().results = [];
			}
			personas.byId('tablePersonas').getAggregation("headerToolbar").setEnabled(false);
							
			var delegados = this.oView.byId('distListView').getContent()[0].getItems()[2];			
			delegados.byId('tableDelegados').unbindAggregation("items");
			//Inicio PRL 08092021: Se dado casos en los que getdata viene undefined, controlamos para evitar error en consola
			if(delegados.byId('tableDelegados').getModel().getData()!==undefined){
			//Fin PRL 08092021: Se dado casos en los que getdata viene undefined, controlamos para evitar error en consola	
			delegados.byId('tableDelegados').getModel().getData().results = [];
			}
			delegados.byId('tableDelegados').getAggregation("headerToolbar").setEnabled(false);
		},
		
		
		onDeleteAcc: function() {
//			var centros = this.oView.byId('accListView').getContent()[0].getItems()[0];
//			sap.ui.getCore().byId('centrosView4').oTable.unbindRows();
//			sap.ui.getCore().byId('centrosView4').oTable.setVisibleRowCount(1);
//			sap.ui.getCore().byId('personasView4').listContainer.unbindAggregation("items");
//			sap.ui.getCore().byId('delegadosView4').listContainer.unbindAggregation("items");
//			sap.ui.getCore().byId('centrosView4').oTable.getToolbar().setEnabled(false);
//			sap.ui.getCore().byId('personasView4').listContainer.getAggregation("headerToolbar").setEnabled(false);
//			sap.ui.getCore().byId('delegadosView4').listContainer.getAggregation("headerToolbar").setEnabled(false);
			

			var centros = this.oView.byId('accListView').getContent()[0].getItems()[0];
			centros.byId('treeTableCentros').unbindRows();
			centros.byId('treeTableCentros').setVisibleRowCount(1);
			//Inicio PRL 08092021: Se dado casos en los que getdata viene undefined, controlamos para evitar error en consola
			if(centros.byId('treeTableCentros').getModel().getData()!==undefined){
			//Fin PRL 08092021: Se dado casos en los que getdata viene undefined, controlamos para evitar error en consola
			centros.byId('treeTableCentros').getModel().getData().centros = [];}
			centros.byId('treeTableCentros').getToolbar().setEnabled(false);
			
			//var personas = sap.ui.getCore().byId('distListView').personas;
			var personas = this.oView.byId('accListView').getContent()[0].getItems()[1];			
			personas.byId('tablePersonas').unbindAggregation("items");
			//Inicio PRL 08092021: Se dado casos en los que getdata viene undefined, controlamos para evitar error en consola
			if(personas.byId('tablePersonas').getModel().getData()!==undefined){
			//Fin PRL 08092021: Se dado casos en los que getdata viene undefined, controlamos para evitar error en consola	
			personas.byId('tablePersonas').getModel().getData().results = [];}
			personas.byId('tablePersonas').getAggregation("headerToolbar").setEnabled(false);
							
			var delegados = this.oView.byId('accListView').getContent()[0].getItems()[2];			
			delegados.byId('tableDelegados').unbindAggregation("items");
			//Inicio PRL 08092021: Se dado casos en los que getdata viene undefined, controlamos para evitar error en consola
			if(delegados.byId('tableDelegados').getModel().getData()!==undefined){
			//Fin PRL 08092021: Se dado casos en los que getdata viene undefined, controlamos para evitar error en consola
			delegados.byId('tableDelegados').getModel().getData().results = [];}
			delegados.byId('tableDelegados').getAggregation("headerToolbar").setEnabled(false);
		}
		
	})
})
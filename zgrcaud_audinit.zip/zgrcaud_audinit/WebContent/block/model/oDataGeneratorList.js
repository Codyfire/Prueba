function loadOData(){
	var oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZGRCAUD_PORTAL_SRV/", false);
	oDataModel.refreshSecurityToken();
	
	//Creo els models que he de tenir preparats
	var oModel = new sap.ui.model.json.JSONModel();
	sap.ui.getCore().setModel(oModel,"centros"); 
	var oDuplicateModel = new sap.ui.model.json.JSONModel();
	sap.ui.getCore().setModel(oDuplicateModel,"duplicate");
	
	oDataModel.read("/InfoListsSet", null, null, false,
		function(data,response){
			console.log(data);
			var oModel = new sap.ui.model.json.JSONModel();
			oModel.setData(data);
			sap.ui.getCore().setModel(oModel,"distList");
			byId("adminListDistr").bindAggregation("","/results/" , byId("adminListDistr").template);
			byId("adminListDistr").setModel(sap.ui.getCore().getModel("distList"));
		},function(oError){
			console.log(oError);
	});
} 

//Funci�n que carga los centros de un registro
function loadCData(url, viewName) {
	var oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZGRCAUD_PORTAL_SRV/", false);
	oDataModel.read(url, null, null, false,
		function(data,response){
			var oModel = new sap.ui.model.json.JSONModel();
			oModel.setData(data);
			//var table = sap.ui.getCore().byId(viewName).table;
			//var table = viewName.getContent()[0].getItems()[0];
			var table = viewName.byId('treeTableCentros');  
			table.setModel(transformJerarquia(oModel));
//			table.bindRows("/centros");
			table.bindRows({path:"/centros"});
			table.setVisibleRowCount(10);
			
			refrescarEstilsTaula(table);
		},function(oError){
			console.log(oError);	
	});
}

//Funci�n que carga las personas de un registro
function loadPData(url, viewName) {
	var oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZGRCAUD_PORTAL_SRV/", false);
	oDataModel.read(url, null, null, false,
		function(data,response){
			var oModel = new sap.ui.model.json.JSONModel();
			oModel.setData(data);
			var list = viewName.byId('tablePersonas');
			//var template = viewName.template;
			//var list = sap.ui.getCore().byId(viewName).listContainer;
			//var template = viewName.byId('tablePersonas').mBindingInfos.items.template;			
			list.setModel(oModel);
			list.bindAggregation("items", "/results/", viewName.templateTable);
			list.bindItems("/results/", viewName.templateTable);
/* Inicio - ANB - Botón de borrado segun si haya personas o no - 31.08.2021 */
/* Código nuevo: */
			//si hay restultados en la lista de personas, se pone la tabla en modo delete para mostrar botón de borrado
			if(list.getModel().oData.results.length>0){
				list.setMode("Delete");
			}else{
				//si no hay personas en la lista, se pone la tabla sin modo para no mostrar botón de borrado
				list.setMode("None");
			}
/* Fin - ANB - Botón de borrado segun si haya personas o no - 31.08.2021 */
		},function(oError){
			console.log(oError);		
	});
}

//Funci�n que carga los delegados de un registro
function loadDData(url, viewName) {
	var oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZGRCAUD_PORTAL_SRV/", false);
	oDataModel.read(url, null, null, false,
		function(data,response){
			var oModel = new sap.ui.model.json.JSONModel();
			oModel.setData(data);
			//var list = sap.ui.getCore().byId(viewName).listContainer;
			var list = viewName.byId('tableDelegados'); 
			//var template = sap.ui.getCore().byId(viewName).template;
			//var template = viewName.byId('tablePersonas').mBindingInfos.items.template;
			list.setModel(oModel);
			list.bindAggregation("items", "/results/", viewName.templateTable);
			list.bindItems("/results/", viewName.templateTable);
//PRL
			if(viewName.byId('buttonDelete')!==undefined){
			if(list.getModel().oData.results.length>0){
				
				viewName.byId('buttonDelete').setVisible(false);
				viewName.byId('buttonAdd').setVisible(false);
				}else{
					viewName.byId('buttonDelete').setVisible(true);
					viewName.byId('buttonAdd').setVisible(true);	
				}
			}
//PRL			
		},function(oError){
			console.log(oError);		
	});
}

function loadAddData(url,aFilters,strFilter) {
	var oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZGRCAUD_PORTAL_SRV/", false);
	if(strFilter != undefined && strFilter != null) {
		oDataModel.read(url+strFilter,{
			//filters : aFilters,
			async: false,
		    success : function (oData) {
		       jQuery.sap.log.info("Odata Read Successfully:::");
		       console.log(oData);
		   		var oModel = new sap.ui.model.json.JSONModel();
		   		oModel.setData(oData);
		   		sap.ui.getCore().setModel(oModel,"centrosSearch");
		   		sap.ui.getCore().getModel("centrosSearch").iSizeLimit=200;
		   		sap.ui.getCore().getComponent("searchComponent").table.setModel(oModel);
		    }.bind(this),
		    error: function (oError) {
		    	console.log(oError);	
		    }.bind(this)
		});
	} else {
		oDataModel.read(url,{
			filters : aFilters,
			async: false,
		    success : function (oData) {
		       jQuery.sap.log.info("Odata Read Successfully:::");
		       console.log(oData);
		   		var oModel = new sap.ui.model.json.JSONModel();
		   		oModel.setData(oData);
		   		sap.ui.getCore().setModel(oModel,"centrosSearch");
		   		sap.ui.getCore().getModel("centrosSearch").iSizeLimit=200;
		   		sap.ui.getCore().getComponent("searchComponent").table.setModel(oModel);
		    }.bind(this),
		    error: function (oError) {
		    	console.log(oError);	
		    }.bind(this)
		});
	}
	
}

//--------------------> Listas section <------------------------//

function loadHeaderData(url) {
	var oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZGRCAUD_PORTAL_SRV/", false);
	oDataModel.read(url, null, null, false,
		function(data,response){
			 var oModel = new sap.ui.model.json.JSONModel();
			  oModel.setData(data);
			  async:false, 
			  sap.ui.getCore().setModel(oModel,"listAreas");
		},function(oError){
			console.log(oError);		
	});
}

function createHeaderList(url,oLista){
	var oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZGRCAUD_PORTAL_SRV/", false);
	oDataModel.create(url,oLista,function(dataResp){
		console.log(dataResp);
	},function(oError){
		console.log(oError);
	});
}

function updateHeaderList(oLista){
	var oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZGRCAUD_PORTAL_SRV/", false);
	//var keyConverted = "binary'" + convertKey(key) +"'";
	var url = "/InfoListsDeepSet";
	oDataModel.create(url,oLista,function(dataResp){
		console.log(dataResp);
	},function(oError){
		console.log(oError);
	});
}

//Funci� per eliminar una llista, sa li ha de passar la key de la entitat
function deleteList(key){
	var oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZGRCAUD_PORTAL_SRV/", false);
	//Genero la clau binaria i formo la url
	var keyConverted = "binary'" + convertKey(key) +"'";
    var url = getListasUrl() + "(" + keyConverted + ")";
    //Elimino l'usuari
    oDataModel.remove( url ,false, 
		function(oDataRes, oResponse){
			loadOData();
	        sap.m.MessageToast.show("Lista borrada correctamente!", {duration: 1000});       
    	},function(oData, oResponse){
    		console.error('Error al borrar grupo!');
    });
}
//--------------------> end section <-------------------------------//

function loadHeaderGData(url) {
	var oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZGRCAUD_PORTAL_SRV/", false);
	oDataModel.read(url, null, null, false,
		function(data,response){
			 var oModel = new sap.ui.model.json.JSONModel();
			 oModel.setData(data);
			 async:false, 
			 sap.ui.getCore().setModel(oModel,"listGrupos");
		},function(oError){
			console.log(oError);	
	});
}

function addPersonasLdap(url, aFilters){
	//Faig el read dels usuaris que tinguin el displayuser a true
	var oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZGRCAUD_PORTAL_SRV/", false);	
	oDataModel.read(url,{
		filters : aFilters,
		async: true,
		success : function (oData) {
			var oModel = new sap.ui.model.json.JSONModel();
			oModel.setData(oData);
			sap.ui.getCore().setModel(oModel,"ldap");
			sap.ui.getCore().getModel("ldap").iSizeLimit=200;
			sap.ui.getCore().getComponent('searchComponent').table.setModel(sap.ui.getCore().getModel("ldap"));
		}.bind(this),
		error: function (oError) {
			jQuery.sap.log.info("Odata Error occured");
		}.bind(this)
	});
}

function addDelegadosLdap(url, aFilters){
	//Faig el read dels usuaris que tinguin el displayuser a true
	var oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZGRCAUD_PORTAL_SRV/", false);		
	oDataModel.read(url,{
		filters : aFilters,
		async: true,
		success : function (oData) {
			var oModel = new sap.ui.model.json.JSONModel();
			oModel.setData(oData);
			sap.ui.getCore().setModel(oModel,"ldap");
			sap.ui.getCore().getModel("ldap").iSizeLimit=200;
			sap.ui.getCore().getComponent('searchComponent').table.setModel(sap.ui.getCore().getModel("ldap"));
		}.bind(this),
		error: function (oError) {
			jQuery.sap.log.info("Odata Error occured");
		}.bind(this)
	});
}


//--------------------> Jerarquias section <------------------------//

//Funci�n que carga la jerarquia que le pedimos de forma plana
function loadJerarquia(url, viewName) {
	var oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZGRCAUD_PORTAL_SRV/", false);		
	oDataModel.read(url, null, null, false,
		function(oData,response){
		var oModel = new sap.ui.model.json.JSONModel();  
		/**
		 * INI INC 829782 07.02.2020 Rafael Galán Baquero
		 * Código antiguo
		 * 		 
		 * oModel.setData(oData);
		 * var table = sap.ui.getCore().byId(viewName).table;
		 * código nuevo
		 */
		var oModel = new sap.ui.model.json.JSONModel();  
		//var table = sap.ui.getCore().byId(viewName).table;
		var table = viewName.byId('treeTableCentros');
		var itemsUser1 = [];
		var itemsUser2 = [];
		var userId;
		var userId2;		

		// Comprobación que el responsable no se encuentre en otro centro borrado 'tachado'
		$.each(oData.results,function(i,n){
			if(table != undefined){
			userId = n.UserIdResp1;
			userId2 = n.UserIdResp2;
			// Comprobamos si hay usuarios repetidos
			$.each(table.getModel().getData().centros,function(i,n){
				// Se obtiene el responsable 1 en caso de estar repetido en otro centro de la lista
				buscaUserIdResp1Repes(n,userId,itemsUser1);
				// Se obtiene el responsable 2 en caso de estar repetido en otro centro de la lista
				if(userId2 != undefined && userId2 != '')
				buscaUserIdResp2Repes(n,userId2,itemsUser2);

				});
				
			// Si ya aparece en otro centro, comprobamos que no esté borrado 'tachado'
				if(itemsUser1.length > 0 || itemsUser2.length > 0){
					var del1 = "false";
					var del2 = "false";
					
					// Si aparece borrado, se informa la variable del a true para el usuarioResp1
						$.each(itemsUser1, function(i,n){
							if(n.DelUserResp1 == "true"){
							del1 = "true";
						
							}							
					});
						
						// Si aparece borrado, se informa la variable del a true para el usuarioResp1
						$.each(itemsUser2, function(i,n){
							if(n.DelUserResp2 == "true"){
							del2 = "true";
						
							}							
					});
					// Se asigna el valor de del para usuario1 y usuario2 (true si ya se encuentra como borrado, false en caso contrario)
					n.DelUserResp1 = del1;
					n.DelUserResp2 = del2;
				}		

			}		
		})
		
			// se asigna el centro añadido al modelo
		oModel.setData(oData);
		/**
		 * FIN INC 829782 07.02.2020 Rafael Galán Baquero
		 */
		
		anadirObjetoACentros(transformJerarquia(oModel).getData().centros[0], table);
		table.bindRows("/centros");
		table.setVisibleRowCount(10);
// Inicio MOD RTC539288 - error part de centres, es desplega malament		
		table.getToolbar().getContent()[3].setIcon("sap-icon://expand")
// Fin MOD RTC539288 - error part de centres, es desplega malament		
	},function(oError){
		console.log(oError);	
	});
}

//Funci�n que pasa de una jerarquia plana a una jerarquia en arbol
function transformJerarquia(model){
	if(model){
		var oModel = new sap.ui.model.json.JSONModel(); 
		oModel.oData.centros = [];
		var nodoPadre;
		var i = 0;
		model.getData().results.forEach(function(n){
			if(n.FirstNode == "true"){
				index = '"' + i + '"';
				oModel.oData.centros.push(n);
				delete n.__metadata;
				nodoPadre = n;
				nodoPadre.centros = [];
			}else{
				pushCentro(nodoPadre.centros,n);
				nodoPadre = n;
				delete n.__metadata;
				nodoPadre.centros = [];
			}
			i++;
		});
		
		var oJerarquiaArbolModel = new sap.ui.model.json.JSONModel();  
		oJerarquiaArbolModel.setData(oModel.getData());
		return oJerarquiaArbolModel;
	}
}

function pushCentro(nodoPadre,nodo){
	nodoPadre.push(nodo);
}

//Funcion que si encuentra algun array en la jerarquia lo transforma en un objeto
function transformJerarquiaToObjects(model){
	if(model){
		var oAuxModel = new sap.ui.model.json.JSONModel(); 
		oAuxModel.oData.centros = {};
		
		$.each(model.getData().centros,function(i,n){
			oAuxModel.oData.centros[i] = n;
			crearObjetoRecursiva(n,oAuxModel.oData.centros[i]);
		});
		
		var oJerarquiaArbolModel = new sap.ui.model.json.JSONModel();  
		oJerarquiaArbolModel.setData(oAuxModel.getData());
		return oJerarquiaArbolModel;
	}
}

//Funcion recursiva que se encarga de ir creando objetos dentro de objetos para asi eliminar arrays hasta llegar al final del arbol
function crearObjetoRecursiva(objeto,model){
	if(Array.isArray(objeto[0]) || typeof objeto === 'object'){
		if(objeto[0][0] != undefined){
			model[0] = objeto[0][0];
			if(objeto[0][0] != undefined){
				if(Array.isArray(objeto[0][0]) || typeof objeto[0][0] === 'object'){
					crearObjetoRecursiva(model[0],model[0]);
				}
			}
		}else{
			delete model[0];
		}
	}
}

//Esta funcion a�ade centros al modelo centros
function anadirObjetoACentros(obj, table){	
	if(table.getModel().getData().centros == undefined){
		//No hay ningun centro en el modelo
		table.getModel().getData().centros = [];
		table.getModel().getData().centros[0] = obj;
	}else{
//		var index = Object.keys(table.getModel().getData().centros).length;
//		table.getModel().getData().centros[index] = obj;
		var prob = 0;
		for(i=0;i<Object.keys(table.getModel().getData().centros).length;i++){
			if(prob < parseInt(Object.keys(table.getModel().getData().centros)[i])){
			console.log("in");
			prob =parseInt(Object.keys(table.getModel().getData().centros)[i]);
		 }}
		//Sugerencia
		//if(Object.keys(table.getModel().getData().centros).length !== 0)
		 //if(prob !==0)
		 	prob++;
		 	table.getModel().getData().centros[prob] = obj;
	 }
}
//--------------------> end section <-------------------------------//

//--------------------> Aplanar jerarquia section <-----------------//

//Funci�n que de una jerarquia en arbol la pasa a una jerarquia plana
function aplanarJerarquia(array){
	var oModel = new sap.ui.model.json.JSONModel();
	oModel.getData().centros = [];
	$.each(array,function(i,n){
		if(oModel.getData().centros !== undefined){
			oModel.getData().centros.push(n);
			sacarObjetosDeJerarquia(oModel.getData().centros,n);
			}
//		oModel.getData().centros.push(n);
//		sacarObjetosDeJerarquia(oModel.getData().centros,n);
	});
	
	return oModel;
}

//Funcion recursiva que saca todos los objetos de una jerarquia
function sacarObjetosDeJerarquia(model,node){
	if(node.centros[0] != undefined){
		model.push(node.centros[0]);
		sacarObjetosDeJerarquia(model,node.centros[0])
	}
}

//--------------------> end section <-------------------------------//

//Esta funcion a�ade personas al modelo personas
function anadirObjetoAPersonas(obj, list){
	if(list.getModel().getData().results == undefined){
		//No hay ningun centro en el modelo
		list.getModel().getData().results = [];
		list.getModel().getData().results[0] = obj;
	}else{
		var index = Object.keys(list.getModel().getData().results).length;
		list.getModel().getData().results[index] = obj;
	}
}

//Esta funcion a�ade delegados al modelo delegados
function anadirObjetoADelegados(obj, list){
	if(list.getModel().getData().results == undefined){
		//No hay ningun centro en el modelo
		list.getModel().getData().results = [];
		list.getModel().getData().results[0] = obj;
	}else{
		var index = Object.keys(list.getModel().getData().results).length;
		list.getModel().getData().results[index] = obj;
	}
}
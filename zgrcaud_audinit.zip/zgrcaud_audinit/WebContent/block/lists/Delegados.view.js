sap.ui.jsview("sap.grc.acs.aud.audit.initiate.extended.block.lists.Delegados", {

	/** Specifies the Controller belonging to this View. 
	* In the case that it is not implemented, or that "null" is returned, this View does not have a Controller.
	* @memberOf zportalaudit.view.Delegados
	*/ 
	getControllerName : function() {
		return "sap.grc.acs.aud.audit.initiate.extended.block.lists.Delegados";
	},

	/** Is initially called once after the Controller has been instantiated. It is the place where the UI is constructed. 
	* Since the Controller is given to this method, its event handlers can be attached right away. 
	* @memberOf zportalaudit.view.Delegados
	*/ 
	
	createContent : function(oController) {
		this.hBox = new sap.m.HBox({
			items: [
			    new sap.ui.core.Icon({  
	                src : "sap-icon://sys-minus",  
	                size : "15px",  
	                color : "#ff0000",
	                width : "15px", 
	                press: function(oEvent){
		                var bindingContext = oEvent.getSource().getBindingContext().sPath;
		                //var UserId = sap.ui.getCore().getModel("centros").getProperty(bindingContext).UserIdResp1;
		                var viewName = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getId();
		                //var UserId = sap.ui.getCore().byId(viewName).listContainer.getModel().getProperty(bindingContext).UserId;
		                sap.ui.getCore().byId(viewName).listContainer.getModel().getProperty(bindingContext).DelegadoDel = true;
//		                sap.ui.getCore().getModel("delegados").getProperty(bindingContext).DelegadoDel = true;
		                oEvent.getSource().getParent().getAggregation("items")[1].addStyleClass("lineThrough");
//		                updateDelUserResp1(UserId,"true",viewName);
	                }
	            }),
			    new sap.m.Text({     
			    	customData:  new sap.ui.core.CustomData({key:"{Key}"}),
					layoutData: new sap.m.FlexItemData({
						alignSelf: sap.m.FlexAlignSelf.Center,styleClass: "marginRight"})
					}).bindProperty("text",{
					    parts:[{path:"FullName"},
					    	   {path:"DelegadoDel"}],
					    formatter: 
						    function(fullName, delegadoDel){
					    		//debugger
					    	
					    		if(delegadoDel != undefined) {
					    			if(JSON.parse(delegadoDel))
						    			this.getParent().getAggregation("items")[1].addStyleClass("lineThrough");
						    		else 
						    			this.getParent().getAggregation("items")[1].removeStyleClass("lineThrough");
					    		}
					    		
					    		this.getParent().setVisible(true);
					    		return fullName != undefined ? fullName : "";
					    		
						     }
					     }),
			       new sap.ui.core.Icon({  
		                src : "sap-icon://sys-add",  
		                size : "15px",  
		                color : "#007833",   
		                width : "15px", 
		                press: function(oEvent){
			                var bindingContext = oEvent.getSource().getBindingContext().sPath;
			                //var UserId = sap.ui.getCore().getModel("centros").getProperty(bindingContext).UserIdResp1;
			                var viewName = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getId();
			                //var UserId = sap.ui.getCore().byId(viewName).listContainer.getModel().getProperty(bindingContext).UserIdResp1;
			                sap.ui.getCore().byId(viewName).listContainer.getModel().getProperty(bindingContext).DelegadoDel = false;
//			                sap.ui.getCore().getModel("delegados").getProperty(bindingContext).DelegadoDel = false;
			                oEvent.getSource().getParent().getAggregation("items")[1].removeStyleClass("lineThrough");
//			                updateDelUserResp1(UserId,"false", viewName);
			                
		                }
		            })
				]
		});
		
		//oController.loadData();
		var listContainer = new sap.m.Table(this.createId("delegados"),{
			headerToolbar: new sap.m.Toolbar({
				content:
					[
				         new sap.m.Label({text:sap.hpa.grcaud.enh_oBundle.getText("dest_delegates"), design: sap.m.LabelDesign.Bold}),
						 new sap.m.ToolbarSpacer(),
						 new sap.m.Button({icon: "sap-icon://add", visible: false, press: [oController.onAdd, oController]}),
					 ]
			}),
			columns : [
						  new sap.m.Column({  
							    hAlign : "Left",  
							    header : new sap.m.Label({  
							              text : sap.hpa.grcaud.enh_oBundle.getText("tag"),
							              design: sap.m.LabelDesign.Bold
							    })  
						   }),new sap.m.Column({  
					                 hAlign : "Left",  
					                 header : new sap.m.Label({  
					                           text : sap.hpa.grcaud.enh_oBundle.getText("name"),
					                           design: sap.m.LabelDesign.Bold
					                 	}) 
					       	 })  
				       ],
			width : "100%",
			height : "100%",
			mode: "None",
		});
		 
		 var itemTemplate = new sap.m.ColumnListItem({
              cells : [  
                       new sap.m.Label({ text : "{UserId}"}),
                       this.hBox
                 	  ],
              customData: [new sap.ui.core.CustomData({
					key : "Id",
					value : "{id}"
			  })],
			  
			  
		}); 
		
		this.listContainer = listContainer;
		this.template = itemTemplate;
		this.listContainer.template = itemTemplate;
			
		//listContainer.bindAggregation("items","/results", itemTemplate);
		return new sap.m.VBox({
			height: "100%",
			items: [this.listContainer]
		});
	}

});
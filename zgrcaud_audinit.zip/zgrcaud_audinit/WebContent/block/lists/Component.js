jQuery.sap.declare("sap.grc.acs.aud.audit.initiate.extended.block.lists.Component");
jQuery.sap.require("sap.ui.core.UIComponent");

sap.ui.core.UIComponent.extend("sap.grc.acs.aud.audit.initiate.extended.block.lists.Component", {
	     /*metadata: {
	         properties: {
	              itemsPerLine: {
	            		type: 'int',
	            		defaultValue: 7
	              },
	              addWhiteSpaces: {
	          		type: 'boolean',
	          		defaultValue: false
	              }
	         },
	         events: {
	            addNewItem: {
	            	parameters: {
	            		item: {
	            			type: 'string'
	            		}
	            	}
	            }
	         },
	   },*/
//	init: function() {
//	    // define variable for control initial loading handling
//	    this._bInitialLoading = true;
//		   // execute standard control method
//	    sap.ui.core.UIComponent.prototype.init.apply(this,arguments);
//	},
//		
//

	/** Is initially called once after the Controller has been instantiated. It is the place where the UI is constructed. 
	* Since the Controller is given to this method, its event handlers can be attached right away. 
	* @memberOf grcaud.lists.lists
	*/ 
	createContent : function() {
//		var oController = sap.ui.controller("resources.js.enhancements.lists.ListView");
//		
// 		var vBox = new sap.m.VBox({
//			height: "100%",
//			items: [
//			        new sap.m.Panel({
//			        	headerText: "Lista de Distribución",
//			        	headerToolbar: new sap.m.Toolbar({
//							content:
//								[
//							         new sap.m.Label({text:"Lista de Distribucion", design: sap.m.LabelDesign.Bold}),
//									 new sap.m.ToolbarSpacer(),
//									 //new sap.m.Button({icon: "sap-icon://edit", press: oController.onEditDist}),
//									 new sap.m.Button({icon: "sap-icon://add", press: [oController.onAddDist, oController]}),
//									 new sap.m.Button({icon: "sap-icon://delete", press: oController.onDeleteDist}),
//								 ]
//						}),
//			        	expandable: true,
//			        	expanded: true,
//			        	width: "auto",
//			        	content: [sap.ui.view({id:"distListView", viewName:"resources.js.enhancements.lists.AdminListasDetail", type:sap.ui.core.mvc.ViewType.JS})]
//			        }),
//			        new sap.m.Panel({
//			        	headerText: "Lista de Acceso",
//			        	headerToolbar: new sap.m.Toolbar({
//							content:
//								[
//							         new sap.m.Label({text:"Lista de Acceso", design: sap.m.LabelDesign.Bold}),
//									 new sap.m.ToolbarSpacer(),
//									 //new sap.m.Button({icon: "sap-icon://edit", press: oController.onEditAcc}),
//									 new sap.m.Button({icon: "sap-icon://add", press: [oController.onAddAcc, oController]}),
//									 new sap.m.Button({icon: "sap-icon://delete", press: oController.onDeleteAcc}),
//								 ]
//						}),
//			        	expandable: true,
//			        	expanded: false,
//			        	width: "auto",
//			        	content: [sap.ui.view({id:"accListView", viewName:"resources.js.enhancements.lists.AdminListasDetail", type:sap.ui.core.mvc.ViewType.JS})]
//			        }),
//			]
//		});
// 		
// 		this.vBox = vBox;
// 		
// 		return this.vBox;
//	},
//	
//	_getCurrentUser: function() {
//		return window.oShell.getUser();
//	},
//	
//	_getInTeam: function(auditKey) {
//		// Find current user in Team
//		var inTeam = false;
//		var currUser = this._getCurrentUser();
//		var oModel = sap.hpa.grcaud.oODataModelPool.get();
//		oModel.read("/AuditSet(guid'"+ auditKey + "')/UserRoles", {	
//																	async: false, 
//																	success: success, 
//																	error: error 
//																  }
//		);
//		
//		function success(oData,oDataRes)
//		{
//			var users = $.grep(oData.results,function(n){ return (n.UserID == currUser); });
//			inTeam = users.length > 0 ? true : false;
//		}
//		
//		function error(error) {
//			console.log("Error retrieving Team members");
//			inTeam = false;
//		}
//		
//		return inTeam;
//	},
//	
//	_getDistList: function(auditKey) {
//		// Fetching Distribution List
//		var urlDist = "/InfoAuditListSet?$filter=Key eq binary'" + oController.auditKey.replaceAll('-','') + "'&$expand=InfoUsersHierList,InfoUsersList,InfoUserDelegatedList";
//		sap.ui.getCore().getModel("con").read(urlDist,{async: false, success: successDist, error: errorDist });
//	},
//	
//	_getAccList: function(auditKey) {
//		// Fetching Access List
//		var urlAcc = "/InfoAuditAccListSet?$filter=Key eq binary'" + oController.auditKey.replaceAll('-','') + "'&$expand=InfoUsersHierList,InfoUsersList,InfoUserDelegatedList";
//	    sap.ui.getCore().getModel("con").read(urlAcc,{async: false, success: successAcc, error: errorAcc });
//	},
//	
//	_getFinalStatus: function() {
//		return ["08","09","18"];
//	},
//	
//	_getInFinalStatus: function(currStatus) {		
//		// Looking for curStatus in finalStatus array
//		var array = $.grep(finalStatus, function(n){ return (n == currStatus)});
//		
//		return array.length > 0 ? true : false;
//	}
	}
});

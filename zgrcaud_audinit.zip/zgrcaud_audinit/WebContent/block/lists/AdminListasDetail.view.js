sap.ui.jsview("sap.grc.acs.aud.audit.initiate.extended.block.lists.AdminListasDetail", {

	/** Specifies the Controller belonging to this View. 
	* In the case that it is not implemented, or that "null" is returned, this View does not have a Controller.
	* @memberOf zportalaudit.view.AdminListasDetail
	*/ 
	getControllerName : function() {
		return "sap.grc.acs.aud.audit.initiate.extended.block.lists.AdminListasDetail";
	},

	/** Is initially called once after the Controller has been instantiated. It is the place where the UI is constructed. 
	* Since the Controller is given to this method, its event handlers can be attached right away. 
	* @memberOf zportalaudit.view.AdminListasDetail
	*/ 
	createContent : function(oController) {
		
		//var header = sap.ui.view({id:"listasHeader", viewName:"appAdminListas.view.ListasHeader", type:sap.ui.core.mvc.ViewType.JS});
		var centros = sap.ui.view({id:this.createId("centrosView"), viewName:"sap.grc.acs.aud.audit.initiate.extended.block.lists.Centros", type:sap.ui.core.mvc.ViewType.JS});
		var personas = sap.ui.view({id:this.createId("personasView"), viewName:"sap.grc.acs.aud.audit.initiate.extended.block.lists.Personas", type:sap.ui.core.mvc.ViewType.JS});
		var delegados = sap.ui.view({id:this.createId("delegadosView"), viewName:"sap.grc.acs.aud.audit.initiate.extended.block.lists.Delegados", type:sap.ui.core.mvc.ViewType.JS});	
		
 		var vBox = new sap.m.VBox({
			height: "100%",
			items: [
			        centros, personas, delegados
				/*new sap.m.Panel({
					content: [centros]
				}),
				new sap.m.Panel({
					content: [personas]
				})*/
			]
		});
  
 		this.centros = centros;
 		this.personas = personas;
 		this.delegados = delegados;
 		
 		//Per passar parametres d'una pàgina a una altra
		this.addEventDelegate({
			onBeforeShow: function(oEvent) {			
				// Se preparan los datos para los centros
				/*var dataCentros = oEvent.data.oModel.getData().centros;
				
				var modelCentros = new sap.ui.model.json.JSONModel(); 
				modelCentros.setData(dataCentros);
				this.centros.setModel(modelCentros);
				this.centros.table.bindRows("/");
				byId("distList").setVisibleRowCount(10);
				
				// Se preparan los datos para las personas
				var dataPersonas = oEvent.data.oModel.getData().personas;
				
				var modelPersonas = new sap.ui.model.json.JSONModel(); 
				modelPersonas.setData(dataPersonas);
				this.personas.setModel(modelPersonas);
				this.personas.listContainer.bindAggregation("items","/",this.personas.template);*/
				
			}
		}, this); 
		
 		return new sap.m.Page({
			showHeader: false,
			showNavButton: false,
			title: "acc_list",
			//fitContainer: true,
			
			content: [
			          vBox, new sap.m.Bar({contentRight: [new sap.m.Button({text: "{'i18nm>save')", press: [oController.doSave, oController]})]})			          
			],
			//navButtonPress: oController.doBackToList,
			//footer: new sap.m.Bar({contentRight: [new sap.m.Button({text: "Guardar", press: oController.doSave})]})
		}).getContent();

	}

});

jQuery.sap.declare("sap.grc.acs.aud.audit.initiate.extended.block.lists.listComponent.Component");
jQuery.sap.require("sap.ui.core.UIComponent");

sap.ui.core.UIComponent.extend("sap.grc.acs.aud.audit.initiate.extended.block.lists.listComponent.Component", {
	     /*metadata: {
	         properties: {
	              itemsPerLine: {
	            		type: 'int',
	            		defaultValue: 7
	              },
	              addWhiteSpaces: {
	          		type: 'boolean',
	          		defaultValue: false
	              }
	         },
	         events: {
	            addNewItem: {
	            	parameters: {
	            		item: {
	            			type: 'string'
	            		}
	            	}
	            }
	         },
	   },*/
//	init: function() {
//	    // define variable for control initial loading handling
//	    this._bInitialLoading = true;
//		   // execute standard control method
//	    sap.ui.core.UIComponent.prototype.init.apply(this,arguments);
//	},
//		

	onAfterRendering: function(){
		
	},

	/** Is initially called once after the Controller has been instantiated. It is the place where the UI is constructed. 
	* Since the Controller is given to this method, its event handlers can be attached right away. 
	* @memberOf grcaud.lists.lists
	*/ 
	createContent : function() {
		var oController = sap.ui.controller("sap.grc.acs.aud.audit.initiate.extended.block.lists.ListView");
		var o18nmModel = new sap.ui.model.resource.ResourceModel({ bundleUrl:"sap/grc/acs/aud/audit/initiate/extended/i18n/i18n.properties" }).getResourceBundle();
 		var vBox = new sap.m.VBox({
			height: "100%",
			items: [
			        new sap.m.Panel({
			        	headerText: o18nmModel.getText('dist_list'),
			        	headerToolbar: new sap.m.Toolbar({
							content:
								[
							         new sap.m.Label({text:o18nmModel.getText('dist_list'), design: sap.m.LabelDesign.Bold}),
									 new sap.m.ToolbarSpacer(),
									 //new sap.m.Button({icon: "sap-icon://edit", press: oController.onEditDist}),
									 new sap.m.Button({icon: "sap-icon://add", press: [oController.onAddDist, oController]}),
									 new sap.m.Button({icon: "sap-icon://delete", press: oController.onDeleteDist}),
								 ]
						}),
			        	expandable: true,
			        	expanded: true,
			        	width: "auto",
			        	content: [sap.ui.view({id:"distListView", viewName:"sap.grc.acs.aud.audit.initiate.extended.block.lists.AdminListasDetail", type:sap.ui.core.mvc.ViewType.JS})]
			        }),
			        new sap.m.Panel({
			        	headerText: o18nmModel.getText("acc_list"),
			        	headerToolbar: new sap.m.Toolbar({
							content:
								[
							         new sap.m.Label({text:o18nmModel.getText("acc_list"), design: sap.m.LabelDesign.Bold}),
									 new sap.m.ToolbarSpacer(),
									 //new sap.m.Button({icon: "sap-icon://edit", press: oController.onEditAcc}),
									 new sap.m.Button({icon: "sap-icon://add", press: [oController.onAddAcc, oController]}),
									 new sap.m.Button({icon: "sap-icon://delete", press: oController.onDeleteAcc}),
								 ]
						}),
			        	expandable: true,
			        	expanded: false,
			        	width: "auto",
			        	content: [sap.ui.view({id:"accListView", viewName:"sap.grc.acs.aud.audit.initiate.extended.block.Lists.lists.AdminListasDetail", type:sap.ui.core.mvc.ViewType.JS})]
			        }),
			]
		}); //fin VBox
 		
 		this.vBox = vBox;
 		
 		return this.vBox;
	}, // fin de funcion createContent
	
	_getCurrentUser: function() {
		return window.oShell.getUser();
	},
	
	_getInTeam: function(auditKey) {
		
		if(auditKey){
			// Find current user in Team
			var inTeam = false;
			var currUser = this._getCurrentUser();
			var oModel = sap.hpa.grcaud.oODataModelPool.get();
			oModel.read("/AuditSet(guid'"+ auditKey + "')/UserRoles", { async: false, success: success, error: error });
			
			function success(oData,oDataRes)
			{
				var users = $.grep(oData.results,function(n){ return (n.UserID == currUser); });
				inTeam = users.length > 0 ? true : false;
			}
			
			function error(error) {
				console.log("Error retrieving Team members");
				inTeam = false;
			}
			
			return inTeam;
		} else return false;
	},
	
	_getDistList: function(oController) {
		var component = this;
		var auditKey = oController.auditKey;
		var currStatus = oController.statusKey;
		
		if(auditKey){
			// Fetching Distribution List
			var urlDist = "/InfoAuditListSet?$filter=Key eq binary'" + auditKey.replaceAll('-','') + "'&$expand=InfoUsersHierList,InfoUsersList,InfoUserDelegatedList";
			sap.ui.getCore().getModel("con").read(urlDist,{async: false, success: success, error: error });
			
		    function success(oData, oDataRes) {

		    	//var view = sap.ui.getCore().byId('listView');
		    	var view = component.vBox;
		    	var distView = sap.ui.getCore().byId('distListView');
		    	var accView = sap.ui.getCore().byId('accListView');
		    	
		    	/**
		    	 * Emtpy table/list
		    	 */ 
		    	
		    	var table = distView.centros.table
		    	if(table) {
		    		table.unbindRows();
		    		table.setVisibleRowCount(1);
		    	}
		    	var list = distView.personas.listContainer;
		    	var template = distView.personas.template;
		   		if(list) {
		   			list.unbindAggregation("items");
		   		}
		    	var list2 = distView.delegados.listContainer;
		    	var template2 = distView.delegados.template;
		   		if(list2) {
		   			list2.unbindAggregation("items");
		   		}
		   		/**
		   		 * Getting buttons
		   		 */
		   		
		   		// Getting Distribution List Panel
		   		var distPanel = view.getItems()[0];
				
				// Getting Access List Panel
				var accPanel = view.getItems()[1];
				
				// Getting Distribution List > Centers section
				var centros = distView.centros;
				var addCenterBtn = centros.table.getToolbar().getContent()[4];
				
				// Getting Distribution List > People section
				var personas = distView.personas;
				var addPeopleBtn = personas.listContainer.getHeaderToolbar().getContent()[2];
				
				// Getting Distribution List > Delegate section
				var delegados = distView.delegados;
				var addDelegatesBtn = delegados.listContainer.getHeaderToolbar().getContent()[2];
				
				// If any data fetched
		    	if(oData.results.length != 0) {
		    		// Center data
		    		var centerModel = new sap.ui.model.json.JSONModel();
		    		centerModel.setData(oData.results[0].InfoUsersHierList);
					table.setModel(transformJerarquiaToObjects(transformJerarquia(centerModel)));
					table.bindRows("/centros");
					
					if(oData.results[0].InfoUsersHierList.results.length > 0) {
						table.setVisibleRowCount(10);
					} else {
						table.setVisibleRowCount(1);
					}
		    		
			   		// People data
			   		var peopleData = new sap.ui.model.json.JSONModel();
			   		peopleData.setData(oData.results[0].InfoUsersList);
			   		list.setModel(peopleData);
			   		list.bindAggregation("items", "/results", template);
			   		
			   		// Delegates data
			   		var delegateData = new sap.ui.model.json.JSONModel();
			   		delegateData.setData(oData.results[0].InfoUserDelegatedList); 
			   		list2.setModel(delegateData);
			   		list2.bindAggregation("items", "/results", template2);
		    	} 
		    	
		    	
		    	/**
		    	 * Preparing buttons by Status
		    	 */
		    	
		    	// Inicio MOD RTC539288 - error part de centres, es desplega malament		
				table.getToolbar().getContent()[3].setIcon("sap-icon://expand")
				// Fin MOD RTC539288 - error part de centres, es desplega malament	
		    	
				// If status is inside finalStatus array, then no editable buttons shall appear
				if(component._getInFinalStatus(currStatus)) {
					// Collapse Distribution List section and disable toolbar
					distPanel.setExpanded(false);
					disableToolbar(distPanel.getHeaderToolbar().getContent());
					addCenterBtn.setEnabled(false);
					addPeopleBtn.setEnabled(false);
					addDelegatesBtn.setEnabled(false);
					// Hide delete row
					table.getColumns()[table.getColumns().length-1].setVisible(false);
					
					component._hideAddSubsBtn(distView);
					// Hide Save footer
					distView.getContent()[1].setVisible(false);
					
					// Hide delete row
					//list.getColumns()[list.getColumns().length-1].setVisible(false);
					list.setMode("None");
					// Loading Access List
//					if(list.getModel().getData().results.length !== 0 || table.getModel().getData().centros.length !== 0){
						component._getAccList(auditKey);
//					}
				} else {
					// Expand Distribution List section and disable toolbar
					distPanel.setExpanded(true);
					enableToolbar(distPanel.getHeaderToolbar().getContent());
					if(oData.results.length == 0) {
			    		addCenterBtn.setEnabled(false);
			    		addPeopleBtn.setEnabled(false);
			    		addDelegatesBtn.setEnabled(false);
			    	} else {
			    		addCenterBtn.setEnabled(true);
			    		addPeopleBtn.setEnabled(true);
			    		addDelegatesBtn.setEnabled(true);
			    	}
					
					// Show delete row
					table.getColumns()[table.getColumns().length-1].setVisible(true);
					// If current audit is not in final state, there's no need to show Access List
					accPanel.setVisible(false);
				}
		    	
				
				if(!component._getInTeam(auditKey)){
					disableToolbar(distPanel.getHeaderToolbar().getContent());
					disableToolbar(accPanel.getHeaderToolbar().getContent());
				}
		    
		    }// fin function oController
		    
		    function error(error) {
		    	alert("Error recuperando lista de distribución");
		    }
		}  
	},
	
	_getAccList: function(auditKey) {
		
		if(auditKey){
			// Fetching Access List
			//var urlAcc = "/InfoAuditAccListSet?$filter=Key eq binary'" + auditKey.replaceAll('-','') + "'&$expand=InfoUsersHierList,InfoUsersList,InfoUserDelegatedList";
			var urlAcc = "/InfoAuditAccListSet?$filter=Key eq binary'" + this.grcaudController.auditKey.replaceAll('-','') + "'&$expand=InfoUsersHierList,InfoUsersList,InfoUserDelegatedList";
			sap.ui.getCore().getModel("con").read(urlAcc,{async: false, success: successAcc, error: errorAcc });
		    
		    function successAcc(oData, oDataRes) {
		    	if(oData.results.length != 0) {
		    		var accView = sap.ui.getCore().byId('accListView');
			    	var table = accView.centros.table;
			    	// Inicio MOD RTC539288 - error part de centres, es desplega malament		
					table.getToolbar().getContent()[3].setIcon("sap-icon://expand")
					// Fin MOD RTC539288 - error part de centres, es desplega malament	
			    	var list = accView.personas.listContainer;
			    	var template = accView.personas.template;
			    	var list2 = accView.delegados.listContainer;
			    	var template2 = accView.delegados.template;
			    	
			    	// Expand Distribution List section and disable toolbar
					//accPanel.setExpanded(true);
			    	accView.getParent().setExpanded(true);
			    	
		    		// Center data
		    		var oModel = new sap.ui.model.json.JSONModel();
					oModel.setData(oData.results[0].InfoUsersHierList);
					
					table.setModel(transformJerarquiaToObjects(transformJerarquia(oModel)));
					table.bindRows("/centros");
					if(oData.results[0].InfoUsersHierList.results.length > 0) {
						table.setVisibleRowCount(10);
					} else {
						table.setVisibleRowCount(1);
					}
		    		
			   		// People data
			   		var peopleData = new sap.ui.model.json.JSONModel();
			   		peopleData.setData(oData.results[0].InfoUsersList);
			   		list.setModel(peopleData);
			   		list.bindAggregation("items", "/results", template);
			   		
			   		// Delegate data
			   		var delegatesData = new sap.ui.model.json.JSONModel();
			   		delegatesData.setData(oData.results[0].InfoUserDelegatedList);
			   		list2.setModel(delegatesData);
			   		list2.bindAggregation("items", "/results", template2);
			   		
			   		disableToolbar(accView.getParent().getHeaderToolbar().getContent());
		    	} else {
		    		if(this.done) { // If we have already save a Acc list, but we still have no data -> DO NOTHING
		    			var accView = sap.ui.getCore().byId('accListView');
				    	var table = accView.centros.table;
				    	var list = accView.personas.listContainer;
				    	var list2 = accView.delegados.listContainer;
				    	
		    			// Add empty model to center table
						table.setModel(new sap.ui.model.json.JSONModel());
						
						// Add empty model to people list
				   		list.setModel(new sap.ui.model.json.JSONModel());
				   		
						// Add empty model to delegates list
				   		list2.setModel(new sap.ui.model.json.JSONModel());
				   		
		    		} else {
		    			var distView = sap.ui.getCore().byId('distListView');
				    	var table = distView.centros.table;
				    	var list = distView.personas.listContainer;
				    	var template = distView.personas.template;
				    	var list2 = distView.delegados.listContainer;
				    	var template2 = distView.delegados.template;
				   		
				    	var listaCentros = [];
				    	if(table.getModel()) {
				    		if(table.getModel().getData().centros) {
			    				var oModelCentros = aplanarJerarquia(table.getModel().getData().centros);
			    				if(oModelCentros.getData().centros != undefined){
			    					if(oModelCentros.getData().centros.length > 0){
			    						$.each(oModelCentros.getData().centros,function(i,n){
			    							listaCentros.push({Company: n.Company, Department: n.Department, FirstNode: transformStringToBool(n.FirstNode),DelUserResp1: transformStringToBool(n.DelUserResp1), DelUserResp2: transformStringToBool(n.DelUserResp2)})
			    						});
			    					}
			    				}
			    			} else {
			    				listaCentros = [{}];
			    			}
				    	} else {
		    				listaCentros = [{}];
		    			}
		    				
			    		
		    			var oModelPersonas = list.getModel();
		    			var listaPersonas = [];
		    			if(oModelPersonas) {
		    				if(oModelPersonas.getData().results != undefined){
			    				if(oModelPersonas.getData().results.length > 0){
			    					$.each(oModelPersonas.getData().results,function(i,n){
			    						listaPersonas.push({UserId: n.UserId});
			    					});
			    				}
			    			}else{
			    				listaPersonas = [{}];
			    			}
		    			}else{
		    				listaPersonas = [{}];
		    			}
		    			
		    			var oModelDelegados = list.getModel();
		    			var listaDelegados = [];
		    			if(oModelDelegados) {
		    				if(oModelDelegados.getData().results != undefined){
			    				if(oModelDelegados.getData().results.length > 0){
			    					$.each(oModelDelegados.getData().results,function(i,n){
			    						listaDelegados.push({UserId: n.UserId});
			    					});
			    				}
			    			}else{
			    				listaDelegados = [{}];
			    			}
		    			}else{
		    				listaDelegados = [{}];
		    			}
		    			
		    			//debugger
		    			//Creamos la entidad lista que pasaremos por parametro
		    			var oLista = {};
		    			//oLista.Key = recoverKey(sap.ui.getCore().getModel("con").oData.currAudit);
		    			oLista.Key = recoverKey(auditKey);
		    			oLista.InfoUsersDeep = listaPersonas.length > 0 ? listaPersonas : [{}];
		    			oLista.InfoUserDelegatesDeep = listaDelegados.length > 0 ? listaDelegados : [{}];
		    			oLista.InfoDepatmentsDeep = listaCentros.length > 0 ? listaCentros : [{}];

		    			var url = "/InfoAuditAccListDeepSet";
					    sap.ui.getCore().getModel("con").refreshSecurityToken();
						sap.ui.getCore().getModel("con").create(url,oLista,{async: false, success: success, error: error });
						
						function success(oData, oDataRes) {
							var urlAcc = "/InfoAuditAccListSet?$filter=Key eq binary'" + auditKey.replaceAll('-','') + "'&$expand=InfoUsersHierList,InfoUsersList,InfoUserDelegatedList";
						    sap.ui.getCore().getModel("con").read(urlAcc,{async: false, success: successAcc.bind({done:"y"}), error: errorAcc });
						}
						
						function error(error) {
							alert("Error creando lista de acceso");
						}
		    		}
		    		
		    	}
		    }
		    
		    function errorAcc(error){
		    	alert("Error recuperando lista de acceso");
		    }
		}
	},
	
	_getFinalStatus: function() {
		// Closed : "08",Canceled : "09", DistributeAuditReport : "18"
		return ["08","09","18"];
	},
	
	_getInFinalStatus: function(currStatus) {		
		// Looking for curStatus in finalStatus array
		var finalStatus = this._getFinalStatus();
		var array = $.grep(finalStatus, function(n){ return (n == currStatus)});
		return array.length > 0 ? true : false;
	},
	
	_hideAddSubsBtn: function(distView) {
		// First Responsible
		distView.centros.hBox.getItems()[0].setVisible(false);
		distView.centros.hBox.getItems()[2].setVisible(false);
		
		// Second Responsible
		distView.centros.hBox2.getItems()[0].setVisible(false);
		distView.centros.hBox2.getItems()[2].setVisible(false);
		
		//Inicio SPAU 02.10.2018
		var hbox = distView.centros.hBox.getItems()[0].getParent().getParent();
		
		$.each(hbox._aTemplateClones, function(a,b){
			b.getItems()[0].setVisible(false);
			b.getItems()[2].setVisible(false);
		});
		//Fin SPAU 02.10.2018
	},
	
	initialize: function(oController) {
		// Saving currAudit Key
		sap.ui.getCore().getModel("con").oData.currAudit = oController.auditKey;
		
		this.grcaudController = oController;
		
		// Fetching Distribution List
		this._getDistList(oController);
	}

});

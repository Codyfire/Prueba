String.prototype.replaceAll = function(search, replacement) {
    var target = this;
    return target.replace(new RegExp(search, 'g'), replacement);
};

String.prototype.contains = function(it) { return this.indexOf(it) != -1; };

function tieneNumeros(texto){
	var numeros="0123456789";
	
   for(i=0; i<texto.length; i++){
      if (numeros.indexOf(texto.charAt(i),0)!=-1){
         return true;
      }
   }
   return false;
}

function transformStringToBool(str){
	if(str == "true")return true;
	else return false;
}

function mirarCentrosRepetidos(selItems, viewName){
	var repetit = false;
	$.each(selItems,function(i,n){
		var bindingContext = n.getBindingContext().sPath;
		var Company = sap.ui.getCore().getModel('centrosSearch').getProperty(bindingContext).Company;
		var Department = sap.ui.getCore().getModel('centrosSearch').getProperty(bindingContext).Department;
		var table = sap.ui.getCore().byId(viewName).table;
		if(table.getModel().getData().centros != undefined)
			$.each(table.getModel().getData().centros,function(j,m){
				if(m.Company == Company && m.Department == Department)repetit = true;
			});
	});
	return repetit;
}

function mirarPersonsaRepetides(selItems, viewName){
	var repetit = false;
	$.each(selItems,function(i,n){
		var bindingContext = n.getBindingContext().sPath;
		var matricula = sap.ui.getCore().getModel("ldap").getProperty(bindingContext).UserId;
		var name = sap.ui.getCore().getModel("ldap").getProperty(bindingContext).FullName;
		var list = sap.ui.getCore().byId(viewName).listContainer;
		if(list.getModel().getData().results != undefined)
			$.each(list.getModel().getData().results,function(j,m){
				if(m.FullName == name && m.UserId == matricula)repetit = true;
			});
	});
	return repetit;
}

function mirarDelegadoRepetides(selItems, viewName){
	var repetit = false;
	$.each(selItems,function(i,n){
		var bindingContext = n.getBindingContext().sPath;
		var matricula = sap.ui.getCore().getModel("ldap").getProperty(bindingContext).UserId;
		var name = sap.ui.getCore().getModel("ldap").getProperty(bindingContext).FullName;
		var list = sap.ui.getCore().byId(viewName).listContainer;
		if(list.getModel().getData().results != undefined)
			$.each(list.getModel().getData().results,function(j,m){
				if(m.FullName == name && m.UserId == matricula)repetit = true;
			});
	});
	return repetit;
}
	
function reorganizarEstilosTabla(){
	
}

//importScripts('worker.js');  


function updateDelUserResp1(userId, status, viewName) {
	var table = sap.ui.getCore().byId(viewName).table;
	
	if(table!=undefined){			
			/*** Responsable 1 ***/
			// Para cada centro buscamos repetidos
			var items = [];
	
			$.each(table.getModel().getData().centros,function(i,n){
				buscaUserIdResp1Repes(n,userId,items);
			})	
			
			if(items.length > 1) { // Si existe más de uno, comprobamos el estado de todos
				var rep2 = $.grep(items, function(e){ return e.DelUserResp1 == status; });
				
				// Si alguno no tiene el mismo STATUS que pasamos, se actualiza
				if(items.length != rep2.length) {
					$.each(items,function(j,m){
						m.DelUserResp1 = status;
					});
				}
			} else { // Si solo existe uno, actualizamos su estado
				items[0].DelUserResp1 = status;
			}			
	}
	
	refrescarEstilsTaula(table);
}

function buscaUserIdResp1Repes(modelo, userId, items){
	var array = [modelo];
	var obj = {};
	
	var rep = $.grep(array, function(e){ 
		if(e.UserIdResp1 == userId) {
			items.push(e);
			return;
		} else {
			if(e[0]) {
				buscaUserIdResp1Repes(e[0], userId, items);
			}
		}
	});
}

function updateDelUserResp2(userId, status, viewName) {
	var table = sap.ui.getCore().byId(viewName).table;
	
	if(table!=undefined){			
		/*** Responsable 2 ***/
		// Para cada centro buscamos repetidos
		var items = [];

		$.each(table.getModel().getData().centros,function(i,n){
			buscaUserIdResp2Repes(n,userId,items);
		})	
		
		if(items.length > 1) { // Si existe más de uno, comprobamos el estado de todos
			var rep2 = $.grep(items, function(e){ return e.DelUserResp2 == status; });
			
			// Si alguno no tiene el mismo STATUS que pasamos, se actualiza
			if(items.length != rep2.length) {
				$.each(items,function(j,m){
					m.DelUserResp2 = status;
				});
			}
		} else { // Si solo existe uno, actualizamos su estado
			items[0].DelUserResp2 = status;
		}			
	}

	refrescarEstilsTaula(table);
}

function buscaUserIdResp2Repes(modelo, userId, items){
	var array = [modelo];
	var obj = {};
	
	var rep = $.grep(array, function(e){ 
		if(e.UserIdResp2 == userId) {
			items.push(e);
			return;
		} else {
			if(e[0]) {
				buscaUserIdResp2Repes(e[0], userId, items);
			}
		}
	});
}

//Listen for the event.
function refrescarEstilsTaula(table){ 
	 
	if(table!=undefined){
	   $.each(table.getAggregation("rows"),function(i,n){
		   /*** Responsable 1 ***/
		   var bindingContext = n.getAggregation("cells")[1].getBindingContext();
		   
		   if(bindingContext) {
			   //var line = sap.ui.getCore().getModel('centros').getProperty(bindingContext.sPath);
			   //var line = byId('centrosView').table.getModel().getProperty(bindingContext.sPath);
			   var line = table.getModel().getProperty(bindingContext.sPath);
			   
			   if(line) {
				   if(line.DelUserResp1 == "true"){
						n.getAggregation("cells")[1].getAggregation("items")[1].addStyleClass("lineThrough");
				   }else{
						n.getAggregation("cells")[1].getAggregation("items")[1].removeStyleClass("lineThrough");
				   }
			   }
			   
		   }
		   
		   /*** Responsable 2 ***/
		   bindingContext = n.getAggregation("cells")[2].getBindingContext();
		   
		   if(bindingContext) {
			   //var line = sap.ui.getCore().getModel('centros').getProperty(bindingContext.sPath);
			   //var line = byId('centrosView').table.getModel().getProperty(bindingContext.sPath);
			   var line = table.getModel().getProperty(bindingContext.sPath);
			   
			   if(line) {
				   if(line.DelUserResp2 == "true"){
						n.getAggregation("cells")[2].getAggregation("items")[1].addStyleClass("lineThrough");
				   }else{
						n.getAggregation("cells")[2].getAggregation("items")[1].removeStyleClass("lineThrough");
				   }
			   }
		   }
		   
	   });
	}
	table.setVisibleRowCount(10);
}


// Listen for the event.
/*function refrescarEstilsTaula(){

   if(byId("distList")!=undefined){
	   $.each(byId("distList").getAggregation("rows"),function(i,n){
		   /*** Responsable 1 **
			var UserId = n.getAggregation("cells")[1].getAggregation("items")[1].getAggregation("customData")[0].getProperty("key");
			var tatxat = false;
			$.each(sap.ui.getCore().getModel("centros").getData().centros,function(i,n){
				if(UserId == n.UserIdResp1){
					if(n.DelUserResp1 == "true"){
						tatxat = true;
					}else{
						tatxat = mirarTatxatsRecursiva1(n[0],UserId);
					}
				}
			});
			if(tatxat){
				n.getAggregation("cells")[1].getAggregation("items")[1].addStyleClass("lineThrough");
			}else{
				n.getAggregation("cells")[1].getAggregation("items")[1].removeStyleClass("lineThrough");
			}
			
			var UserId = n.getAggregation("cells")[2].getAggregation("items")[1].getAggregation("customData")[0].getProperty("key");
			var tatxat = false;
			$.each(sap.ui.getCore().getModel("centros").getData().centros,function(i,n){
				if(UserId == n.UserIdResp2){
					if(n.DelUserResp2 == "true"){
						tatxat = true;
					}else{
						tatxat = mirarTatxatsRecursiva2(n[0],UserId);
					}
				}
			});
			if(tatxat){
				n.getAggregation("cells")[2].getAggregation("items")[1].addStyleClass("lineThrough");
			}else{
				n.getAggregation("cells")[2].getAggregation("items")[1].removeStyleClass("lineThrough");
			}
		});
   }
	
}*/

function mirarTatxatsRecursiva1(node,UserId){
	tatxat = false;
	if(node != undefined){
		if(UserId == node.UserIdResp1){
			if(node.DelUserResp1 == "true"){
				tatxat = true;
			}
		}else{
			mirarTatxatsRecursiva1(node[0])
		}
	}
	return tatxat;
}

function mirarTatxatsRecursiva2(node,UserId){
	tatxat = false;
	if(node != undefined){
		if(UserId == node.UserIdResp2){
			if(node.DelUserResp1 == "true"){
				tatxat = true;
			}
		}else{
			mirarTatxatsRecursiva1(node[0])
		}
	}
	return tatxat;
}

function getModel(name) {
	return sap.ui.getCore().getModel(name);
}

function byId(name) {
	return sap.ui.getCore().byId(name);
}

function enableToolbar(items)
{
	$.each(items,function(i,n){ if(n.getMetadata()._sUIDToken == "button" || n.getMetadata()._sUIDToken == "spacer") n.setVisible(true);});
}

function disableToolbar(items)
{
	$.each(items,function(i,n){ if(n.getMetadata()._sUIDToken == "button" || n.getMetadata()._sUIDToken == "spacer") n.setVisible(false);});
}

//if (!String.prototype.startsWith) {
//  String.prototype.startsWith = function(stringBuscada, posicion) {
//    posicion = posicion || 0;
//    return this.indexOf(stringBuscada, posicion) === posicion;
//  };
//}

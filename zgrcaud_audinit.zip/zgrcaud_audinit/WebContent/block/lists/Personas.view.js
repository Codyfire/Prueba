sap.ui.jsview("sap.grc.acs.aud.audit.initiate.extended.block.lists.Personas", {

	/** Specifies the Controller belonging to this View. 
	* In the case that it is not implemented, or that "null" is returned, this View does not have a Controller.
	* @memberOf zportalaudit.view.Personas
	*/ 
	getControllerName : function() {
		return "sap.grc.acs.aud.audit.initiate.extended.block.lists.Personas";
	},

	/** Is initially called once after the Controller has been instantiated. It is the place where the UI is constructed. 
	* Since the Controller is given to this method, its event handlers can be attached right away. 
	* @memberOf zportalaudit.view.Personas
	*/ 
	
	createContent : function(oController) {
		//oController.loadData();
		var listContainer = new sap.m.Table(this.createId("personas"),{
			headerToolbar: new sap.m.Toolbar({
				content:
					[
				         new sap.m.Label({text:sap.hpa.grcaud.enh_oBundle.getText("dest_people"), design: sap.m.LabelDesign.Bold}),
						 new sap.m.ToolbarSpacer(),
						 new sap.m.Button({icon: "sap-icon://add", press: [oController.onAdd, oController]}),
						 //new sap.m.Button({icon: "sap-icon://delete", /*press: oController.onDelete*/}),
					 ]
			}),
			columns : [
						  new sap.m.Column({  
							    hAlign : "Left",  
							    header : new sap.m.Label({  
							              text : sap.hpa.grcaud.enh_oBundle.getText("tag"),
							              design: sap.m.LabelDesign.Bold
							    })  
						   }),new sap.m.Column({  
					                 hAlign : "Left",  
					                 header : new sap.m.Label({  
					                           text : sap.hpa.grcaud.enh_oBundle.getText("name"),
					                           design: sap.m.LabelDesign.Bold
					                 	})  
					       	 })  
				       ],
			width : "100%",
			height : "100%",
			mode: "Delete",
			delete: [function(oEvent){
				   	var bindingContext = oEvent.getParameter("listItem").getBindingContext().getPath();
					   var index = bindingContext.substr(9);
					   
					   var dialog = new sap.m.Dialog({
							title: sap.hpa.grcaud.enh_oBundle.getText("warning"),
							type: 'Message',
								content: new sap.m.Text({
									text: sap.hpa.grcaud.enh_oBundle.getText("deleting_person")
								}),
							state: sap.ui.core.ValueState.Warning,
							beginButton: new sap.m.Button({
								text: 'OK',
								press: [function () {

									//Elimino la persona del model local
									var list = this.getView().listContainer;
									var template = this.getView().template;
									var oModel = list.getModel();
									var aEntries = oModel.getData().results;
									
									aEntries.splice(index,1);
									oModel.setData({
										results : aEntries
									});
									
									list.setModel(oModel);
									list.bindAggregation("items","/results", template);
									dialog.close();
								}, oController]
							}),
							endButton: new sap.m.Button({
								text: sap.hpa.grcaud.enh_oBundle.getText("cancel"),
								press: function () {
									dialog.destroy();
								}
							}),
							afterClose: function() {
								dialog.destroy();
							}
						});
					   dialog.open();
				   },oController]
		}).addStyleClass("listaPersonas");
		
		 var itemTemplate = new sap.m.ColumnListItem({
              cells : [  
                       new sap.m.Label({  
                           text : "{UserId}",
                       }), 
                 		new sap.m.Label({  
                           text : "{FullName}",
                        })/*,
                        new sap.ui.core.Icon({
         				   //type:sap.m.ButtonType.Reject,
         				   src: "sap-icon://sys-cancel",
         				   press: [function(oEvent){
         					   var bindingContext = oEvent.getSource().getBindingContext().sPath
         					   var index = bindingContext.substr(9);
         					   
         					   var dialog = new sap.m.Dialog({
         							title: 'Advertencia',
         							type: 'Message',
         								content: new sap.m.Text({
         									text: '¿Esta seguro que desea eliminar la persona seleccionada?'
         								}),
         							state: sap.ui.core.ValueState.Warning,
         							beginButton: new sap.m.Button({
         								text: 'OK',
         								press: [function () {

         									//Elimino la persona del model local
         									var list = this.getView().listContainer;
         									var template = this.getView().template;
         									var oModel = list.getModel();
         									var aEntries = oModel.getData().results;
         									
         									aEntries.splice(index,1);
         									oModel.setData({
         										results : aEntries
         									});
         									
         									list.setModel(oModel);
         									list.bindAggregation("items","/results", template);
         									dialog.close();
         								}, oController]
         							}),
         							endButton: new sap.m.Button({
         								text: 'Cancelar',
         								press: function () {
         									dialog.destroy();
         								}
         							}),
         							afterClose: function() {
         								dialog.destroy();
         							}
         						});
         					   dialog.open();
         				   },oController]
         			   }).addStyleClass("sapMTokenIcon")*/
              ],
              customData: [new sap.ui.core.CustomData({
					key : "Id",
					value : "{id}"
			  })],
			  
			  
		});  
		
		this.listContainer = listContainer;
		this.template = itemTemplate;
		this.listContainer.template = itemTemplate;
			
		//listContainer.bindAggregation("items","/results", itemTemplate);
		return new sap.m.VBox({
			height: "100%",
			items: [this.listContainer]
		});
	}

});
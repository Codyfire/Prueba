/*
 * Copyright (C) 2009-2020 SAP SE or an SAP affiliate company. All rights reserved.
 */
sap.ui.define([ "sap/uxap/BlockBase" ], function(B) {
	"use strict";
	return B.extend("sap.grc.acs.aud.audit.initiate.extended.block.Lists", {
//		metadata : {
//			views : {
//				Collapsed : {
//					viewName : "sap.grc.acs.aud.audit.initiate.extended.block.lists.ListView",
//					type : "JS"
//				}, 
//				Expanded : {
//					viewName : "sap.grc.acs.aud.audit.initiate.extended.block.lists.ListView",
//					type : "JS"
//				}
//			}
//		},
		metadata : {
			views : {
				Collapsed : {
					viewName : "sap.grc.acs.aud.audit.initiate.extended.block.view.Lists",
					type : "XML"
				}, 
				Expanded : {
					viewName : "sap.grc.acs.aud.audit.initiate.extended.block.view.Lists",
					type : "XML"
				}
			}
		}
		
		
	});
});
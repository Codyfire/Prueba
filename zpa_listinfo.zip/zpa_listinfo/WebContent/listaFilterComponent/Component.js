jQuery.sap.declare("listaFilterComponent.Component");
jQuery.sap.require("sap.ui.core.UIComponent");

sap.ui.core.UIComponent.extend("listaFilterComponent.Component", {		
	metadata: {
        properties: {
           refObject: {
       		type: 'string',
       		defaultValue: ''
           }
        }
	},
	
	init : function () {
		// define variable for control initial loading handling
	    this._bInitialLoading = true;
		// execute standard control method
	    sap.ui.core.UIComponent.prototype.init.apply(this,arguments);
	},
	
	createContent: function(){
		var that = this;
		this.dialog = new sap.m.ViewSettingsDialog({
			cancel: function(oEvent){},
			resetFilters: function(oEvent) {
				
				var toDeleteFilters = this.getAggregation("filterItems");
				
				for(i = 0; i < toDeleteFilters.length; ++i) {
					if(this.getAggregation("filterItems")[i]._control) {
						toDeleteFilters[i]._control.getAggregation("formContainers")[0].getAggregation("formElements")[0].getAggregation("fields")[0].setValue("");
					}
				}
			}
		});
	},
		
   	setRefObject: function (refObject) {
   		
   		this.setProperty("refObject", refObject, true);
		var that = this;
		var oComponent = sap.ui.getCore().getComponent(this.getRefObject());
		
		var confirmFunction = function(oEvent){			
			
		     var oTable = sap.ui.getCore().getComponent(refObject).table;
		     var mParams = oEvent.getParameters();
		     var oBinding = oTable.getBinding("");
	 
		     listaInfoUtils.grouping = false;
		     listaInfoUtils.sorters = [];
		     listaInfoUtils.grouper = [];
		     listaInfoUtils.filters = [];
		     
		     // apply sorter
		     if(mParams.sortItem){
		    	 
		    	 var sPath = mParams.sortItem.getKey();
		    	 
			     var bDescending = mParams.sortDescending;
		    	 listaInfoUtils.sorters.push(new sap.ui.model.Sorter(sPath, bDescending));
		     }
			     
		     // apply grouping
		     if (mParams.groupItem) {
		    	 listaInfoUtils.sorters = [];
		         var sPath = mParams.groupItem.getKey();
	        	 var bDescending = mParams.groupDescending;
		         var vGroup = function(oContext) {
		             var name = oContext.getProperty(mParams.groupItem.mProperties.key);
		             return {
		                 key: name,
		                 text: name
		             };
		         };
		         var sPathSort = mParams.groupItem.getKey();
			     var bDescendingSort = mParams.groupDescending;
		         
			     listaInfoUtils.grouping = true;
		         listaInfoUtils.grouper.push(new sap.ui.model.Sorter(sPath, bDescending, vGroup));
		     	 // apply sorter
			     listaInfoUtils.sorters.push(new sap.ui.model.Sorter(sPathSort, bDescendingSort));
		     }
     
		     // apply filters
		     var aStatusFilters = [];
		     var statusFalg = false;
			 $.each(oEvent.getParameters().filterItems,function(j,value2){
				var field  = oEvent.getParameters().filterItems[j].oParent.mProperties.key;
				/**
				 * INI MOD RTC 746228 Rafael Gal�n Baquero
				 * 24.06.2019
				 * C�digo antiguo
//				  listaInfoUtils.filters.push(new sap.ui.model.Filter(field,sap.ui.model.FilterOperator.EQ, oEvent.getParameters().filterItems[j].mProperties.text));  
				 * C�digo nuevo
				 */
				// Se le proporciona la key del filtro
				listaInfoUtils.filters.push(new sap.ui.model.Filter(field,sap.ui.model.FilterOperator.EQ, oEvent.getParameters().filterItems[j].mProperties.key));
				
				/**
				 * FIN MOD RTC 746228 Rafael Gal�n Baquero
				 * 24.06.2019
				 */
				
				
			 });
			 
			 //Extra filter text
			 if(oEvent.getSource()._page2 != undefined)

				 if(oEvent.getSource()._page2.mAggregations.content != undefined)
					 if(oEvent.getSource()._page2.mAggregations.content["0"].mAggregations.formContainers != undefined)
						 if(oEvent.getSource()._page2.mAggregations.content["0"].mAggregations.formContainers["0"] != undefined)
							 if(oEvent.getSource()._page2.mAggregations.content["0"].mAggregations.formContainers["0"].mAggregations.formElements["0"].mAggregations.fields["0"].mProperties.value != ""){
								 var value = oEvent.getSource()._page2.mAggregations.content["0"].mAggregations.formContainers["0"].mAggregations.formElements["0"].mAggregations.fields["0"].mProperties.value;
								 var key = oEvent.getSource()._page2.mAggregations.content["0"].mAggregations.formContainers["0"].mAggregations.formElements["0"].mAggregations.label.mAggregations.customData["0"].mProperties.key;
								 listaInfoUtils.filters.push(new sap.ui.model.Filter(key,sap.ui.model.FilterOperator.Contains, value)); 
							}	
			 loadInformes(0, 7, listaInfoUtils.filters, listaInfoUtils.sorters, listaInfoUtils.grouping);
			 byId("informes").oTableComp.createPaginationMenu("planesAccion",7,"tablePlanAcciones", false);
		};
		this.dialog.attachConfirm(confirmFunction);
	},
		
	//Funcion que a�ade todos los items al componente de filtro, los agrupadores, los filtros y los ordenadores.
	addAllItems: function(sortItems, groupItems, filterItems, model,claus,table){
		var dialog = this.dialog;
		var that = this;
		this.sortItems = sortItems;
		this.claus = claus;
		
		/**
		 * INI MOD RTC 746228 Rafael Gal�n Baquero
		 * 25.06.2019
		 * C�digo antiguo
//				$.each(sortItems, function(i,value){
//			var selected = (i == 1);
//			dialog.addSortItem(
//				new sap.m.ViewSettingsItem({
//			    	text: value,
//			    	key: claus[i],
//			    	selected:selected
//			    })
//			);
//		});
//		
//		$.each(groupItems, function(i,value){
//			dialog.addGroupItem(
//				new sap.m.ViewSettingsItem({
//			    	text: value,
//			    	key: claus[i],
//			    	selected:false
//			    })
//			);
//		});
		 * C�digo nuevo
		 */
	
		$.each(sortItems, function(i,value){
			var selected = (i == 1);
			var key = claus[i];
			
			// En el caso de que sea clasificaci�n o departament, se agrupa por el nombre del departamento
		    	 if(key == "Rating")
		    	 key = "RatingText";
		    	 else if(key == "Department")
		    	 key = "DepartmentName";
			
			dialog.addSortItem(
				new sap.m.ViewSettingsItem({
			    	text: value,
			    	key: key,
			    	selected:selected
			    })
			);
		});
		
		$.each(groupItems, function(i,value){
			var key = claus[i];
			// En el caso de que sea clasificaci�n o departament, se agrupa por el nombre de la clasificaci�n
		    	 if(key == "Rating")
		    	 key = "RatingText";
		    	 else if(key == "Department")
		    	 key = "DepartmentName";
		    	 
			dialog.addGroupItem(
				new sap.m.ViewSettingsItem({
			    	text: value,
			    	key: key,
			    	selected:false
			    })
			);
		});
		
		
		/**
		 * FIN MOD RTC 746228 Rafael Gal�n Baquero
		 * 24.06.2019
		 */
		var oModel = sap.ui.getCore().getModel(model);
		
		$.each(filterItems, function(i,value){
			if(value != "") {
				if(i<claus.length){
					var items = [];
					var flac = false;
					
					/**
					 * INI MOD RTC 746228 Rafael Gal�n Baquero
					 * 24.06.2019			
					 * C�digo nuevo
					 */
					// Comprobamos si el filtro es Departmento o clasificaci�n					 
					if(claus[i]=="Department" || claus[i]== "Rating"){

						// Se montan los elementos para el departamento
						if(claus[i]=="Department")

						// Se a�aden los elementos desde el modelo
						$.each(getModel("DepAuditReport").getData().results,function(j,n){							
								items.push(
									new sap.m.ViewSettingsItem({										
										/**
										 * INI MOD PPM 069908 Rafael Galán Baquero 10/02/2021
										 * Código antiguo
										 * text: text: n.Text,
										 * Codigo nuevo
										*/
										text: n.AuditDepartment +' - '+ n.Text,
										/**
										* FIN MOD PPM069908 Rafael Galán Baquero 10/02/2021
										*/
										key: n.AuditDepartment
									})
								);							
						});
						
						// Se montan los elementos para la clasificaci�n						
						else
							// Se a�aden los elementos desde el modelo							
							$.each(getModel("RankingsAuditReport").getData().results,function(j,n){							
								items.push(
									new sap.m.ViewSettingsItem({
										text: n.Value,
										key: n.Name
									})
								);							
						});
							
							
						// Se a�aden los items al filtro
						dialog.addFilterItem(
							new sap.m.ViewSettingsFilterItem({
								setModel: oModel,
								text:value,
								key: claus[i],
								items:[
								    items   
								],
								
							})
						);
					
						
					}else
						/**
						 * FIN MOD RTC 746228 Rafael Gal�n Baquero
						 * 24.06.2019
						 */
						
						dialog.addFilterItem(
								new sap.m.ViewSettingsCustomItem({
									text:value,
									customControl: new sap.ui.layout.form.Form({
										editable: false,
										width:"100%",
										height: "100%",
										layout: new sap.ui.layout.form.GridLayout({}),
										formContainers: [
											new sap.ui.layout.form.FormContainer({
												formElements: [
													new sap.ui.layout.form.FormElement({
														label: new sap.m.Label({
															text: value,
															layoutData: new sap.ui.layout.form.GridElementData({hCells: "4"}),
															customData: new sap.ui.core.CustomData({key:claus[i]})
														}).addStyleClass("lbAdUsr"),
														fields: [
														    new sap.m.Input({ value: "", placeholder: "Filtro",editable: true, required: false, layoutData: new sap.ui.layout.form.GridElementData({hCells: "auto"})}),	
														]
													})
												]
											})
										]
									})
								})
							);					
					
					
				}
			}
		});	
	},
	
	//Funci�n que nos abre el filtro
	openDialog: function(){this.dialog.open();}
});
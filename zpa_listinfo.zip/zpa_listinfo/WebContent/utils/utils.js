// Funciones a�adidas al tipo String en Javascript

String.prototype.contains = function(it) { return this.indexOf(it) != -1; };

String.prototype.trim = String.prototype.trim || function() {
    return this.replace(/^\s+|\s+$/,"");
}

//Funciones a�adidas al tipo Date en Javascript

Date.prototype.toClean=function(){
    if(this!==null){
            var vDay = ((this.getDate())<10)?'0'+(this.getDate()):(this.getDate()),
                    oMonths = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'],
                    vMonth = oMonths[this.getMonth()],
                    vYear = this.getFullYear().toString().right(2);
                    
            return vDay+' '+vMonth+' \''+vYear;
    } else {
            return '[Invalid Date]';
    }
}

function getModel(name) {
	return sap.ui.getCore().getModel(name);
}

function byId(name) {
	return sap.ui.getCore().byId(name);
}

var listaInfoUtils = {};

//get i18n
listaInfoUtils.oBundle = new sap.ui.model.resource.ResourceModel ({
    bundleName: "appListaInformes.i18n.i18n"
 }).getResourceBundle();

//Variables de filtros, agrupadors y ordenadores.
listaInfoUtils.filters = [];
listaInfoUtils.sorters = [];
listaInfoUtils.grouper = [];
listaInfoUtils.grouping = false;

// Mostrar mensaje de aplicaci�n
listaInfoUtils.showMsg = function(text) {
	 sap.m.MessageToast.show(text, {duration: 800});
}

//Convertir fecha "1987-09-23T00:00:00" a "23/09/1987"
listaInfoUtils.convertDate = function(date){
	if(date != "") {
		var dat = new Date(date);
		var day = dat.getDate() < 10 ? '0' + dat.getDate() : '' + dat.getDate();
		var month = dat.getMonth()+1;
		month = month < 10 ? '0' + month : '' + month;
		return day + "/" + month + "/" + dat.getFullYear();
	} else { return ""; }
}

listaInfoUtils.getServerURL = function(){
	return location.protocol + "//" + location.hostname + ":" + location.port;
}

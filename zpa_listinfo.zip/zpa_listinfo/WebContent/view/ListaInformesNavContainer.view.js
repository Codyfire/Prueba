sap.ui.jsview("appListaInformes.view.ListaInformesNavContainer", {

	/** Specifies the Controller belonging to this View. 
	* In the case that it is not implemented, or that "null" is returned, this View does not have a Controller.
	* @memberOf zportalaudit.controller.informes.ListadoInformesNavCont
	*/ 
	getControllerName : function() {
		return "appListaInformes.controller.ListaInformesNavContainer";
	},

	/** Is initially called once after the Controller has been instantiated. It is the place where the UI is constructed. 
	* Since the Controller is given to this method, its event handlers can be attached right away. 
	* @memberOf zportalaudit.controller.informes.ListadoInformesNavCont
	*/ 
	createContent : function(oController) {
		var navContainer = new sap.m.NavContainer("listaInformesCont", {
			pages: [
			   	sap.ui.view({id:"informes", viewName:"appListaInformes.view.ListaInformes", type:sap.ui.core.mvc.ViewType.JS}),
			    //sap.ui.view({id:"adminListasDetail", viewName:"zportalaudit.view.adminListas.AdminListasDetail", type:sap.ui.core.mvc.ViewType.JS})
			]
		});
		
		
 		return new sap.m.Page({
			showHeader: false,
			//fitContainer: true,
			content: [navContainer]
		});
	}

});
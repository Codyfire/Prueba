sap.ui.jsview("appListaInformes.view.ListaInformes", {

	/** Specifies the Controller belonging to this View. 
	* In the case that it is not implemented, or that "null" is returned, this View does not have a Controller.
	* @memberOf zportalaudit.view.AdminListasNavContainer
	*/ 
	getControllerName : function() {
		return "appListaInformes.controller.ListaInformes";
	},

	/** Is initially called once after the Controller has been instantiated. It is the place where the UI is constructed. 
	* Since the Controller is given to this method, its event handlers can be attached right away. 
	* @memberOf zportalaudit.view.AdminListasNavContainer
	*/ 
	createContent : function(oController) {
		//Carrego els informes de bade de dades
		loadInformes(0, 7, listaInfoUtils.filters, listaInfoUtils.sorters, listaInfoUtils.grouping);
		//loadCount();
		
		//Cream la plantilla
		this.template = new sap.m.ColumnListItem({    
			type:"Active",
            cells : [ 
			   new sap.m.Text({  
				  text : "{ReportId}"  
			   }),
               new sap.m.Text({
            	   text: "{ReportTitle}"
               }),  
               new sap.m.Text({  
//                  text: "{SubmittedDateTime}"
               }).bindProperty("text",{
            	   parts:["DateRepIssued"],
            	   formatter: function(created){
            		   if(created != "")
            			   return listaInfoUtils.convertDate(created)
            		   else return "";
            	   }
               }),
               
                /**
				 * INI MOD PPM 069808 Rafael Galán Baquero 10/02/2021
				 * Código antiguo
				 * new sap.m.Text({  
                   text: "{DepartmentName}"
                }),
				 * Código nuevo
				 */
	 			// Se concatena el codigo de dept. auditoría al departamento de auditoría
	 			new sap.m.Text({}).bindProperty("text",{
	 				   parts: [ "DepartmentName", "Department"], 
	 				   formatter: function(deptName,dept){

	 					   return dept + ' - ' + deptName;
	 				   }
		 			 }),  
	 			/**
				 * FIN MOD PPM069808 Rafael Galán Baquero 10/02/2021
				 */
               new sap.m.Text({  
                    text: "{RatingText}"
               })
            ],
//        }).bindProperty("href",{
//     	   parts:["RepKey"],
//     	   formatter: function(key){
//     		   var convertedKey = convertKey(key);
//     		   return window.location.protocol + "//" + window.location.hostname + ":" + window.location.port +"/sap/opu/odata/sap/GRCAUD_SRV/DocWorkPaperSet(guid'" + convertedKey.substring(0,8) + "-" + convertedKey.substring(8,12) + "-" + convertedKey.substring(12,16) + "-" + convertedKey.substring(16,20) + "-" + convertedKey.substring(20) + "')/File/$value"; 
//     	   }
            press: function(oEvent) {
            	return oController.downloadReport(oEvent);
            }
        });
		
		
		//Creo la taula de paginaci� a partir del component creat
		this.oTableComp = new sap.ui.getCore().createComponent({
			//INI AJUSTES SPAU 15/11/18
			//name: "tablePagination",
			name: "tablePaginationlistInfo",
			//FIN AJUSTE SPAU 15/11/18
			id: "taulaInformes"
		});
		
		//Agrego les columnes a la taula
		this.oTableComp.addColumns([listaInfoUtils.oBundle.getText("numInforme"), listaInfoUtils.oBundle.getText("titInforme"), listaInfoUtils.oBundle.getText("fechaDistr"), listaInfoUtils.oBundle.getText("departamento"), listaInfoUtils.oBundle.getText("clasif")],0);
		
		//Bindejo les dades
		this.oTableComp.addItemTemplate("", "/results", this.template);
		
		var func = function(){
			//var numInformes = sap.ui.getCore().getModel("count").getData().numInformes;
			var numInformes = sap.ui.getCore().getModel("informes").getData().__count;
			return numInformes;
		}
		
		this.oTableComp.setCountFunction(func); 
		
		//Agrego el model de dades a la taula
		this.oTableComp.setDataModel("informes");
		
		this.oTableComp.createPaginationMenu("informes",7,"taulaInformes",listaInfoUtils.filters);
		this.oTableComp.refreshTableVisibility(0,7, listaInfoUtils.filters,null,null,true);
		
		//Creo el contenidor per la taula
		var oCompCont = new sap.ui.core.ComponentContainer({
			component:this.oTableComp
		});
		
		return new sap.m.Page({
			showNavButton:false,
			title: "{i18n>header}",
			subHeader:[
					new sap.m.Toolbar({
						content:[
						    //new sap.m.Text({text:"Lista de Informes"}).addStyleClass("boldLabel"),
						    new sap.m.ToolbarSpacer({}),
						    new sap.m.Button({
						    	icon: "sap-icon://download",
						    	press: function(){sap.ui.getCore().getComponent("taulaInformes").exportToExcel(listaInfoUtils.filters, listaInfoUtils.sorters);}       
						    }),
						    new sap.m.Button({
						    	icon: "sap-icon://drop-down-list",
					            press: oController.onFilterPress       
						    }),  
						    new sap.m.Button({
						    	icon:"sap-icon://person-placeholder",
						    	press: oController.onColunModifierPress
						    })
						]
					})
 			],
			content:[oCompCont]
		});
	}
});
//define a new UIComponent 
jQuery.sap.require("sap.ui.core.UIComponent");
jQuery.sap.require("sap.m.Table");
jQuery.sap.require("sap.m.VBox");
// INI AJUSTE SPAU 15/11/18
//jQuery.sap.declare("tablePagination.Component");
jQuery.sap.declare("tablePaginationlistInfo.Component");
// FIN AJUSTE SPAU 15/11/18

sap.ui.define([
	"sap/ui/core/UIComponent"
], function (UIComponent) {
	"use strict";
	// INI AJUSTE SPAU 15/11/18
	//return UIComponent.extend("tablePagination.Component", {
	return UIComponent.extend("tablePaginationlistInfo.Component", {
		//FIN AJUSTE SPAU 15/11/18

		init : function () {
			// call the init function of the parent
			UIComponent.prototype.init.apply(this, arguments);
		},
		
		createContent: function(){
			this.rowsForPage = 7;
			//Esto es para que funcione en IE i en Fiori
			var screenWidth = window.innerWidth || document.body.clientWidth;
			var width;
			/*if(screenWidth >= 1280){
				width = "1280px";
			}else{
				width = screenWidth + "px";
			}*/
			width = screenWidth + "px";
			
			//Creo la taula buida
			this.table = new sap.m.Table({				
				width:width, //Canviar per un 100% si es vol responsive, pero no funcionara amb IE
		    });
			
			var table = this.table;
			
			this.oFlex = new sap.m.FlexBox({
				//width:width,
				height:"100%",
				direction:"Column",
				displayInline: true,
				alignItems: sap.m.FlexAlignItems.Center,
				fitContainer:true,
				items:[
				       table
				]
			});
			
			return this.oFlex;
		},
		//En aquesta funci� li passo les columnes que vull que tingui la taula en un array 
		addColumns: function(columns,numVisible){
			var table = this.table;
			//Afegeixo les columnes a la taula
			$.each(columns, function(i,value){
				if(numVisible == 0 || numVisible == undefined || numVisible > i){
					var col = new sap.m.Column({
						hAlign:"Left",
						header: new sap.m.Text({
							text:value
						})
					});
					table.addColumn(col);
				}else{
					var col = new sap.m.Column({
						hAlign:"Left",
						visible: false,
						header: new sap.m.Text({
							text:value
						})
					});
					table.addColumn(col);
				}
			});
		},
		//func� per bindejar les dades a la taula
		addItemTemplate: function(a,b,c){
			this.table.bindAggregation(a,b,c);
			this.ruta = b;
			this.table.bindItems({path:b,template:c});
			
		},
		//funci� que fica el model de dades a la taula
		setDataModel: function(model){
			this.model = model;
			this.table.setModel(new sap.ui.model.json.JSONModel(sap.ui.getCore().getModel(model).getData() ));
		},
		//funci� que crea el men� de paginaci�
		createPaginationMenu: function(model, elementsForPage, id, aFilters){
			var numberOfRows = this.countFunc();
			var that = this;
			var numberOfPages = Math.ceil(numberOfRows / elementsForPage);
			//Un cop tinc el model ja puc saber el nombre de files que tindre, agafo el vBox i li assigno el paginador
			var oFlex = this.oFlex;
			if(oFlex.getItems()[1]){
				oFlex.getItems()[1].destroy();
			}
			if(numberOfPages > 1){
				oFlex.addItem(
				   new sap.ui.commons.Paginator({
			           numberOfPages: numberOfPages,
			    	   currentPage: 1,
			    	   page : function(oEvent) {
			    		   sap.ui.getCore().getComponent(that.sId).refreshTableVisibility(oEvent.getParameter("targetPage"), elementsForPage, listaInfoUtils.filters,listaInfoUtils.sorters, listaInfoUtils.grouping, false);
			    	   }
			       })
				);
			}     
		},
		
		refreshTableVisibility: function(pageNumber, elementsForPage, aFilters, aSorters, grouping, firstLoad){
			var currentPage = 1
			if(sap.ui.getCore().getComponent(this.sId).oFlex.getItems()[1] != undefined){
				currentPage = sap.ui.getCore().getComponent(this.sId).oFlex.getItems()[1].getCurrentPage();
			}
			var top = sap.ui.getCore().getComponent(this.sId).rowsForPage
			var skip = (currentPage-1) * top;
			if(!firstLoad)
				loadInformes(skip, top, aFilters, aSorters, grouping);
		},
		
		refreshTablePaginationForFilteredItems: function(pageNumber, elementsForPage){
			var initialElement = elementsForPage * (pageNumber - 1); //El primer element que ha de ser visible
			var finalElement = pageNumber * elementsForPage; //L'ultim element que ha de ser visible
			var table = this.table;
			
			//Si el nombre d'elements que retorna el filtre es major al nombre d'elements per p�gina, em de crear un nou paginador
			var numberOfElements = table.getItems().length;
			if(numberOfElements > elementsForPage){
				//Obting el numero total de files
				var numberOfRows = this.table.getVisibleItems().length;
				var numberOfPages = Math.ceil(numberOfRows / elementsForPage);
				
				//refresco els items visibles de la taula
				$.each(table.getVisibleItems(),function(i, value){
					if(i >= initialElement && i < finalElement)
						value.setVisible(true);
					else
						value.setVisible(false);
				});
			}else{
				//ense�o tots els items
				$.each(table.getItems(),function(i, value){
					value.setVisible(true);
				});
			}
			//Comprovem si el vBox te un paginador i si el te l'elimino
			this.createPaginationMenu(this.model,7);
		},
		
		setCustomToolbar: function(toolbar){
			this.table.setHeaderToolbar(toolbar);
		},
		
		setMode: function(mode){
			this.table.setMode(mode);
		},
		
		setCountFunction: function(funct){this.countFunc = funct;},
		
		getVisibleColumns: function() {
			var items = [];
			var table = this.table;
			$.each(table.getColumns(),function(i,n){ if(n.getVisible() == true){items.push(n);} });
			return items;
		},
		
		getVisibleColumnsIndexs: function() {
			var items = [];
			var table = this.table;
			$.each(table.getColumns(),function(i,n){ if(n.getVisible() == true){items.push(n._index);} });
			return items;
		},
		
		exportToExcel: function(filters, sorters){
			createExportJob(filters, sorters);
		},
		
	});
			
});
sap.ui.jsfragment ("fragment.Conclusion",{ 
	createContent: function (oController ) {
		var oForm =  new sap.ui.layout.form.Form({
			height: "100%",
			layout: new sap.ui.layout.form.GridLayout({}),
			formContainers: [
				new sap.ui.layout.form.FormContainer({
					title: "",
					formElements: [
						new sap.ui.layout.form.FormElement({
							label: new sap.m.Label({text: "C�digo de conclusi�n",layoutData: new sap.ui.layout.form.GridElementData({hCells: "3"})	}).addStyleClass("lbAdUsr"),
							fields: [
								new sap.m.Input("nameInput",{ value: "{/FullName}", placeholder: "Nombre", editable: false, required: true, layoutData: new sap.ui.layout.form.GridElementData({hCells: "auto"})}),
									new sap.m.Button({
										icon: "sap-icon://search",
										press: sap.ui.getCore().byId("gestionAlertas").getController().onButtonSearchConclusion,
										layoutData: new sap.ui.layout.form.GridElementData({hCells: "2"})							         		
								}).addStyleClass("formBtAdd")    	
							]
						}),
						new sap.ui.layout.form.FormElement({
							label: new sap.m.Label({text: "C�digo de incidencia",layoutData: new sap.ui.layout.form.GridElementData({hCells: "3"})	}).addStyleClass("lbAdUsr"),
							fields: [
							    new sap.m.Select({
							    	enabled:false,
							    	items:[
							    	       new sap.ui.core.Item({text:"C�digo incidencia 1"}),
							    	       new sap.ui.core.Item({text:"C�digo incidencia 2"}),
							    	       new sap.ui.core.Item({text:"C�digo incidencia 3"}),
							    	       new sap.ui.core.Item({text:"C�digo incidencia 4"}),
							    	       new sap.ui.core.Item({text:"C�digo incidencia 5"})
							    	]
							    })    	
							]
						}),
						new sap.ui.layout.form.FormElement({
							label: new sap.m.Label({text: "Final",layoutData: new sap.ui.layout.form.GridElementData({hCells: "3"})	}).addStyleClass("lbAdUsr"),
							fields: [
							    new sap.m.Select({
							    	enabled:false,
							    	items:[
							    	       new sap.ui.core.Item({text:"Llamada"}),
							    	       new sap.ui.core.Item({text:"Mail"}),
							    	       new sap.ui.core.Item({text:"Informe"})
							    	]
							    })    	
							]
						}),
						new sap.ui.layout.form.FormElement({
							label: new sap.m.Label({text: "Importe",layoutData: new sap.ui.layout.form.GridElementData({hCells: "3"})	}).addStyleClass("lbAdUsr"),
							fields: [
							    	    new sap.m.Input({value: "", placeholder: "Importe",editable: false, type:sap.m.InputType.Number, required: true, layoutData: new sap.ui.layout.form.GridElementData({hCells: "auto"})})   	
							]
						}),
						new sap.ui.layout.form.FormElement({
							label: new sap.m.Label({text: "Conclusi�n",layoutData: new sap.ui.layout.form.GridElementData({hCells: "3"})	}).addStyleClass("lbAdUsr"),
							fields: [
							    	    new sap.m.TextArea({rows:4, editable:false})   	
							]
						})
					]
				})	
			]
		});
		
		return oForm; 
	} 
});
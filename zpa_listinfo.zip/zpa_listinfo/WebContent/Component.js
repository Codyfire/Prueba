jQuery.sap.declare ("sap.ui.model.resources.ResourceModel");
jQuery.sap.declare("appListaInformes.Component");

sap.ui.core.UIComponent.extend("appListaInformes.Component",{
	metadata:{
		includes: [
			   "utils/utils.js",
			   "utils/conUtils.js",
			   "css/style.css",
			   "utils/encodingUtils.js",
			   "model/oDataGenerator.js",
			   "listaFilterComponent/Component.js",
			   "tablePagination/Component.js",
			   "visualitzadorColumnesComponent/Component.js",
			   "Download/download.min.js",
			   "sap/ui/model/resource/ResourceModel"
		], dependencies : { // external dependencies
			libs: ["sap.ui.commons"]
		},
		config : {
			fullWidth : true
		}
	},
	
	destroy : function() {
        if(sap.ui.getCore().byId("listaInformesNavCont")) sap.ui.getCore().byId("listaInformesNavCont").destroy();
        sap.ui.core.UIComponent.prototype.destroy.apply(this, arguments);
	},
	
	createContent : function(){
		//Creo la conexi�n para comunicarnos con el oData
		var con = {};
	    con.Model = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZGRCAUD_PORTAL_SRV/", false);
	    sap.ui.getCore().setModel(con.Model,"con");
////Inicio RTC-536982 FJHP 07.05.2017
//	    var date = new Date();
//	    date.setMonth(date.getMonth()-18)
//	    listaInfoUtils.filters.push(new sap.ui.model.Filter("Category",sap.ui.model.FilterOperator.EQ, "INFIE"));
//	    listaInfoUtils.filters.push(new sap.ui.model.Filter("DateRepIssued",sap.ui.model.FilterOperator.GE, listaInfoUtils.convertDate(date)));
////Fin    RTC-536982 FJHP 07.05.2017
		var oView = sap.ui.view({
			id:"listaInformesNavCont", 
			height: "100%", 
			viewName:"appListaInformes.view.ListaInformesNavContainer", 
			type:sap.ui.core.mvc.ViewType.JS,
			viewData : { component : this }
		});
		
		// Se comprueba si ha sido llamado desde el email de distribución para descargar el informe
		var hash = window.location.hash;
		var url = window.location.hash.split("?")[1];
		
		if(url != undefined) {
			window.location.assign(atob(url));
		}
		
		return oView;
	},
});



//--------------------> Informes section <---------------------------------

function loadInformes(skip,top,aFilters,aSorters,grouping){
	//Ir a la TCODE: SICF
	//Buscar servicio -> Detalles
	//Datos logon -> a�adir user: U0184284, pass: Hola1234
	
	//Refresco el security token per a poder logar-nos a sap
	getModel('con').refreshSecurityToken();
	 
	//Faig el read de les alertas
	getModel('con').read("/InfoAuditReportSet?&$skip=" + skip + "&$top=" + top,{
		filters : aFilters,
		sorters: aSorters,
		async: false,
        success : function (oData) {
           console.log(oData);
	   		var oModel = new sap.ui.model.json.JSONModel();
	   		oModel.setData(oData);
	   		sap.ui.getCore().setModel(oModel,"informes");
	   		//sap.ui.getCore().getModel("users").iSizeLimit=200;
	   		//countUsers(aFilters,aSorters);
	   		if(byId("informes").oTableComp != undefined){
	   			byId("informes").oTableComp.addItemTemplate("", "/results", byId("informes").template);
	   			//byId("informes").oTableComp.setDataModel("informes");
	   			byId("informes").oTableComp.setDataModel('informes');
	   			if(grouping){
	   				var oTable = byId("informes").oTableComp.table;
	   				var oBinding = oTable.getBinding("");
				    oBinding.sort(listaInfoUtils.grouper);
	   			}
	   		}
	   		
        }.bind(this),
        error: function (oError) {
           console.log(oError);
        }.bind(this)
	});
}

function loadCount() {	 
	//Faig el read de les alertas
	getModel('con').read("/InfoAuditReportSet/$count",{
		async: false,
        success : function (oData, oDataResp) {
           console.log(oData);
	   		var oModel = new sap.ui.model.json.JSONModel();
	   		var oEntity = {};
        	oEntity.numInformes = oDataResp.body;
	   		oModel.setData(oEntity);
	   		sap.ui.getCore().setModel(oModel,"count");
	   		//sap.ui.getCore().getModel("users").iSizeLimit=200;
        }.bind(this),
        error: function (oError) {
           console.log(oError);
        }.bind(this)
	});
}

//Funci�n que nos exporta un excel de backend
function createExportJob(aFilters, aSorters){
	
	var oEntity = {};
	var selections = [];
	
	oEntity.ObjectType = "ZAUDR";
	oEntity.Scenario = "LST_INFPOR";
	oEntity.Template = "XLSX";
	
	$.each(aFilters,function(i,n){
		var operator = "";
		var value = ""
		switch(n.sOperator){
			default: operator = n.sOperator;
					value = n.oValue1;
					break;
			case "Contains": operator = "CP";
					value = "*" + n.oValue1 + "*";
					break;
		}
		selections.push({Field: n.sPath, Sign: "I", Opt: operator, Low: value});
	});
	
	var sorts = [];
	$.each(aSorters, function(i,n){
		sorts.push({AttributeName: n.sPath, Ascending: !n.bDescending});
	});
	
	if(selections.length != 0 ) oEntity.Selections = selections;
	if(sorts.length != 0 ) oEntity.Sorts = sorts;

	var url = "/ExportJobSet";
	getModel('con').create(url,oEntity,null,function(dataResp){
		window.open(listaInfoUtils.getServerURL() + getModel('con').sServiceUrl + "/ExportJobSet(guid'" + dataResp.Key + "')/File/$value", '_blank');
	},function(oError){
		console.log(oError);
	});
}

//---------------------> End section <-----------------------------------

//--------------------> Rol section <---------------------------------
/*function loadRol(){
	var rol = "Auditor";
	

}*/

//Esta funcion modifica el modelo del rol segun el rol, este hace visible o invisible lo que cada usuario puede ver.
/*function modifyRolModel(rol){
	var oModel = new sap.ui.model.json.JSONModel();
	switch(rol){
		case"Auditor":  oModel.getData().asignar = true;
						oModel.getData().desestimar = true;
						oModel.getData().rechazar = true;
						break;
		case"Supervisor":   oModel.getData().asignar = true;
							oModel.getData().desestimar = true;
							oModel.getData().rechazar = true;
							break;
	}
}*/

//---------------------> End section <-----------------------------------

//--------------------> Codigos Conclusion section <---------------------------------

/*function loadCodigosConclusion(aFilters){
	//Faig el read dels usuaris que tinguin el displayuser a true
	getModel('con').read(getCodigosConclusionUrl(),{
		filters : aFilters,
		async: false,
        success : function (oData) {
           jQuery.sap.log.info("Odata Read Successfully:::");
           console.log(oData);
	   		var oModel = new sap.ui.model.json.JSONModel();
	   		oModel.setData(oData);
	   		sap.ui.getCore().setModel(oModel,"codigosConclusion");
	   		sap.ui.getCore().getModel("codigosConclusion").iSizeLimit=200;
        }.bind(this),
        error: function (oError) {
           jQuery.sap.log.info("Odata Error occured");
        }.bind(this)
	});
}*/
//---------------------> End section <-----------------------------------

/**
 * INI MOD RTC 746228 Rafael Galán Baquero
 * 24.06.2019
 * Código nuevo
 */
// Se obtienen los departamentos disponibles en el sistema
function loadDepartments(){
	var url = "/InfoDepAuditSet";
	getModel('con').read(url,null,null,false,
			function(data,response){
				var oModel = new sap.ui.model.json.JSONModel();
				oModel.setData(data);
				async: false,	
			sap.ui.getCore().setModel(oModel,"DepAuditReport");
},function(oError){
	console.log(oError);		
});
}

// Se obtienen las clasificaciones disponibles en el sistema
function loadRatings(){
	
	var connexion = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/GRCAUD_SRV", false);
	var url = "/DataElementSet('GRCAUD_REPRAT')/NameValuePairs";
		connexion.read(url,null,null,false,	
				function(data,response){
					var oModel = new sap.ui.model.json.JSONModel();
					oModel.setData(data);
					async: false,	
				sap.ui.getCore().setModel(oModel,"RankingsAuditReport");
	},function(oError){
		console.log(oError);		
	});

	
}
/**
 * FIN MOD RTC 746228 Rafael Galán Baquero
 * 24.06.2019
 */


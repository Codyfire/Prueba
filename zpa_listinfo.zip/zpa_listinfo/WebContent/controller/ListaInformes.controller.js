sap.ui.controller("appListaInformes.controller.ListaInformes", {

/**
* Called when a controller is instantiated and its View controls (if available) are already created.
* Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
* @memberOf zadminuser.main
*/
	onInit: function() {
		
	},

/**
* Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
* (NOT before the first rendering! onInit() is used for that one!).
* @memberOf zadminuser.main
*/
//	onBeforeRendering: function() {
//
//	},

/**
* Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
* This hook is the same one that SAPUI5 controls get after being rendered.
* @memberOf zadminuser.main
*/
//	onAfterRendering: function() {
//
//	},

/**
* Called when the Controller is destroyed. Use this one to free resources and finalize activities.
* @memberOf zadminuser.main
*/
//	onExit: function() {
//
//	}
	
	onFilterPress: function(){
		if(!sap.ui.getCore().getComponent("listaInformFilter")){
			/**
			 * INI MOD RTC 746228 Rafael Gal�n Baquero
			 * 24.06.2019
			 * C�digo nuevo
			 */
			// Se realiza obtiene los departamentos disponibles
			loadDepartments();
			
			// Se realiza obtiene las clasificaciones disponibles
			loadRatings();
			/**
			 * FIN MOD RTC 746228 Rafael Gal�n Baquero
			 * 24.06.2019
			 */
			var oFilterComp = new sap.ui.getCore().createComponent({
				name: "listaFilterComponent",
				id:"listaInformFilter",
				settings: {refObject: "taulaInformes"}
			});
			var table = sap.ui.getCore().getComponent("taulaInformes").table;
			// En el filterItems se a�ade un valor vacio para evitar que coja la clave del campo Fecha de Distribuci�n
			oFilterComp.addAllItems([listaInfoUtils.oBundle.getText("numInforme"), listaInfoUtils.oBundle.getText("titInforme"), listaInfoUtils.oBundle.getText("fechaDistr"), listaInfoUtils.oBundle.getText("departamento"), listaInfoUtils.oBundle.getText("clasif")],
									[listaInfoUtils.oBundle.getText("numInforme"), listaInfoUtils.oBundle.getText("titInforme"), listaInfoUtils.oBundle.getText("fechaDistr"), listaInfoUtils.oBundle.getText("departamento"), listaInfoUtils.oBundle.getText("clasif")],
									[listaInfoUtils.oBundle.getText("numInforme"), listaInfoUtils.oBundle.getText("titInforme"), "",listaInfoUtils.oBundle.getText("departamento"), listaInfoUtils.oBundle.getText("clasif")], 
									"informes",
									["ReportId",
									"ReportTitle",
									"DateRepIssued",
									/**
									 * INI MOD RTC 746228 Rafael Gal�n Baquero
									 * 24.06.2019
									 * C�digo antiguo
									 //"DepartmentName",
									 // "RatingText"],
									 
									 * C�digo nuevo
									 */		
									// Se modifica la key de los filtros departamento y clasificaci�n para buscar por clave en vez del nombre
									"Department",
									"Rating"],
									/**
									 * FIN MOD RTC 746228 Rafael Gal�n Baquero
									 * 24.06.2019
									 */
									table);
			
			var oCompCont = new sap.ui.core.ComponentContainer({
				component: oFilterComp
			});
			
			oFilterComp.openDialog();
			sap.ui.getCore().getComponent("taulaInformes").refreshTablePaginationForFilteredItems(1,7);
		//	sap.ui.getCore().getComponent("paginationTable").recalculatePaginator
			
		}else{
			var oFilterComp = sap.ui.getCore().getComponent("listaInformFilter");
			//oFilterComp.refresh("users");
			oFilterComp.openDialog();
			sap.ui.getCore().getComponent("taulaInformes").refreshTablePaginationForFilteredItems(1,7);
		}
	},
	
	onLinkPress: function() {
		var dialog = new sap.m.Dialog({
			title: listaInfoUtils.oBundle.getText("info"),
			type: 'Message',
				content: new sap.m.Text({
					text: listaInfoUtils.oBundle.getText("funcDescInf")
				}),
			beginButton: new sap.m.Button({
				text: listaInfoUtils.oBundle.getText("ok"),
				press: function () {
					dialog.close();
				}
			}),
			afterClose: function() {
				dialog.destroy();
			}
		});

		dialog.open();
	},
	
	showListaInforme: function() {
		var viewContainer = sap.ui.getCore().byId("listaInformesCont");
		
		if(viewContainer.getPage("listaInforme"))
		{
			viewContainer.getPage('listaInforme').destroy();
		}
		
		var oModel = new sap.ui.model.json.JSONModel(); 
		var data = sap.ui.getCore().getModel('distList').getProperty("/results/0");
		oModel.setData(data);
		
		var view = sap.ui.view({id:"listaInforme", viewName:"appListaInformes.view.ListAccesoDetail", type:sap.ui.core.mvc.ViewType.JS});
		view.setModel(oModel);
		
		viewContainer.addPage(view);	
		viewContainer.to("listaInforme","slide",{oModel: oModel});
	},
	
	downloadReport: function(oEvent) {
		var sPath = oEvent.getSource().getBindingContext().sPath;
		var key = oEvent.getSource().getBindingContext().getModel().getProperty(sPath).RepKey;
		var convertedKey = convertKey(key);
		window.open(window.location.protocol + "//" + window.location.hostname + ":" + window.location.port +"/sap/opu/odata/sap/GRCAUD_SRV/DocWorkPaperSet(guid'" + convertedKey.substring(0,8) + "-" + convertedKey.substring(8,12) + "-" + convertedKey.substring(12,16) + "-" + convertedKey.substring(16,20) + "-" + convertedKey.substring(20) + "')/File/$value"); 
	},
	
	
	onColunModifierPress: function(){
		if(!sap.ui.getCore().getComponent("visColumnListaInfComp")){
			var oVisualitzadorComp = new sap.ui.getCore().createComponent({
				name: "visualitzadorColumnesComponent",
				id:"visColumnListaInfComp"
			});
			var table = sap.ui.getCore().getComponent("taulaInformes").table;
			oVisualitzadorComp.addAllItems(table);
			
			var funct = function(){
				$.each(oVisualitzadorComp.oSelectDialog.getItems(),function(i,n){
					j = i - 1;
					if(j > -1 && j < table.getColumns().length)
						table.getColumns()[j].setVisible(n.getSelected());
				});
			}
			oVisualitzadorComp.addConfirmFunction(funct);
			
			var oVisualitzadorCompCont = new sap.ui.core.ComponentContainer({
				component: oVisualitzadorComp
			});
			
			oVisualitzadorComp.openDialog();
			
			
		}else{
			var oVisualitzadorComp = sap.ui.getCore().getComponent("visColumnListaInfComp");

			oVisualitzadorComp.openDialog();
		}
	}
});
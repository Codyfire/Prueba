jQuery.sap.declare("searchComponent.Component");
jQuery.sap.require("sap.ui.core.UIComponent");

sap.ui.core.UIComponent.extend("searchComponent.Component", {
     /*metadata: {
         properties: {
              itemsPerLine: {
            		type: 'int',
            		defaultValue: 7
              },
              addWhiteSpaces: {
          		type: 'boolean',
          		defaultValue: false
              }
         },
         events: {
            addNewItem: {
            	parameters: {
            		item: {
            			type: 'string'
            		}
            	}
            }
         },
   },*/
	init: function() {
	    // define variable for control initial loading handling
	    this._bInitialLoading = true;
		   // execute standard control method
	    sap.ui.core.UIComponent.prototype.init.apply(this,arguments);
	},
	
	createContent: function() {
		
		// Search Field
		var searchField = new sap.m.SearchField({});
		
		// List Item
		var listContainer = new sap.m.Table({
			width : "100%",
			height : "100%",
		});
		this.table = listContainer;
		
		var dialog = new sap.m.Dialog({
			showHeader:false,
			content:[
			         searchField,
			         listContainer
			         ],
	        beginButton: new sap.m.Button({
					text: listaInfoUtils.oBundle.getText("anadir"),
				}),
			endButton: new sap.m.Button({
				text: listaInfoUtils.oBundle.getText("cancelar"),
				press: function () {
					dialog.close();
				}
			}),         
		});
		
		this.searchField = searchField;
		this.listContainer = listContainer;
		this.dialog = dialog;
		
		this.dialog.open();
		
	},
	
	// Cabecera, Binding Posiciones, Modo de Lista, Binding Aggregation, Path, Model, AddFunction
	setupInicial: function(columns, cells, listMode, bindAggregation, path, oModel, addFunct, addSearchFunct) {
		this.addColumns(columns);
		this.setListMode(listMode);
		this.createItemTemplate(bindAggregation, path, cells);
		this.addModel(oModel);
		this.setAddFunction(addFunct);
		this.setSerchFunction(addSearchFunct);
	},
	
	// Se indica el modo de selecci�n de la tabla
	setListMode: function(mode) {
		this.listContainer.setMode(mode);
	},
	
	// Se crean las columnas dinamicamente
	addColumns: function(cols) {
		
		var listContainer = this.listContainer;
		
		if(cols) {
		    $.each(cols,function (i, n) {
			    if(n != undefined && n != null) {
			    	var col = new sap.m.Column({  
		                hAlign : "Left",  
		                header : new sap.m.Label({  
		                          text : n,
		                          design: sap.m.LabelDesign.Bold
		                })});
					
					listContainer.addColumn(col);
			    }
		    });
		}
	},
		
	// Se a�ade el objeto de itemTemplate
	addItemTemplate: function(aggregation, path, itemTemplate) {
		
		var listContainer = this.listContainer;
		
		listContainer.bindAggregation(aggregation, path , itemTemplate);
		listContainer.bindItems({path:path,template: itemTemplate});
	},
	
	// Se crea el objeto de itemTemplate -> bindings = array [ "{Id}", "{Name}", ... ]
	createItemTemplate: function(aggregation, path, bindings) {
		
		var listContainer = this.listContainer;
		
		var itemTemplate = new sap.m.ColumnListItem({});
		
		if(bindings) {
		    $.each(bindings,function (i, n) {
			    if(n != undefined && n != null) {
			    	itemTemplate.addCell(new sap.m.Label({ text : n }));
			    }
		    });
		}

		itemTemplate.addCustomData(new sap.ui.core.CustomData({ key : "Id", value : "{id}" }));
		listContainer.bindAggregation(aggregation, path, itemTemplate);
		listContainer.bindItems({path:path,template: itemTemplate});
	},
	
	addModel: function(oModel) {
		//this.listContainer.setModel(sap.ui.getCore().getModel(oModel));
		this.listContainer.setModel(new sap.ui.model.json.JSONModel(sap.ui.getCore().getModel(oModel).getData() ));
	},
	
	setAddFunction: function( funct ) {
		
		var dialog = this.dialog;
		
		dialog.getBeginButton().attachPress( funct );
	},
	
	setSerchFunction: function(funct){
		var dialog = this.dialog;
		var oSearchField = dialog.getContent()[0];
		oSearchField.attachSearch(funct);
	}
});